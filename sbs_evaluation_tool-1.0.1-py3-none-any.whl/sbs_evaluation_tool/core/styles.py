"""Compatibility wrapper for `core.styles`.

Usage::

    from sbs_evaluation_tool.core.styles import COLORS, STATUS_COLORS
"""

from core.styles import *  # noqa: F401,F403
