from typing import Optional, Dict, Any
from IPython.display import display, HTML

def show_test_inline(test_obj, params: Dict[str, Any], key: Optional[str] = None, max_items: Optional[int] = None) -> None:
    """
    Выполнить тест и сразу отобразить его HTML-результат в ноутбуке, без сборки общего отчёта.

    Параметры:
      - test_obj: экземпляр теста (например, M42_CalibrationCurveByPredictBinsLn())
      - params: словарь параметров, передаваемых в run(...).
                Рекомендуемый формат: {'df': final_df, 'config': config, ...}
      - key: если у результата есть конкретный ключ ('combined', 'score' и т.п.),
             можно явно указать, какой блок отрисовать.
      - max_items: если результат содержит много блоков (например, по признакам),
                   ограничивает количество выводимых блоков.
    """
    try:
        res = test_obj.run(**params)
    except Exception as e:
        display(HTML(f"<p>Ошибка выполнения теста: {str(e)}</p>"))
        return

    if not isinstance(res, dict):
        display(HTML(f"<p>Unexpected result type: {type(res)}</p>"))
        return

    # Приоритет: конкретный ключ -> 'combined' -> 'DASHBOARD' -> все остальные элементы
    if key and key in res:
        display(HTML(res[key]))
        return
    if 'combined' in res:
        display(HTML(res['combined']))
        return
    if 'DASHBOARD' in res:
        display(HTML(res['DASHBOARD']))
        return

    shown = 0
    for subkey, html in res.items():
        display(HTML(f"<h4 style='margin:8px 0'>{subkey}</h4>" + str(html)))
        shown += 1
        if max_items and shown >= max_items:
            break
