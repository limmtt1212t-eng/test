import os
import base64
from typing import Dict, Optional, Tuple

COLORS: Dict[str, str] = {
    'GREEN': '#21A038',    # основной зелёный (светофоры)
    'EMERALD': '#21BA72',  # изумрудный (графики/линии)
    'GRASS': '#00D900',    # насыщенный зелёный для TRAIN гистограмм
    'YELLOW': '#FFCC00',   # жёлтый
    'RED': '#fa1929',      # красный
    'BLUE': '#1f77b4',     # существующий синий (INFO) — оставляем
    'GRAY': '#7f7f7f',     # нейтральный серый
    'TEXT': '#333F48',     # корпоративный цвет текста
}

# Сопоставление статусов к корпоративным цветам
STATUS_COLORS: Dict[str, str] = {
    'green': COLORS['GREEN'],
    'yellow': COLORS['YELLOW'],
    'orange': COLORS['YELLOW'],  # оранжевый приравняем к корпоративному жёлтому
    'red': COLORS['RED'],
    'blue': COLORS['BLUE'],
    'gray': COLORS['GRAY'],
}

# Папка для шрифтов (положить сюда .ttf)
FONTS_DIR = os.path.join(os.path.dirname(__file__), 'fonts')
ASSETS_DIR = os.path.join(os.path.dirname(__file__), 'assets')


def _hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
    hex_color = hex_color.lstrip('#')
    if len(hex_color) == 3:
        hex_color = ''.join([c*2 for c in hex_color])
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))


def rgba(hex_color: str, alpha: float) -> str:
    r, g, b = _hex_to_rgb(hex_color)
    a = max(0.0, min(1.0, float(alpha)))
    return f"rgba({r}, {g}, {b}, {a})"


def load_first_font_in_dir(dir_path: str) -> Optional[str]:
    try:
        for name in os.listdir(dir_path):
            lower = name.lower()
            if lower.endswith('.ttf') or lower.endswith('.otf'):
                return os.path.join(dir_path, name)
    except Exception:
        return None
    return None


def apply_matplotlib_style(font_path: Optional[str] = None) -> None:
    """Применяет корпоративный стиль к Matplotlib (цвета и шрифты).

    - Настраивает семейство шрифтов, если найден .ttf (либо в font_path, либо первый в FONTS_DIR)
    - Задаёт стандартный цветовой цикл с упором на изумрудный для линий
    - Не трогает прозрачности (alpha) — остаются на уровне, задаваемом конкретными графиками
    """
    try:
        import matplotlib as mpl
        from matplotlib import font_manager

        # Шрифт: берём явный путь или первый .ttf из FONTS_DIR
        font_to_use = font_path or load_first_font_in_dir(FONTS_DIR)
        if font_to_use and os.path.isfile(font_to_use):
            try:
                font_manager.fontManager.addfont(font_to_use)
                font_name = font_manager.FontProperties(fname=font_to_use).get_name()
                mpl.rcParams['font.family'] = font_name
            except Exception:
                pass

        # Цветовой цикл (первым — EMERALD)
        emerald = COLORS['EMERALD']
        green = COLORS['GREEN']
        yellow = COLORS['YELLOW']
        red = COLORS['RED']
        blue = COLORS['BLUE']
        gray = '#6d6d6d'
        mpl.rcParams['axes.prop_cycle'] = mpl.cycler(color=[emerald, blue, green, gray, red, yellow])

        # Сетка/ось — более нейтральные
        mpl.rcParams['grid.color'] = '#cccccc'
        mpl.rcParams['axes.edgecolor'] = '#444444'
        mpl.rcParams['xtick.color'] = '#333333'
        mpl.rcParams['ytick.color'] = '#333333'

    except Exception:
        # Тихий фоллбэк — не ломаем исполнение, если Matplotlib недоступен
        pass


def _detect_font_format(ext: str) -> str:
    ext = ext.lower().lstrip('.')
    if ext == 'ttf':
        return 'truetype'
    if ext == 'otf':
        return 'opentype'
    # generic default
    return 'truetype'


def generate_font_face_css(font_path: Optional[str] = None, font_family: str = 'Corporate') -> str:
    """Генерирует CSS с встраиванием шрифта через @font-face (base64) и применением к <body>.

    Если файл шрифта не найден, возвращает CSS только с семейством запасных системных шрифтов.
    """
    # Пытаемся найти шрифт: явный путь или первый из папки FONTS_DIR
    path = font_path or load_first_font_in_dir(FONTS_DIR)
    if path and os.path.isfile(path):
        try:
            with open(path, 'rb') as f:
                data = f.read()
            b64 = base64.b64encode(data).decode('ascii')
            fmt = _detect_font_format(os.path.splitext(path)[1])
            # Используем data: URL с base64
            font_face = (
                f"@font-face {{\n"
                f"  font-family: '{font_family}';\n"
                f"  src: url(data:font/{fmt};charset=utf-8;base64,{b64}) format('{fmt}');\n"
                f"  font-weight: normal;\n"
                f"  font-style: normal;\n"
                f"  font-display: swap;\n"
                f"}}\n"
            )
            body_css = (
                f"body {{\n"
                f"  font-family: '{font_family}', -apple-system, 'Segoe UI', Arial, Helvetica, sans-serif;\n"
                f"  color: {COLORS['TEXT']};\n"
                f"}}\n"
            )
            return font_face + body_css
        except Exception:
            # Фоллбэк — только системные шрифты
            pass

    # Без встроенного шрифта: система + запасные
    return (
        "body {\n"
        "  font-family: -apple-system, 'Segoe UI', Arial, Helvetica, sans-serif;\n"
        f"  color: {COLORS['TEXT']};\n"
        "}\n"
    )


def get_logo_data_uri() -> Optional[str]:
    """Ищет логотип в ASSETS_DIR и возвращает data URI.

    Приоритетные имена: sber_logo.svg/png/jpg/jpeg, затем logo.*. Возвращает None, если файл не найден.
    """
    try:
        base_dir = os.path.dirname(__file__)
        search_dirs = [
            ASSETS_DIR,
            os.path.join(os.path.dirname(base_dir), 'assets'),  # core/assets
            os.path.join(os.path.dirname(os.path.dirname(base_dir)), 'assets'),  # <project>/assets
            base_dir,  # allow dropping logo next to this file
        ]
        allowed_exts = ('.svg', '.png', '.jpg', '.jpeg')
        candidates = [
            'sber_logo.svg', 'sber_logo.png', 'sber_logo.jpg', 'sber_logo.jpeg',
            'logo.svg', 'logo.png', 'logo.jpg', 'logo.jpeg',
        ]

        def encode_path(path: str) -> Optional[str]:
            ext = os.path.splitext(path)[1].lower()
            if ext == '.svg':
                mime = 'image/svg+xml'
            elif ext in ('.jpg', '.jpeg'):
                mime = 'image/jpeg'
            elif ext == '.png':
                mime = 'image/png'
            else:
                return None
            with open(path, 'rb') as f:
                b64 = base64.b64encode(f.read()).decode('ascii')
            return f"data:{mime};base64,{b64}"

        for d in search_dirs:
            if not os.path.isdir(d):
                continue
            # First, try prioritized names
            for name in candidates:
                path = os.path.join(d, name)
                if os.path.isfile(path):
                    uri = encode_path(path)
                    if uri:
                        return uri
            # Else, try any file starting with sber_logo or logo
            try:
                for name in os.listdir(d):
                    lower = name.lower()
                    if (lower.startswith('sber_logo') or lower.startswith('logo')) and lower.endswith(allowed_exts):
                        path = os.path.join(d, name)
                        uri = encode_path(path)
                        if uri:
                            return uri
            except Exception:
                continue
    except Exception:
        return None
    return None
