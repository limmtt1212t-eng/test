import pandas as pd
from datetime import datetime
from pathlib import Path

from .base_test import TestGroupBuilder, ModelReportBuilder
from ..tests.psi_calculator import PSICalculator, PSICalculatorExtended

# Import all test modules
from ..tests.m0_data_quality import (
    M01_DataQualityOverviewTest,
    M04_MonthlyDistributionsTest,
    M05_ModeAndMissingByPeriodTest
)
from ..tests.m1_distribution_tests import (
    M11_TrainVsGenpopPSITest,
    M12_OOSVsGenpopPSITest,
    M13_MaxDateRecencyTest,
)
from ..tests.m2_gini_tests import (
    M21_GiniTest,
    M22_GiniFactorsTest,
    M23_GiniDynamicsTest,
    M24_GiniUpliftTest,
)
from ..tests.m3_multicollinearity import (
    M31_CorrelationOverviewTest,
    M32_LikelihoodRatioTest,
    M33_MulticollinearityTest,
)
from ..tests.m4_model_performance import (
    M41_TargetRateTest,
    M42_CalibrationCurveByPredictBinsLn,
    M43_CalibrationCurveByDatesLn,
)
from ..tests.m5_model_stability import (
    M51_ModelGiniStabilityTest,
    M52_FactorGiniStabilityTest,
    M53_ScorePSITest,
    M54_FactorPSITest,
)

def run_sbs_evaluation(data: pd.DataFrame, config: dict, segment_name: str = "FMTLP", output_dir: str = "reports", size: str = "normal"):
    """
    Запускает полный цикл тестов SBS (M0-M5), генерирует и сохраняет HTML-отчет.
    
    Args:
        data: DataFrame с данными (должен содержать колонки из config)
        config: Словарь конфигурации SBS
        segment_name: Префикс для имени файла отчета (например, 'FMTLP' или 'OSAGO')
        output_dir: Папка для сохранения отчетов (относительно корневой директории запуска)
    """
    print(f"🚀 Запуск SBS Evaluation для сегмента: {segment_name}")
    
    psi_calc = PSICalculatorExtended()
    
    # --- Group M0: Data Quality ---
    group_m0 = TestGroupBuilder(group_code="M0", group_name="M0. Data Quality")
    group_m0.add_test(M01_DataQualityOverviewTest())
    group_m0.add_test(M04_MonthlyDistributionsTest())
    group_m0.add_test(M05_ModeAndMissingByPeriodTest())

    params_m0 = {
        "M 0.1": {"df": data, "config": config},
        "M 0.4": {"df": data, "config": config},
        "M 0.5": {"df": data, "config": config},
    }

    # --- Group M1: Distribution ---
    group_m1 = TestGroupBuilder(group_code="M1", group_name="M1. Distribution")
    group_m1.add_test(M11_TrainVsGenpopPSITest(psi_calc=psi_calc))
    group_m1.add_test(M12_OOSVsGenpopPSITest(psi_calc=psi_calc))
    group_m1.add_test(M13_MaxDateRecencyTest())

    params_m1 = {
        "M 1.1": {"df": data, "config": config},
        "M 1.2": {"df": data, "config": config},
        "M 1.3": {"df": data, "config": config},
    }

    # --- Group M2: Gini ---
    group_m2 = TestGroupBuilder(group_code="M2", group_name="M2. Gini")
    group_m2.add_test(M21_GiniTest())
    group_m2.add_test(M22_GiniFactorsTest())
    group_m2.add_test(M23_GiniDynamicsTest())
    group_m2.add_test(M24_GiniUpliftTest())

    params_m2 = {
        "M 2.1": {"df": data, "config": config},
        "M 2.2": {"df": data, "config": config},
        "M 2.3": {"df": data, "config": config},
        "M 2.4": {"df": data, "config": config},
    }

    # --- Group M3: Multicollinearity ---
    if size != "heavy":
        group_m3 = TestGroupBuilder(group_code="M3", group_name="M3. Multicollinearity")
        group_m3.add_test(M31_CorrelationOverviewTest())
        group_m3.add_test(M32_LikelihoodRatioTest())
        group_m3.add_test(M33_MulticollinearityTest())

        params_m3 = {
            "M 3.1": {"df": data, "config": config},
            "M 3.2": {"df": data, "config": config},
            "M 3.3": {"df": data, "config": config},
        }
    else:
        print("  ⏭️  M3 (Multicollinearity) пропущена (size='heavy')")

    # --- Group M4: Calibration ---
    group_m4 = TestGroupBuilder(group_code="M4", group_name="M4. Calibration")
    group_m4.add_test(M41_TargetRateTest())
    # По умолчанию M4.2/M4.3 строят обычные и логарифмические графики.
    group_m4.add_test(M42_CalibrationCurveByPredictBinsLn())
    group_m4.add_test(M43_CalibrationCurveByDatesLn())

    params_m4 = {
        "M 4.1": {"df": data, "config": config},
        "M 4.2": {"df": data, "config": config, "num_groups": 20},
        "M 4.3": {"df": data, "config": config},
    }

    # --- Group M5: Stability ---
    group_m5 = TestGroupBuilder(group_code="M5", group_name="M5. Stability")
    group_m5.add_test(M51_ModelGiniStabilityTest())
    group_m5.add_test(M52_FactorGiniStabilityTest())
    group_m5.add_test(M53_ScorePSITest(psi_calc=psi_calc))
    group_m5.add_test(M54_FactorPSITest(psi_calc=psi_calc))

    params_m5 = {
        "M 5.1": {"df": data, "config": config},
        "M 5.2": {"df": data, "config": config},
        "M 5.3": {"df": data, "config": config},
        "M 5.4": {"df": data, "config": config},
    }

    # --- Run execution ---
    all_groups = [group_m0, group_m1, group_m2, group_m4, group_m5]
    all_params = [params_m0, params_m1, params_m2, params_m4, params_m5]
    if size != "heavy":
        all_groups.insert(3, group_m3)
        all_params.insert(3, params_m3)

    mr = ModelReportBuilder()
    
    for grp, params in zip(all_groups, all_params):
        print(f"  ... Running group {grp.group_name}")
        grp.run_all_tests(test_params=params)
        mr.add_group(grp)

    # --- Report Generation ---
    html = mr.generate_html()
    
    # Generate filename
    cols = config.get("columns", {}) if isinstance(config, dict) else getattr(config, "columns", {})
    score_name = cols.get("prediction_column") or cols.get("score_column") or "score"
    target_name = cols.get("target_column") or "target"
    
    def _sanitize(name: str) -> str:
        return "".join(ch if (str(ch).isalnum() or ch in ('-', '_', '.')) else '_' for ch in str(name))
    
    today = datetime.now().strftime('%d_%m_%Y')
    fname = f"{_sanitize(segment_name)}_{_sanitize(score_name)}_{_sanitize(target_name)}_{today}.html"
    
    # Используем Path.cwd() для определения текущей рабочей директории, если output_dir относительный
    out_path_dir = Path(output_dir)
    if not out_path_dir.is_absolute():
       out_path_dir = Path.cwd() / output_dir

    out_path_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_path_dir / fname
    
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(html)
        
    print(f"✅ Готово! Отчет сохранен: {out_path}")
    return str(out_path)
