from typing import Tuple, Optional, Any, Dict, List, Union
import pandas as pd
from .config_validation import SBSConfig, ConfigValidationError, validate_config

def ensure_config(config: Union[Dict, SBSConfig], df: pd.DataFrame) -> SBSConfig:
    """
    Ensures config is a validated SBSConfig object.
    If it's already SBSConfig, returns it as-is.
    If it's a dict, validates and returns SBSConfig.
    """
    if isinstance(config, SBSConfig):
        return config
    return validate_config(config, df)

def get_col_name(cfg: SBSConfig, name: str) -> Optional[str]:
    """
    Safely retrieves a column name from SBSConfig.columns.
    Returns None if the attribute doesn't exist.
    """
    return getattr(cfg.columns, name, None)

def split_frames(df: pd.DataFrame, cfg: SBSConfig) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Splits DataFrame into train, test, and genpop (full) based on sample_column in config.
    Returns (df_train, df_test, df_genpop).
    """
    sc = cfg.columns.sample_column
    if sc is None or sc not in df.columns:
        raise ConfigValidationError([f"Column '{sc}' (sample_column) is missing in DataFrame"])
    
    s = df[sc].astype(str).str.lower()
    df_train = df[s.eq('train')].copy()
    df_test = df[s.eq('test')].copy()
    return df_train, df_test, df.copy()

def get_weight_col(df: pd.DataFrame, cfg: SBSConfig, config_dict: Optional[dict] = None) -> Optional[pd.Series]:
    """
    Retrieves the weight series from DataFrame based on config.
    Returns None if weight_column is not set, not in DF, or contains only non-positive values.
    Supports legacy dict access via config_dict for backward compatibility if needed,
    but primarily uses SBSConfig.
    """
    weight_col = None
    if config_dict:
        cols = config_dict.get("columns") or config_dict
        weight_col = cols.get("weight_column") or cols.get("weight")
    
    if weight_col is None:
        weight_col = getattr(cfg.columns, 'weight_column', None)
    
    if not weight_col or weight_col not in df.columns:
        return None
    
    w = pd.to_numeric(df[weight_col], errors="coerce").fillna(0.0)
    if (w > 0).sum() == 0:
        # If all weights are 0, treating as unweighted might be safer or returning None
        return None
    return w

def get_features(df: pd.DataFrame, cfg: SBSConfig, include_categorical: bool = True) -> List[str]:
    """
    Returns combined list of numeric and categorical features from config.
    Ensures unique values and presence in DataFrame is valid (optional check).
    """
    num = getattr(cfg.columns, 'numeric_features', []) or []
    cat = getattr(cfg.columns, 'categorical_features', []) or []
    
    feats = list(num)
    if include_categorical:
        feats.extend(list(cat))
        
    # Remove duplicates while preserving order
    return list(dict.fromkeys(feats))

def get_score_col(cfg: SBSConfig) -> str:
    """
    Determines the primary score column based on task type.
    Classification -> prediction_column
    Regression -> score_column (or prediction_column fallback)
    """
    if str(cfg.task).lower() == "classification":
        if not cfg.columns.prediction_column:
             # Fallback if prediction_column is missing but score_column exists? 
             # Usually prediction_column is score.
             pass
        return cfg.columns.prediction_column
    elif str(cfg.task).lower() == "regression":
        if getattr(cfg.columns, 'score_column', None):
            return cfg.columns.score_column
        # Fallback
        if getattr(cfg.columns, 'prediction_column', None):
            return cfg.columns.prediction_column
        raise ConfigValidationError(["Для regression требуется columns.score_column (или prediction_column)"])
    return None

def get_vectors(df: pd.DataFrame, cfg: SBSConfig, for_classification: bool = True) -> Tuple[pd.Series, Optional[pd.Series], Optional[pd.Series]]:
    """
    Returns (target, prediction, score) series from DataFrame based on config.
    target: target_column
    prediction: prediction_column (optional - class labels for classification)
    score: score_column (optional - probabilities for classification, value for regression)
    
    Validates presence of columns.
    """
    tcol = cfg.columns.target_column
    scol = cfg.columns.score_column
    pcol = cfg.columns.prediction_column
    
    if tcol not in df.columns:
        raise ConfigValidationError([f"target_column '{tcol}' not in df"])
    
    y = df[tcol]
    score = df[scol] if (scol and scol in df.columns) else None
    pred = df[pcol] if (pcol and pcol in df.columns) else None
    
    if for_classification:
        if score is None and pred is None:
             raise ConfigValidationError(["For classification need either score_column or prediction_column"])
    else:
        if score is None:
             if pred is not None:
                  score = pred
             else:
                  raise ConfigValidationError(["For regression need score_column (or prediction_column) with numeric predictions"])
             
    return y, pred, score
