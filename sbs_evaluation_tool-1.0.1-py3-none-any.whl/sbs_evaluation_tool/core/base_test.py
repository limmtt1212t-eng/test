from abc import ABC, abstractmethod
from typing import List, Dict, Union
import itertools
import logging
from .styles import STATUS_COLORS, rgba, apply_matplotlib_style, generate_font_face_css, COLORS, get_logo_data_uri

# Configure root logger with time-only formatter once
_root = logging.getLogger()
if not _root.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter('[%(asctime)s] %(message)s', datefmt='%H:%M:%S'))
    _root.addHandler(_handler)
    _root.setLevel(logging.INFO)

# Базовый абстрактный класс теста
class BaseModelTest(ABC):
    def __init__(self, test_code: str, test_name: str):
        self.test_code = test_code
        self.test_name = test_name
        self.test_signal = None  # string: "green", "yellow", "red"
        self.test_meta = {}      # dict with metadata: summary values, counts, etc.

    @abstractmethod
    def run(self, **kwargs) -> Dict[str, str]:
        """
        Выполнить тест и вернуть словарь вида {feature_name: html_block, ..., 'DASHBOARD': dashboard_html (опционально)}
        """
        pass

class TestGroupBuilder:
    def __init__(self, group_code: str, group_name: str):
        self.group_code = group_code
        self.group_name = group_name
        self.tests: List[BaseModelTest] = []
        self.test_results: Dict[str, Dict[str, str]] = {}


    def add_test(self, test: BaseModelTest):
        self.tests.append(test)

    def run_all_tests(self, test_params: Dict[str, dict]):
        for test in self.tests:
            params = test_params.get(test.test_code, {})
            self.test_results[test.test_code] = test.run(**params)
    
    def compute_group_signal(self) -> str:
        """Group-level traffic light:
        - Red if any test is red
        - Yellow if > 10% of considered tests are yellow/orange (and none red)
        - Else green
        Blue/gray are informational and ignored in the ratio.
        """
        signals = [getattr(t, 'test_signal', None) for t in self.tests]
        if any(s == 'red' for s in signals):
            return 'red'
        total_considered = sum(1 for s in signals if s in ('green', 'yellow', 'orange'))
        yellow_like = sum(1 for s in signals if s in ('yellow', 'orange'))
        if total_considered > 0 and (yellow_like / total_considered) > 0.10:
            return 'yellow'
        return 'green'
    
    def generate_group_menu(self) -> str:
        # Use corporate colors with softer background via rgba alpha
        def bg(signal: str) -> str:
            hex_color = STATUS_COLORS.get(signal or 'gray', '#dddddd')
            return rgba(hex_color, 0.18)

        return ''.join([
            f'<li onclick="showTest(\'{self.group_code}_{test.test_code}\')" '
            f'style="background-color: {bg(getattr(test, "test_signal", None))};">'
            f'{test.test_code} {test.test_name}</li>'
            for test in self.tests
        ])

    def generate_group_content(self) -> str:
        html_blocks = ""

        # --- Signal Summary Table ---
        signal_summary = "<h3>Test Signal Summary</h3><table border='1' cellpadding='5'><tr><th>Test</th><th>Signal</th></tr>"
        for test in self.tests:
            signal = getattr(test, "test_signal", None)
            # Map colors; treat blue as INFO in blue color
            color = STATUS_COLORS.get(signal or 'gray', 'black')
            signal_display = ("INFO" if signal == "blue" else signal.upper()) if signal else "-"
            signal_summary += f"<tr><td>{test.test_code} {test.test_name}</td><td style='color:{color}'><b>{signal_display}</b></td></tr>"
        signal_summary += "</table><hr>"

        html_blocks += f"""
        <div id="signal_summary_{self.group_code}" class="test-block" style="display:none">
            {signal_summary}
        </div>
        """

        # --- Per-test blocks ---
        for test in self.tests:
            test_id = f"{self.group_code}_{test.test_code}"
            features = self.test_results[test.test_code]
            feature_blocks = ""

            if "DASHBOARD" in features:
                feature_blocks += f"{features['DASHBOARD']}"

            non_dashboard_items = [(feat, html) for feat, html in features.items() if feat != "DASHBOARD"]
            if "DASHBOARD" in features and non_dashboard_items:
                feature_blocks += "<hr>"

            if len(non_dashboard_items) == 1:
                feature_blocks += str(non_dashboard_items[0][1])
            else:
                for feat, html in non_dashboard_items:
                    feature_blocks += f"""
                    <details>
                        <summary><b>{feat}</b></summary>
                        {html}
                    </details>
                    <br>
                    """

            html_blocks += f"""
            <div id="{test_id}" class="test-block" style="display:none">
                <h2>{test.test_code} {test.test_name}</h2>
                {feature_blocks}
            </div>
            """

        return html_blocks


class ModelReportBuilder:
    def __init__(self):
        self.groups: List[TestGroupBuilder] = []

    def add_group(self, group: TestGroupBuilder):
        self.groups.append(group)

    def generate_html(self) -> str:
        # Apply global matplotlib style (colors + corporate font if available)
        try:
            apply_matplotlib_style()
        except Exception:
            pass

        # Embed corporate font into HTML via @font-face (base64) and set body font
        try:
            font_css = generate_font_face_css()
        except Exception:
            font_css = "body { font-family: -apple-system, 'Segoe UI', Arial, Helvetica, sans-serif; }"

        # Build overall (home) signal based on group-level signals
        group_signals = []
        for group in self.groups:
            group_signals.append(group.compute_group_signal())
        def aggregate_signal(signals_list):
            if any(s == 'red' for s in signals_list):
                return 'red'
            considered = [s for s in signals_list if s in ('green', 'yellow', 'orange')]
            if considered:
                yellow_ratio = sum(1 for s in considered if s in ('yellow', 'orange')) / len(considered)
                if yellow_ratio > 0.10:
                    return 'yellow'
            return 'green'
        overall_signal = aggregate_signal(group_signals)

        # Build tab headers with home first and group-level traffic light color
        tab_headers = ''
        home_bg = rgba(STATUS_COLORS.get(overall_signal, '#dddddd'), 0.25)
        # Inline SVG for house icon
        home_icon_svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" style="vertical-align:middle;margin-right:6px;">'
            '<path d="M12 3l9 8h-3v9h-5v-6H11v6H6v-9H3l9-8z" fill="currentColor"/></svg>'
        )
        tab_headers += (
            f'<button class="tablink" style="background-color:{home_bg}" '
            f'onclick="openGroup(event, \'group_HOME\')">{home_icon_svg}Home</button>'
        )
        for group in self.groups:
            gsig = group.compute_group_signal()
            bg_col = rgba(STATUS_COLORS.get(gsig, '#dddddd'), 0.25)
            tab_headers += (
                f'<button class="tablink" style="background-color:{bg_col}" '
                f'onclick="openGroup(event, \'group_{group.group_code}\')">{group.group_name}</button>'
            )

        # Build Home dashboard tab content
        # Dashboard table summarizing all groups and tests with signals
        def signal_dot(signal_name: str) -> str:
            color = STATUS_COLORS.get(signal_name or 'gray', '#cccccc')
            return f"<span class='signal-dot' style='background-color:{color}' title='{signal_name or '-'}'></span>"

        dashboard_rows = []
        for group in self.groups:
            gsig = group.compute_group_signal()
            # Group header row
            dashboard_rows.append(
                f"<tr class='group-row'><td><b>{group.group_code}</b></td><td><b>{group.group_name}</b></td>"
                f"<td class='center'>{signal_dot(gsig)}</td><td><b>{gsig.upper()}</b></td></tr>"
            )
            # Each test row
            for test in group.tests:
                tsig = getattr(test, 'test_signal', None)
                sig_label = ("INFO" if tsig == 'blue' else (tsig.upper() if tsig else '-'))
                dashboard_rows.append(
                    f"<tr><td>{group.group_code}</td><td>{test.test_code} {test.test_name}</td>"
                    f"<td class='center'>{signal_dot(tsig)}</td><td>{sig_label}</td></tr>"
                )

        dashboard_table = (
            "<div class='home-dashboard'>"
            "<h2>Overall Dashboard</h2>"
            f"<p><b>Overall status:</b> {signal_dot(overall_signal)} <span>{overall_signal.upper()}</span></p>"
            "<table class='dashboard-table'>"
            "<thead><tr><th>Group</th><th>Item</th><th>Signal</th><th>Status</th></tr></thead>"
            f"<tbody>{''.join(dashboard_rows)}</tbody>"
            "</table>"
            "</div>"
        )

        group_tabs = ''
        group_tabs += f"""
            <div id="group_HOME" class="tabcontent" style="display:none;">
                {dashboard_table}
            </div>
        """
        for group in self.groups:
            menu = group.generate_group_menu()
            content = group.generate_group_content()
            group_tabs += f'''
            <div id="group_{group.group_code}" class="tabcontent" style="display:none;">
                <ul class="test-list">{menu}</ul>
                {content}
            </div>
            '''

        # Build report header with optional logo
        try:
            logo_uri = get_logo_data_uri()
        except Exception:
            logo_uri = None
        logo_img = f'<img class="brand-logo" src="{logo_uri}" alt="Sber logo" />' if logo_uri else ''
        header_html = (
            f'<header class="report-header">'
            f'{logo_img}'
            f'<h1 class="report-title"><span class="brand-gradient">SBS</span> Model Evaluation Tool</h1>'
            f'</header>'
        )

        return f"""
        <html><head>
        <style>
            {font_css}
            .tablink {{
                background-color: #ddd;
                border: none;
                outline: none;
                cursor: pointer;
                padding: 10px 15px;
                font-size: 16px;
                font-family: inherit;
                color: inherit;
            }}
            .tabcontent {{
                display: none;
                padding: 20px;
            }}
            .dashboard-table {{
                width: 100%;
                border-collapse: collapse;
                font-family: inherit;
                color: inherit;
            }}
            .dashboard-table th, .dashboard-table td {{
                border: 1px solid #e0e0e0;
                padding: 8px 10px;
            }}
            .dashboard-table thead th {{
                background: {rgba(COLORS['GRAY'], 0.15)};
                text-align: left;
            }}
            .dashboard-table .group-row td {{
                background: {rgba(COLORS['GREEN'], 0.08)};
            }}
            .signal-dot {{
                display: inline-block;
                width: 12px;
                height: 12px;
                border-radius: 50%;
                vertical-align: middle;
            }}
            .center {{ text-align: center; }}
            .test-list {{
                list-style-type: none;
                padding: 0;
                margin: 0 0 20px 0;
                background-color: #f0f0f0;
                overflow-x: auto;
                white-space: nowrap;
            }}
            .test-list li {{
                display: inline-block;
                padding: 8px 15px;
                cursor: pointer;
                background-color: #ddd;
                margin-right: 5px;
                border-radius: 4px;
                font-family: inherit;
                color: inherit;
            }}
            .test-block {{
                margin-top: 20px;
            }}
            h1, h2, h3, h4, h5, h6, p, table, td, th {{
                color: inherit;
                font-family: inherit;
            }}
            .report-title {{
                font-size: 1em; /* inherits from .report-header */
                line-height: 1;
                margin: 0;
                font-weight: 700;
            }}
            .brand-gradient {{
                /* Fallback solid color */
                color: {COLORS['GREEN']};
                background: linear-gradient(90deg, #21aa82 0%, #1acf52 100%);
                -webkit-background-clip: text;
                background-clip: text;
                color: transparent;
                -webkit-text-fill-color: transparent;
            }}
            .report-header {{
                display: flex;
                align-items: center;
                gap: 12px;
                margin: 6px 0 16px 0;
                font-size: 36px; /* controls both logo and title sizing */
                line-height: 1;
            }}
            .brand-logo {{ height: 1em; width: auto; display: block; }}
        </style>
        </head><body>

        {header_html}
        {tab_headers}
        {group_tabs}

        <script>
        function openGroup(evt, groupId) {{
            let i, content, tabs;
            content = document.getElementsByClassName("tabcontent");
            for (i = 0; i < content.length; i++) {{
                content[i].style.display = "none";
            }}
            tabs = document.getElementsByClassName("tablink");
            for (i = 0; i < tabs.length; i++) {{
                tabs[i].style.backgroundColor = "";
            }}
            document.getElementById(groupId).style.display = "block";
            evt.currentTarget.style.backgroundColor = "#ccc";

            // Auto-open signal summary when group opens
            let groupIdParts = groupId.split("_");
            let summaryBlock = document.getElementById("signal_summary_" + groupIdParts[1]);
            if (summaryBlock) {{
                let testBlocks = document.getElementsByClassName("test-block");
                for (let i = 0; i < testBlocks.length; i++) {{
                    testBlocks[i].style.display = "none";
                }}
                summaryBlock.style.display = "block";
            }}
        }}

        function showTest(testId) {{
            let blocks = document.getElementsByClassName("test-block");
            for (let i = 0; i < blocks.length; i++) {{
                blocks[i].style.display = "none";
            }}
            let block = document.getElementById(testId);
            if (block) {{
                block.style.display = "block";
            }}
        }}

        document.getElementsByClassName("tablink")[0].click();
        </script>
        </body></html>
        """
