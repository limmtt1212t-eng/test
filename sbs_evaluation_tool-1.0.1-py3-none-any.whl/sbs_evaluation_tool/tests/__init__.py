"""Test suite and metric implementations for SBS Evaluation Tool.

This package is intentionally shipped as part of the library so that
M0–M5 tests can be imported as `tests.mX_...` from user code.
"""
