# core import
from ..core.base_test import BaseModelTest
from ..core.styles import COLORS, STATUS_COLORS
from ..core.data_utils import ensure_config,  split_frames, get_features
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64
# stat imports
from tqdm import tqdm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm
from typing import Optional, List, Dict
import itertools
import concurrent.futures
from joblib import Parallel, delayed
from scipy.stats import chi2, contingency
from matplotlib.patches import Patch
from ._visual_utils import apply_standard_axis_style, figure_to_base64
import logging
logger = logging.getLogger(__name__)


def _aggregate_lr_test_signal(red_share: float, yel_share: float) -> str:
    """Aggregate per-factor LR-test results into a final traffic-light signal."""
    if red_share >= 0.10:
        return 'red'
    if (0.0 < red_share < 0.10) or (yel_share >= 0.10):
        return 'orange'
    return 'green'


def _aggregate_lr_distribution_signals(signals: list[str]) -> str:
    """Aggregate family-level LR signals into one final test signal."""
    considered = [signal for signal in signals if signal in {"green", "orange", "red"}]
    if not considered:
        return "blue"
    if any(signal == "orange" for signal in considered):
        return "orange"
    if any(signal == "green" for signal in considered):
        return "green"
    return "red"


# NEW
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import ensure_config

# === helpers for M3 ===
# _frames_from_cfg, _numeric_features_from_cfg, _categorical_features_from_cfg removed
# Use split_frames from core.data_utils and getattr(model_config.columns, ...) instead

def _vif_numpy(X_values: np.ndarray, i: int) -> float:
    """Быстрый расчёт VIF через numpy lstsq (без вызова statsmodels OLS на каждый признак)."""
    y = X_values[:, i]
    X_rest = np.delete(X_values, i, axis=1)
    try:
        coeffs, _, _, _ = np.linalg.lstsq(X_rest, y, rcond=None)
        y_hat = X_rest @ coeffs
        ss_res = float(np.sum((y - y_hat) ** 2))
        ss_tot = float(np.sum((y - y.mean()) ** 2))
        if ss_tot <= 0:
            return 1.0
        r2 = 1.0 - ss_res / ss_tot
        return 1.0 / (1.0 - r2) if r2 < 1.0 else np.inf
    except Exception:
        return np.inf


def cramers_v(x: pd.Series, y: pd.Series) -> float:
    """
    Вычисляет коэффициент Крамера V для двух категориальных переменных.
    
    Параметры:
        x, y: категориальные Series
    
    Возвращает:
        float: значение Cramer's V (0..1)
    """
    confusion_matrix = pd.crosstab(x, y)
    chi2_stat = contingency.chi2_contingency(confusion_matrix)[0]
    n = confusion_matrix.sum().sum()
    min_dim = min(confusion_matrix.shape[0], confusion_matrix.shape[1]) - 1
    if min_dim == 0 or n == 0:
        return 0.0
    return np.sqrt(chi2_stat / (n * min_dim))

def correlation_ratio(categories: pd.Series, values: pd.Series) -> float:
    """
    Вычисляет correlation ratio (eta) между категориальной и численной переменной.
    
    Параметры:
        categories: категориальная переменная
        values: численная переменная
    
    Возвращает:
        float: correlation ratio (0..1)
    """
    categories = pd.Categorical(categories)
    values = pd.to_numeric(values, errors='coerce')
    
    # Удаляем NaN
    valid_mask = ~values.isna()
    categories = categories[valid_mask]
    values = values[valid_mask]
    
    if len(values) < 2:
        return 0.0
    
    # Общая вариация
    overall_mean = values.mean()
    ss_total = ((values - overall_mean) ** 2).sum()
    
    if ss_total == 0:
        return 0.0
    
    # Вариация между группами
    ss_between = 0.0
    for cat in categories.categories:
        cat_values = values[categories == cat]
        if len(cat_values) > 0:
            cat_mean = cat_values.mean()
            ss_between += len(cat_values) * ((cat_mean - overall_mean) ** 2)
    
    eta_squared = ss_between / ss_total
    return np.sqrt(max(0.0, min(1.0, eta_squared)))

def target_encode_categorical(
    df_train: pd.DataFrame,
    df_test: pd.DataFrame,
    cat_features: list,
    target_col: str,
    smoothing: float = 10.0
) -> tuple:
    """
    Применяет target encoding с smoothing к категориальным признакам.
    
    Параметры:
        df_train: обучающая выборка
        df_test: тестовая выборка
        cat_features: список категориальных признаков
        target_col: название целевой переменной
        smoothing: сила регуляризации (m в формуле smoothing)
    
    Возвращает:
        tuple: (df_train_encoded, df_test_encoded, feature_map)
               feature_map: dict {encoded_name: original_name}
    """
    if not cat_features:
        return df_train.copy(), df_test.copy(), {}
    
    df_train_enc = df_train.copy()
    df_test_enc = df_test.copy()
    feature_map = {}
    
    # Глобальное среднее таргета
    global_mean = df_train[target_col].mean()
    
    for cat_feat in cat_features:
        # Вычисляем статистику по каждой категории
        stats = df_train.groupby(cat_feat)[target_col].agg(['mean', 'count'])
        
        # Применяем smoothing: (count * mean + m * global) / (count + m)
        stats['smoothed_mean'] = (
            (stats['count'] * stats['mean'] + smoothing * global_mean) / 
            (stats['count'] + smoothing)
        )
        
        # Создаем маппинг
        encoding_map = stats['smoothed_mean'].to_dict()
        
        # Применяем к train и test
        encoded_name = f"{cat_feat}_encoded"
        df_train_enc[encoded_name] = df_train_enc[cat_feat].map(encoding_map).fillna(global_mean)
        df_test_enc[encoded_name] = df_test_enc[cat_feat].map(encoding_map).fillna(global_mean)
        
        # Удаляем исходную категориальную колонку
        df_train_enc = df_train_enc.drop(columns=[cat_feat])
        df_test_enc = df_test_enc.drop(columns=[cat_feat])
        
        feature_map[encoded_name] = cat_feat
    
    return df_train_enc, df_test_enc, feature_map


def _corr_heatmap_buf(corr_df: pd.DataFrame) -> str:
    """Return base64 PNG of a correlation heatmap for given correlation DataFrame."""
    fig, ax = plt.subplots(figsize=(max(6, len(corr_df) * 0.4), max(4, len(corr_df) * 0.4)))
    im = ax.imshow(corr_df.values, cmap='RdBu_r', vmin=-1, vmax=1)
    ax.set_xticks(np.arange(len(corr_df.columns)))
    ax.set_yticks(np.arange(len(corr_df.index)))
    ax.set_xticklabels(corr_df.columns, rotation=45, ha='right')
    ax.set_yticklabels(corr_df.index)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode()


class M31_CorrelationOverviewTest(BaseModelTest):
    """Compute correlations among numeric and categorical features and between features and target.

    For numeric-numeric: Pearson correlation
    For categorical-categorical: Cramer's V
    For numeric-categorical: Correlation ratio (eta)

    Outputs:
      - table of strongly correlated feature pairs and a heatmap
      - table of feature-target correlations (sorted) and list of strongly correlated features

    Works for both classification (binary target) and regression (continuous target).
    """

    def __init__(self, feat_corr_thresh: float = 0.8, target_corr_thresh: float = 0.3):
        super().__init__('M 3.1', 'Feature-Target Correlation Overview')
        self.feat_corr_thresh = float(feat_corr_thresh)
        self.target_corr_thresh = float(target_corr_thresh)

    def _ensure_numeric_target(self, s: pd.Series) -> pd.Series:
        # try numeric conversion, otherwise map categories to codes
        if pd.api.types.is_numeric_dtype(s):
            return s.astype(float)
        try:
            return pd.to_numeric(s, errors='raise').astype(float)
        except Exception:
            # fallback to categorical codes
            return pd.Categorical(s).codes.astype(float)

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        outputs: Dict[str, str] = {}

        # Per requirement: this test is informational; force INFO (blue) signal
        self.test_signal = 'blue'

        # Получаем численные и категориальные признаки
        num_features = getattr(cfg.columns, 'numeric_features', []) or []
        cat_features = getattr(cfg.columns, 'categorical_features', []) or []
        # ensure lists
        if isinstance(num_features, str): num_features = [num_features]
        if isinstance(cat_features, str): cat_features = [cat_features]
        # unique
        num_features = list(dict.fromkeys(num_features))
        cat_features = list(dict.fromkeys(cat_features))
        all_features = num_features + cat_features
        
        if not all_features:
            return {'error': 'No features provided in config (numeric_features or categorical_features)'}

        missing = [c for c in all_features if c not in df.columns]
        if missing:
            return {'error': f'Missing features in dataframe: {missing}'}

        X = df[all_features].copy()
        # drop rows where all features are NaN
        X = X.dropna(how='all')

        # === Feature-Feature correlations (optimized) ===
        n_features = len(all_features)
        cat_features_set = set(cat_features)
        corr_matrix = pd.DataFrame(np.nan, index=all_features, columns=all_features)
        np.fill_diagonal(corr_matrix.values, 1.0)
        ff_pairs = []

        # 1. Numeric-Numeric: single vectorized call instead of O(F²) loop
        if len(num_features) >= 2:
            X_num = X[num_features].apply(pd.to_numeric, errors='coerce')
            num_corr = X_num.corr()
            corr_matrix.loc[num_features, num_features] = num_corr.values
            for i2, j2 in itertools.combinations(range(len(num_features)), 2):
                f1, f2 = num_features[i2], num_features[j2]
                corr_val = float(corr_matrix.loc[f1, f2])
                if not np.isnan(corr_val) and abs(corr_val) >= self.feat_corr_thresh:
                    ff_pairs.append({'feature_1': f1, 'feature_2': f2,
                                     'corr': corr_val, 'type': 'num-num'})

        # 2. Cat-cat and mixed pairs: parallelized via ThreadPoolExecutor
        mixed_pairs = [
            (all_features[i], all_features[j])
            for i, j in itertools.combinations(range(n_features), 2)
            if not (all_features[i] not in cat_features_set
                    and all_features[j] not in cat_features_set)
        ]

        def _compute_pair(feat1, feat2):
            is_num1 = feat1 not in cat_features_set
            is_num2 = feat2 not in cat_features_set
            try:
                valid = (~X[feat1].isna()) & (~X[feat2].isna())
                if valid.sum() < 3:
                    return feat1, feat2, 0.0, is_num1, is_num2
                if not is_num1 and not is_num2:
                    val = cramers_v(X.loc[valid, feat1], X.loc[valid, feat2])
                else:
                    nf, cf = (feat1, feat2) if is_num1 else (feat2, feat1)
                    val = correlation_ratio(X.loc[valid, cf], X.loc[valid, nf])
            except Exception:
                val = 0.0
            return feat1, feat2, val, is_num1, is_num2

        if mixed_pairs:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                futures_map = {
                    executor.submit(_compute_pair, f1, f2): (f1, f2)
                    for f1, f2 in mixed_pairs
                }
                for future in tqdm(concurrent.futures.as_completed(futures_map),
                                   total=len(mixed_pairs),
                                   desc="Корреляции (cat/mixed пары)"):
                    f1, f2, corr_val, is_num1, is_num2 = future.result()
                    corr_matrix.loc[f1, f2] = corr_val
                    corr_matrix.loc[f2, f1] = corr_val
                    if abs(corr_val) >= self.feat_corr_thresh:
                        ff_pairs.append({
                            'feature_1': f1, 'feature_2': f2, 'corr': float(corr_val),
                            'type': f"{'num' if is_num1 else 'cat'}-{'num' if is_num2 else 'cat'}"
                        })

        if ff_pairs:
            ff_df = pd.DataFrame(sorted(ff_pairs, key=lambda r: -abs(r['corr'])))
            outputs['ff_pairs_table'] = '<h4>Strongly correlated feature pairs</h4>' + ff_df.to_html(index=False, float_format='%.4f')
            # heatmap for involved features
            involved = sorted(set(ff_df['feature_1'].tolist() + ff_df['feature_2'].tolist()))
            sub_corr = corr_matrix.loc[involved, involved]
            heat_b64 = _corr_heatmap_buf(sub_corr)
            outputs['ff_heatmap'] = f'<h4>Correlation heatmap (features)</h4><img src="data:image/png;base64,{heat_b64}"/>'
        else:
            outputs['ff_pairs_table'] = '<p>No strongly correlated feature pairs found above threshold.</p>'

        # === Feature-Target correlations ===
        target_col = getattr(cfg.columns, 'target_column', None)
        if target_col is None or target_col not in df.columns:
            outputs['ft_info'] = '<p>Target column not provided or missing - skipping feature-target correlations.</p>'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return outputs

        tseries = self._ensure_numeric_target(df[target_col].loc[X.index])
        ft_corrs: dict = {}

        # Numeric features: single vectorized corrwith
        if num_features:
            X_num_ft = X[num_features].apply(pd.to_numeric, errors='coerce')
            valid_mask = ~tseries.isna()
            num_corrs = X_num_ft[valid_mask].corrwith(tseries[valid_mask])
            for feat in num_features:
                ft_corrs[feat] = float(num_corrs.get(feat, float('nan')))

        # Categorical features: parallel
        def _ft_corr_cat(feat):
            try:
                valid = (~X[feat].isna()) & (~tseries.isna())
                if valid.sum() < 3:
                    return feat, float('nan')
                return feat, float(correlation_ratio(X.loc[valid, feat], tseries[valid]))
            except Exception:
                return feat, float('nan')

        if cat_features:
            with concurrent.futures.ThreadPoolExecutor() as executor:
                for feat, val in tqdm(
                    executor.map(_ft_corr_cat, cat_features),
                    total=len(cat_features),
                    desc="Корреляция категориальных признаков с таргетом"
                ):
                    ft_corrs[feat] = val

        ft_df = pd.DataFrame([
            {
                'feature': k, 
                'corr_with_target': float(v),
                'type': 'numeric' if k in num_features else 'categorical'
            } 
            for k, v in ft_corrs.items()
        ])
        ft_df['abs_corr'] = ft_df['corr_with_target'].abs()
        ft_df = ft_df.sort_values('abs_corr', ascending=False).drop(columns=['abs_corr'])
        
        outputs['ft_table'] = (
            f'<h4>Feature - Target correlations (sorted)</h4>'
            f'<p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>'
            f'<p><i>Для численных используется Pearson correlation, для категориальных - correlation ratio (eta)</i></p>'
            + ft_df.to_html(index=False, float_format='%.4f')
        )

        # top-10 features by absolute correlation with target
        top10 = ft_df.head(10)
        top10_html = '<h5>Top 10 features by |corr_with_target|</h5>' + top10.to_html(index=False, float_format='%.4f')

        strong_ft = ft_df[ft_df['corr_with_target'].abs() >= self.target_corr_thresh]
        if not strong_ft.empty:
            outputs['strong_ft'] = ('<h4>Features strongly correlated with target</h4>'
                                    + strong_ft.to_html(index=False, float_format='%.4f')
                                    + top10_html)
        else:
            outputs['strong_ft'] = ('<p>No features exceed the target correlation threshold.</p>'
                                    + top10_html)

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return outputs


class M32_LikelihoodRatioTest(BaseModelTest):
    """Likelihood-ratio test by factor under multiple GLM families."""

    def __init__(self, features: Optional[list] = None, smoothing: float = 10.0):
        super().__init__('M 3.2', 'Likelihood-ratio tests (per factor)')
        self.features = features
        self.smoothing = smoothing

    def _collect_feature_list(self, cfg):
        if self.features:
            return list(dict.fromkeys([f for f in self.features if f]))
        feats = []
        if getattr(cfg.columns, 'numeric_features', None):
            feats.extend(list(cfg.columns.numeric_features))
        if getattr(cfg.columns, 'categorical_features', None):
            feats.extend(list(cfg.columns.categorical_features))
        return list(dict.fromkeys([f for f in feats if f]))

    @staticmethod
    def _p_to_flag(p_value: float) -> str:
        if p_value is None or not np.isfinite(p_value):
            return 'gray'
        if p_value > 0.10:
            return 'red'
        if p_value > 0.05:
            return 'orange'
        return 'green'

    def _family_specs(self):
        return [
            {
                'key': 'gaussian',
                'label': 'Gaussian',
                'family': sm.families.Gaussian(),
                'description': 'Gaussian GLM with identity link.',
            },
            {
                'key': 'poisson',
                'label': 'Poisson',
                'family': sm.families.Poisson(),
                'description': 'Poisson GLM for non-negative targets.',
            },
            {
                'key': 'gamma',
                'label': 'Gamma',
                'family': sm.families.Gamma(link=sm.families.links.Log()),
                'description': 'Gamma GLM with log link for strictly positive targets.',
            },
        ]

    def _valid_mask_for_family(self, y: pd.Series, family_key: str) -> pd.Series:
        y_num = pd.to_numeric(y, errors='coerce')
        if family_key == 'poisson':
            return y_num.notna() & np.isfinite(y_num) & (y_num >= 0)
        if family_key == 'gamma':
            return y_num.notna() & np.isfinite(y_num) & (y_num > 0)
        return y_num.notna() & np.isfinite(y_num)

    def _build_histogram_html(self, res_df: pd.DataFrame, family_label: str) -> str:
        plot_df = res_df.copy()
        plot_df = plot_df.sort_values(by=['p_test', 'p_train', 'feature'], ascending=[True, True, True], na_position='last')
        if plot_df.empty:
            return '<p>No valid factor-level results are available for this chart.</p>'

        top_n = min(50, len(plot_df))
        plot_df = plot_df.head(top_n)
        plot_df['flag_test'] = plot_df['p_test'].apply(self._p_to_flag)
        test_p = plot_df['p_test'].fillna(1.0).clip(0, 1)
        train_p = plot_df['p_train'].fillna(1.0).clip(0, 1)

        color_map = {
            'green': STATUS_COLORS['green'],
            'orange': STATUS_COLORS['orange'],
            'red': STATUS_COLORS['red'],
            'gray': STATUS_COLORS['gray'],
        }
        fig_w = max(8.0, min(4.0 + 0.55 * len(plot_df), 28.0))
        fig, ax = plt.subplots(figsize=(fig_w, 5.4))
        x = np.arange(len(plot_df))
        width = 0.38
        ax.bar(x - width / 2, train_p, width, label='Train (p)', color=COLORS['GRAY'])
        ax.bar(x + width / 2, test_p, width, label='Test (p)', color=[color_map.get(flag, STATUS_COLORS['gray']) for flag in plot_df['flag_test']])
        ax.axhline(0.10, color=STATUS_COLORS['orange'], linestyle='--', linewidth=1.2, label='Yellow threshold = 0.10')
        ax.axhline(0.05, color=STATUS_COLORS['green'], linestyle='--', linewidth=1.2, label='Green threshold = 0.05')
        ax.set_xticks(x)
        ax.set_xticklabels(plot_df['feature'], rotation=55, ha='right')
        ax.set_ylim(0, 1)
        apply_standard_axis_style(
            ax,
            title=f'{family_label}: LR test by factor',
            ylabel='p-value',
            legend_loc=None,
        )
        legend_patches = [
            Patch(facecolor=COLORS['GRAY'], label='Train (p)'),
            Patch(facecolor=color_map['green'], label='Test: GREEN (<= 0.05)'),
            Patch(facecolor=color_map['orange'], label='Test: YELLOW (0.05-0.10)'),
            Patch(facecolor=color_map['red'], label='Test: RED (> 0.10)'),
        ]
        ax.legend(handles=legend_patches, loc='upper right', frameon=False)
        fig.tight_layout(pad=1.1)
        encoded = figure_to_base64(fig)
        return f'<img src="data:image/png;base64,{encoded}" style="display:block; width:100%; max-width:1100px; height:auto;">'

    def _build_family_summary(self, signal: str, total: int, green_cnt: int, orange_cnt: int, red_cnt: int) -> str:
        label = {'green': 'GREEN', 'orange': 'YELLOW', 'red': 'RED', 'blue': 'INFO'}.get(signal, signal.upper())
        return f"""
        <div style="margin:12px 0 16px 0;">
            <p><b>Family signal:</b> <span style="color:{signal}; font-weight:bold;">{label}</span></p>
            <table border="1" cellpadding="5" cellspacing="0">
                <tr><th>Status</th><th>Count</th><th>Share</th></tr>
                <tr><td style="color:green; font-weight:bold;">GREEN</td><td>{green_cnt}</td><td>{green_cnt}/{total if total > 0 else 1}</td></tr>
                <tr><td style="color:orange; font-weight:bold;">YELLOW</td><td>{orange_cnt}</td><td>{orange_cnt}/{total if total > 0 else 1}</td></tr>
                <tr><td style="color:red; font-weight:bold;">RED</td><td>{red_cnt}</td><td>{red_cnt}/{total if total > 0 else 1}</td></tr>
            </table>
        </div>
        """

    def _run_family_lr(
        self,
        family_spec: dict,
        df_train: pd.DataFrame,
        df_test: pd.DataFrame,
        encoded_features: list[str],
        target_col: str,
    ) -> dict:
        split_frames = {'train': df_train, 'test': df_test}
        split_stats = {}

        for split_name, frame in split_frames.items():
            if frame.empty:
                split_stats[split_name] = {'present': False}
                continue

            X_raw = frame[encoded_features].apply(pd.to_numeric, errors='coerce')
            y_raw = pd.to_numeric(frame[target_col], errors='coerce')
            valid_mask = self._valid_mask_for_family(y_raw, family_spec['key']) & np.isfinite(X_raw).all(axis=1)
            if valid_mask.sum() < max(8, len(encoded_features) + 2):
                split_stats[split_name] = {'present': False}
                continue

            X_valid = X_raw.loc[valid_mask].copy()
            y_valid = y_raw.loc[valid_mask].copy()
            try:
                X_full = sm.add_constant(X_valid, has_constant='add')
                fitted = sm.GLM(y_valid, X_full, family=family_spec['family']).fit()
                split_stats[split_name] = {
                    'present': True,
                    'X': X_valid,
                    'y': y_valid,
                    'llf_full': float(fitted.llf),
                    'n_obs': int(len(y_valid)),
                }
            except Exception:
                split_stats[split_name] = {'present': False}

        rows = []
        for feature in encoded_features:
            row = {
                'feature': feature,
                'distribution': family_spec['label'],
                'df': 1,
                'W_train': float('nan'),
                'p_train': float('nan'),
                'W_test': float('nan'),
                'p_test': float('nan'),
            }
            for split_name in ('train', 'test'):
                info = split_stats.get(split_name, {})
                if not info.get('present'):
                    continue
                keep_cols = [col for col in encoded_features if col != feature]
                if not keep_cols:
                    continue
                try:
                    X_red = sm.add_constant(info['X'][keep_cols], has_constant='add')
                    fitted_red = sm.GLM(info['y'], X_red, family=family_spec['family']).fit()
                    stat = 2.0 * (info['llf_full'] - float(fitted_red.llf))
                    p_value = float(chi2.sf(stat, 1)) if np.isfinite(stat) else float('nan')
                except Exception:
                    stat = float('nan')
                    p_value = float('nan')
                row[f'W_{split_name}'] = float(stat)
                row[f'p_{split_name}'] = float(p_value)
            rows.append(row)

        res_df = pd.DataFrame(rows)
        if res_df.empty:
            return {
                'signal': 'blue',
                'panel_html': f"""
                <p><b>Distribution:</b> {family_spec['label']}</p>
                <p><i>{family_spec['description']}</i></p>
                <p>No valid observations were available for this distribution.</p>
                """,
            }

        res_df['flag_test'] = res_df['p_test'].apply(self._p_to_flag)
        valid_flags = res_df['flag_test'].isin(['green', 'orange', 'red'])
        total = int(valid_flags.sum())
        red_cnt = int((res_df.loc[valid_flags, 'flag_test'] == 'red').sum())
        orange_cnt = int((res_df.loc[valid_flags, 'flag_test'] == 'orange').sum())
        green_cnt = int((res_df.loc[valid_flags, 'flag_test'] == 'green').sum())
        red_share = (red_cnt / total) if total > 0 else 0.0
        orange_share = (orange_cnt / total) if total > 0 else 0.0
        family_signal = _aggregate_lr_test_signal(red_share, orange_share) if total > 0 else 'blue'

        res_df = res_df.sort_values(by=['p_test', 'p_train', 'feature'], ascending=[True, True, True], na_position='last')
        hist_html = self._build_histogram_html(res_df, family_spec['label'])
        table_html = res_df.to_html(index=False, float_format='%.6f')
        summary_html = self._build_family_summary(family_signal, total, green_cnt, orange_cnt, red_cnt)

        train_n = split_stats.get('train', {}).get('n_obs', 0)
        test_n = split_stats.get('test', {}).get('n_obs', 0)
        panel_html = f"""
        <div>
            <p><b>Distribution:</b> {family_spec['label']}</p>
            <p><i>{family_spec['description']}</i></p>
            <p><i>Train observations used: {train_n}. Test observations used: {test_n}.</i></p>
            {summary_html}
            <h4>Factor-level chart</h4>
            {hist_html}
            <h4>LR Parameter Table</h4>
            {table_html}
        </div>
        """
        return {'signal': family_signal, 'panel_html': panel_html}

    def _build_tabs_html(self, panels: list[dict]) -> str:
        root_id = f"m32-tabs-{id(self)}"
        button_html = []
        panel_html = []
        for idx, panel in enumerate(panels):
            active = 'true' if idx == 0 else 'false'
            display = 'block' if idx == 0 else 'none'
            signal_color = STATUS_COLORS.get(panel['signal'], panel['signal'])
            button_html.append(
                f"""
                <button type="button"
                        data-tab-target="{root_id}-panel-{idx}"
                        data-root-id="{root_id}"
                        aria-selected="{active}"
                        style="padding:8px 14px; border:1px solid #d9dee8; background:#fff; cursor:pointer; border-radius:8px; color:{signal_color}; font-weight:600;">
                    {panel['label']}
                </button>
                """
            )
            panel_html.append(
                f"""
                <div id="{root_id}-panel-{idx}" data-tab-panel="{root_id}" style="display:{display}; margin-top:16px;">
                    {panel['html']}
                </div>
                """
            )

        script = f"""
        <script>
        (function() {{
            var root = document.getElementById('{root_id}');
            if (!root) return;
            var buttons = root.querySelectorAll('button[data-tab-target]');
            var panels = root.querySelectorAll('div[data-tab-panel="{root_id}"]');
            buttons.forEach(function(btn) {{
                btn.addEventListener('click', function() {{
                    var targetId = btn.getAttribute('data-tab-target');
                    buttons.forEach(function(other) {{ other.setAttribute('aria-selected', 'false'); }});
                    panels.forEach(function(panel) {{ panel.style.display = 'none'; }});
                    btn.setAttribute('aria-selected', 'true');
                    var target = document.getElementById(targetId);
                    if (target) target.style.display = 'block';
                }});
            }});
        }})();
        </script>
        """
        return f"""
        <div id="{root_id}">
            <div style="display:flex; gap:8px; flex-wrap:wrap; margin:14px 0 8px 0;">
                {''.join(button_html)}
            </div>
            {''.join(panel_html)}
        </div>
        {script}
        """

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)

        sample_col = getattr(cfg.columns, 'sample_column', None)
        target_col = getattr(cfg.columns, 'target_column', None)
        if sample_col is None or sample_col not in df.columns:
            return {'error': 'sample_column missing in config or dataframe'}
        if target_col is None or target_col not in df.columns:
            return {'error': 'target_column missing in config or dataframe'}

        all_features = self._collect_feature_list(cfg)
        cat_feats = set(getattr(cfg.columns, 'categorical_features', []) or [])
        numeric_features = [feature for feature in all_features if feature in df.columns and feature not in cat_feats]
        skipped_categorical = [feature for feature in all_features if feature in cat_feats and feature in df.columns]

        if not numeric_features:
            return {'error': 'No numeric features available for the LR test.'}

        work_cols = numeric_features + [target_col, sample_col]
        df_work = df[work_cols].copy()
        train_mask = df_work[sample_col].astype(str).str.lower() == 'train'
        test_mask = df_work[sample_col].astype(str).str.lower() == 'test'
        df_train = df_work.loc[train_mask, numeric_features + [target_col]].copy()
        df_test = df_work.loc[test_mask, numeric_features + [target_col]].copy()

        family_panels = []
        family_signals = []
        for family_spec in self._family_specs():
            family_result = self._run_family_lr(
                family_spec=family_spec,
                df_train=df_train,
                df_test=df_test,
                encoded_features=numeric_features,
                target_col=target_col,
            )
            family_panels.append({
                'label': family_spec['label'],
                'signal': family_result['signal'],
                'html': family_result['panel_html'],
            })
            family_signals.append(family_result['signal'])

        self.test_signal = _aggregate_lr_distribution_signals(family_signals)
        signal_label = {'green': 'GREEN', 'orange': 'YELLOW', 'red': 'RED', 'blue': 'INFO'}.get(self.test_signal, self.test_signal.upper())
        skipped_html = ''
        if skipped_categorical:
            skipped_html = (
                '<p><i>Categorical features are intentionally skipped in this version of the test: '
                + ', '.join(skipped_categorical)
                + '.</i></p>'
            )

        combined_html = f"""
        <h4>Likelihood-ratio test by distribution</h4>
        <p><b>Final Signal:</b> <span style="color:{self.test_signal}; font-weight:bold;">{signal_label}</span></p>
        <p><i>Numeric features evaluated: {len(numeric_features)}.</i></p>
        {skipped_html}
        {self._build_tabs_html(family_panels)}
        """

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {'combined': combined_html}


class M33_MulticollinearityTest(BaseModelTest):
    """
    VIF test с поддержкой численных и категориальных признаков.
    Категориальные признаки кодируются через target encoding с smoothing вместо one-hot.
    """
    def __init__(self, test_num='M 3.3', test_name='Multicollinearity Test', smoothing: float = 10.0):
        super().__init__(test_num, test_name)
        self.smoothing = smoothing

    def compute_vif(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Вычисляет VIF для каждого признака.
        Использует numpy lstsq (быстрее statsmodels) и joblib для параллелизма.
        При N > 50 000 строк автоматически сэмплирует данные (VIF — свойство
        структуры признаков, не зависит от числа строк при достаточном объёме).
        """
        MAX_ROWS = 50_000
        X_samp = df
        if len(df) > MAX_ROWS:
            X_samp = df.sample(n=MAX_ROWS, random_state=42)
            logger.info(f"VIF: используется выборка {MAX_ROWS} строк из {len(df)}")

        X_np = sm.add_constant(X_samp).values.astype(float)
        feature_names = list(df.columns)
        indices = list(range(1, X_np.shape[1]))  # skip const at index 0

        vif_values = Parallel(n_jobs=-1, backend="threading")(
            delayed(_vif_numpy)(X_np, i)
            for i in tqdm(indices, desc="Calculating VIF")
        )
        return pd.DataFrame({"Feature": feature_names, "VIF": vif_values})

    def assign_flag(self, vif: float) -> str:
        if vif > 10:
            return "red"
        elif vif > 5:
            return "orange"
        else:
            return "green"

    def compute_signal(self, flags: List[str]) -> str:
        if "red" in flags:
            return "red"
        orange_count = flags.count("orange")
        total = len(flags)
        if orange_count / total > 0.2:
            return "orange"
        return "green"

    def plot_vif_comparison(self, merged: pd.DataFrame) -> str:
        x = np.arange(len(merged))
        fig, ax = plt.subplots(figsize=(12, 8))
        bar_width = 0.4
        ax.bar(x - bar_width / 2, merged["VIF_train"], width=bar_width, label="Train", color=COLORS['BLUE'])
        ax.bar(x + bar_width / 2, merged["VIF_test"], width=bar_width, label="Test", color=COLORS['EMERALD'])
        ax.set_xticks(x)
        ax.set_xticklabels(merged["Feature"], rotation=45, ha="right")
        apply_standard_axis_style(ax, title="VIF Comparison (Train vs Test)", ylabel="VIF")
        ax.grid(True, linestyle='--', linewidth=0.5)
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # валидируем конфиг и режем выборки
        cfg = ensure_config(config, df)
        df_train, df_test, _ = split_frames(df, cfg)
        target_col = cfg.columns.target_column
        
        # Получаем численные и категориальные признаки
        num_features = getattr(cfg.columns, 'numeric_features', []) or []
        cat_features = getattr(cfg.columns, 'categorical_features', []) or []
        # ensure lists
        if isinstance(num_features, str): num_features = [num_features]
        if isinstance(cat_features, str): cat_features = [cat_features]
        # unique
        num_features = list(dict.fromkeys(num_features))
        cat_features = list(dict.fromkeys(cat_features))
        all_features = num_features + cat_features
        
        if not all_features:
            raise ValueError("Не указаны признаки в конфиге (numeric_features или categorical_features)")

        # формируем X_train / X_test
        missing_tr = [c for c in all_features if c not in df_train.columns]
        missing_te = [c for c in all_features if c not in df_test.columns]
        if missing_tr or missing_te:
            raise ValueError(f"Отсутствуют фичи в train/test: train_missing={missing_tr}, test_missing={missing_te}")

        # Добавляем target в датафреймы для кодирования
        df_train_with_target = df_train[all_features + [target_col]].copy()
        df_test_with_target = df_test[all_features + [target_col]].copy()

        # Приводим численные к numeric и проверяем NaN
        for X, name in [(df_train_with_target, "train"), (df_test_with_target, "test")]:
            for col in num_features:
                if not pd.api.types.is_numeric_dtype(X[col]):
                    try:
                        X[col] = pd.to_numeric(X[col], errors='raise')
                    except Exception:
                        raise ValueError(f"Колонка {col} в {name} не числовая и не конвертируется в numeric.")
            # Проверяем NaN во всех признаках
            if X[all_features].isnull().any().any():
                bad = X[all_features].columns[X[all_features].isnull().any()].tolist()
                raise ValueError(f"В {name} обнаружены пропуски в колонках {bad}. "
                                f"Очистите/импутируйте данные для расчёта VIF.")

        # Применяем target encoding к категориальным признакам
        df_train_enc, df_test_enc, feature_map = target_encode_categorical(
            df_train_with_target,
            df_test_with_target,
            cat_features,
            target_col,
            smoothing=self.smoothing
        )
        
        # Убираем target из закодированных датафреймов
        X_train = df_train_enc.drop(columns=[target_col])
        X_test = df_test_enc.drop(columns=[target_col])
        
        # Создаем обратный маппинг для отображения
        reverse_feature_map = {v: v for v in num_features}  # numeric features map to themselves
        reverse_feature_map.update(feature_map)  # add categorical mappings

        # считаем VIF
        vif_train = self.compute_vif(X_train)
        vif_test  = self.compute_vif(X_test) if len(X_test) > 0 else None

        # Добавляем колонку типа признака
        def get_feature_type(feat_name):
            original = reverse_feature_map.get(feat_name, feat_name)
            if original in num_features:
                return 'numeric'
            elif original in cat_features:
                return 'categorical'
            else:
                return 'unknown'
        
        vif_train['Type'] = vif_train['Feature'].apply(get_feature_type)
        vif_train['Original_Feature'] = vif_train['Feature'].apply(lambda x: reverse_feature_map.get(x, x))

        if vif_test is not None:
            vif_test['Type'] = vif_test['Feature'].apply(get_feature_type)
            vif_test['Original_Feature'] = vif_test['Feature'].apply(lambda x: reverse_feature_map.get(x, x))
            
            merged = pd.merge(
                vif_train[['Feature', 'Original_Feature', 'Type', 'VIF']], 
                vif_test[['Feature', 'VIF']], 
                on="Feature", 
                how="inner", 
                suffixes=("_train", "_test")
            )
            if merged.empty:
                merged = pd.merge(
                    vif_train[['Feature', 'Original_Feature', 'Type', 'VIF']], 
                    vif_test[['Feature', 'VIF']], 
                    on="Feature", 
                    how="outer", 
                    suffixes=("_train", "_test")
                )
            
            # нормализуем бесконечности/NaN
            merged["VIF_train"] = merged["VIF_train"].replace([np.inf, -np.inf], np.nan)
            merged["VIF_test"]  = merged["VIF_test"].replace([np.inf, -np.inf], np.nan)
            merged["VIF_train"] = merged["VIF_train"].fillna(1e6)
            merged["VIF_test"]  = merged["VIF_test"].fillna(1e6)
            merged["Delta"] = (merged["VIF_train"] - merged["VIF_test"]).abs()
            
            merged["Flag_Train"] = merged["VIF_train"].apply(self.assign_flag)
            merged["Flag_Test"]  = merged["VIF_test"].apply(self.assign_flag)

            # флаг-сводка
            def count_flags(flag_series):
                return {"green": (flag_series == "green").sum(),
                        "orange": (flag_series == "orange").sum(),
                        "red": (flag_series == "red").sum()}
            train_flags = count_flags(merged["Flag_Train"])
            test_flags  = count_flags(merged["Flag_Test"])
            signal_train = self.compute_signal(merged["Flag_Train"].tolist())
            signal_test  = self.compute_signal(merged["Flag_Test"].tolist())
            self.test_signal = "red" if "red" in [signal_train, signal_test] else \
                            ("orange" if "orange" in [signal_train, signal_test] else "green")

            # листы фич по зонам (по train)
            def features_by_flag(df, flag_series, flag):
                return df[flag_series == flag]["Original_Feature"].unique().tolist()
            features_green  = features_by_flag(merged, merged["Flag_Train"], "green")
            features_orange = features_by_flag(merged, merged["Flag_Train"], "orange")
            features_red    = features_by_flag(merged, merged["Flag_Train"], "red")

            # HTML
            features_by_zone_html = f"""
            <h4>Feature Flags (Train)</h4>
            <p><b style='color:green'>Green Zone Features:</b> {', '.join(features_green) if features_green else 'None'}</p>
            <p><b style='color:orange'>Orange Zone Features:</b> {', '.join(features_orange) if features_orange else 'None'}</p>
            <p><b style='color:red'>Red Zone Features:</b> {', '.join(features_red) if features_red else 'None'}</p>
            """

            summary_table = f"""
            <h4>VIF Zones Summary</h4>
            <table border="1" cellpadding="5" cellspacing="0">
                <tr><th>Dataset</th><th style='color:green'>Green</th><th style='color:orange'>Orange</th><th style='color:red'>Red</th></tr>
                <tr><td>Train</td><td style='color:green'><b>{train_flags["green"]}</b></td>
                <td style='color:orange'><b>{train_flags["orange"]}</b></td>
                <td style='color:red'><b>{train_flags["red"]}</b></td></tr>
                <tr><td>Test</td><td style='color:green'><b>{test_flags["green"]}</b></td>
                <td style='color:orange'><b>{test_flags["orange"]}</b></td>
                <td style='color:red'><b>{test_flags["red"]}</b></td></tr>
            </table>
            """

            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><b>Final Signal (Test):</b> <span style='color:{signal_test}; font-weight:bold'>{signal_test.upper()}</span></p>
            <p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>
            <p><i>Примечание: категориальные признаки закодированы через target encoding с smoothing={self.smoothing}</i></p>
            """

            # Для графика используем Original_Feature
            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><b>Final Signal (Test):</b> <span style='color:{signal_test}; font-weight:bold'>{signal_test.upper()}</span></p>
            <p><i>Numeric features: {len(num_features)}, categorical features: {len(cat_features)}</i></p>
            <p><i>Note: categorical features are encoded with target encoding, smoothing={self.smoothing}.</i></p>
            """
            plot_df = merged[['Original_Feature', 'VIF_train', 'VIF_test']].drop_duplicates('Original_Feature')
            vif_plot = self.plot_vif_comparison(plot_df.rename(columns={'Original_Feature': 'Feature'}))
            
            table_html = merged[["Original_Feature", "Type", "VIF_train", "VIF_test", "Delta"]].to_html(index=False, float_format="%.2f")

            html = f"""
            <h4>Multicollinearity Test</h4>
            {signal_html}
            {summary_table}
            <br>
            {features_by_zone_html}
            <br>
            <h5>VIF Comparison Chart</h5>
            <img src="data:image/png;base64,{vif_plot}" style="display:block; width:100%; max-width:1000px; height:auto;">
            <h5>VIF Table</h5>
            {table_html}
            """
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": html}

        else:
            # кейс, когда тест-сэмпла нет → считаем только train
            vif_train["VIF"] = vif_train["VIF"].replace([np.inf, -np.inf], np.nan).fillna(1e6)
            vif_train["Flag_Train"] = vif_train["VIF"].apply(self.assign_flag)
            signal_train = self.compute_signal(vif_train["Flag_Train"].tolist())
            self.test_signal = signal_train

            table_html = vif_train[['Original_Feature', 'Type', 'VIF']].rename(columns={"VIF": "VIF_train"}).to_html(index=False, float_format="%.2f")
            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><i>Test выборка не обнаружена (sample='test'). Показаны только метрики Train.</i></p>
            <p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>
            <p><i>Примечание: категориальные признаки закодированы через target encoding с smoothing={self.smoothing}</i></p>
            """

            signal_html = f"""
            <p><b>Final Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
            <p><i>Test sample was not found (sample='test'). Only train metrics are shown.</i></p>
            <p><i>Numeric features: {len(num_features)}, categorical features: {len(cat_features)}</i></p>
            <p><i>Note: categorical features are encoded with target encoding, smoothing={self.smoothing}.</i></p>
            """

            html = f"""
            <h4>Multicollinearity Test (Train only)</h4>
            {signal_html}
            <h5>VIF Table</h5>
            {table_html}
            """
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": html}
