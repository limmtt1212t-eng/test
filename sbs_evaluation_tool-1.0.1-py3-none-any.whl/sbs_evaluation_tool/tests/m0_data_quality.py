# core import
import warnings
from ..core.base_test import BaseModelTest
from ..core.styles import COLORS, STATUS_COLORS
from ._visual_utils import (
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    apply_secondary_axis_style,
    apply_standard_axis_style,
)

# default imports
import pandas as pd  # type: ignore
import numpy as np   # type: ignore
import matplotlib.pyplot as plt  # type: ignore
from io import BytesIO
import base64
from matplotlib.colors import LinearSegmentedColormap  # type: ignore

# stat imports (оставлены без использования — на будущее)
from sklearn.linear_model import LogisticRegression  # type: ignore
from sklearn.metrics import roc_auc_score            # type: ignore
from scipy.stats import norm                         # type: ignore
import statsmodels.api as sm                         # type: ignore

# module imports
import itertools
from typing import List, Dict, Union

# NEW: валидация конфига
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import ensure_config
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)


class M01_DataSummaryTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 0.1", "Data Summary")

    # NEW: теперь принимаем df + config
    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        """
        Сводка по датасету с разбивкой по sample: Observations, Duplicates, Min/Max Date.
        Берёт имена колонок из config.columns.*
        """
        cfg = ensure_config(config, df)
        date_column = cfg.columns.date_column
        sample_column = cfg.columns.sample_column

        if date_column not in df.columns or sample_column not in df.columns:
            raise KeyError("В данных отсутствуют date_column или sample_column из config")

        # Переводим даты в datetime (мягко)
        df = df.copy()
        df[date_column] = pd.to_datetime(df[date_column], errors='coerce')

        # Если попали NaT — предупреждаем
        if df[date_column].isnull().any():
            warnings.warn("Некоторые значения в date_column не приводятся к datetime (NaT).")

        summary_dict = {}
        index = ['Observations', 'Duplicates', 'Min Date', 'Max Date']

        for sample in tqdm(df[sample_column].dropna().unique(), desc="M 0.1 - Samples"):
            sample_df = df[df[sample_column] == sample]
            summary_dict[sample] = [
                len(sample_df),
                sample_df.duplicated().sum(),
                sample_df[date_column].min(),
                sample_df[date_column].max()
            ]

        summary_df = pd.DataFrame.from_dict(summary_dict, orient='index', columns=index)
        html = "<h4>Data Summary</h4>" + summary_df.to_html()
        # blue/info since informational
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"summary": html}


class M02_SampleOverlayTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 0.2", "Sample Overlay")

    # NEW: теперь принимаем df + config (primary_key берём из config)
    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        """
        Считает пересечения объектов между сэмплами по primary key.
        primary_key берётся из config.columns.id_column (или columns.id_columns если задан список).
        """
        cfg = ensure_config(config, df)
        sample_column = cfg.columns.sample_column
        # поддержим и одиночный id_column, и потенциальный список id_columns (если добавишь в config)
        primary_key = config.get("columns", {}).get("id_columns", None) or cfg.columns.id_column

        # нормализуем в список
        if isinstance(primary_key, str):
            key_cols = [primary_key]
        elif isinstance(primary_key, list):
            key_cols = primary_key
        else:
            raise ValueError("В config.columns ожидается id_column (str) или id_columns (List[str])")

        missing = [c for c in key_cols + [sample_column] if c not in df.columns]
        if missing:
            raise KeyError(f"В данных отсутствуют колонки: {missing}")
        if len(key_cols) > 10:
            raise ValueError("Слишком много ключевых колонок в id_columns — максимум 10.")

        df = df.copy()
        # ВАЖНО: формируем ключ ТОЛЬКО по первичному ключу (без sample),
        # иначе пересечения всегда будут пустыми.
        df["__key__"] = df[key_cols].astype(str).agg("_".join, axis=1)

        distinct_samples = df[sample_column].dropna().unique()
        overlaps = []
        pairs = list(itertools.combinations(distinct_samples, 2))
        for a, b in tqdm(pairs, desc="M 0.2 - Sample pairs", total=len(pairs)):
            keys_a = df.loc[df[sample_column] == a, "__key__"].unique()
            keys_b = df.loc[df[sample_column] == b, "__key__"].unique()
            intersection = np.intersect1d(keys_a, keys_b)
            overlaps.append({"Samples": f"{a} vs {b}", "Intersections": int(len(intersection))})

        df.drop("__key__", axis=1, inplace=True)
        overlap_df = pd.DataFrame(overlaps) if overlaps else pd.DataFrame(columns=["Samples", "Intersections"])
        html = "<h4>Sample Overlap</h4>" + overlap_df.to_html(index=False)
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"overlap": html}


class M03_ObsVsPredTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 0.3", "Observed vs Predicted")

    # NEW: теперь принимаем df + config; колонку предсказания берём по task
    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        """
        По каждому sample считает сумму фактов, сумму предсказаний и отклонение (%).
        Для classification: используется prediction_column (метки 0/1).
        Для regression: используется score_column (вещественное предсказание).
        """
        cfg = ensure_config(config, df)
        sample_column = cfg.columns.sample_column
        target_column = cfg.columns.target_column
        if cfg.task == "classification":
            predict_column = cfg.columns.prediction_column
            if predict_column is None:
                raise ConfigValidationError(["Для classification требуется columns.prediction_column (метки класса)."])
        else:
            predict_column = cfg.columns.score_column
            if predict_column is None:
                raise ConfigValidationError(["Для regression требуется columns.score_column (предсказание)."])

        needed = [predict_column, target_column, sample_column]
        missing = [c for c in needed if c not in df.columns]
        if missing:
            raise KeyError(f"В данных отсутствуют колонки: {missing}")

        df = df.copy()
        # Приведём к числовому типу столбцы с фактом/предсказанием (где уместно)
        for column in [predict_column, target_column]:
            if not pd.api.types.is_numeric_dtype(df[column]):
                try:
                    df[column] = pd.to_numeric(df[column], errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {column} не является числовым. Перевод в числовой тип невозможен.")

        result = []
        for sample in tqdm(df[sample_column].dropna().unique(), desc="M 0.3 - Samples"):
            group = df[df[sample_column] == sample]
            obs = float(group[target_column].sum())
            pred = float(group[predict_column].sum())
            deviation = (pred - obs) / obs * 100 if obs != 0 else np.nan
            result.append({
                "Sample": sample,
                "Observed": obs,
                "Prediction": pred,
                "Deviation (%)": round(deviation, 2) if pd.notnull(deviation) else np.nan
            })

        result_df = pd.DataFrame(result)
        html = "<h4>Observed vs Predicted</h4>" + result_df.to_html(index=False)
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"obs_pred": html}

# --- M 0.1 — Data Quality Overview ---
class M01_DataQualityOverviewTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 0.1", "Data Quality (duplicates, overlaps, obs vs pred)")

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        sample_column = cfg.columns.sample_column
        target_column = cfg.columns.target_column
        # предсказание в зависимости от задачи
        predict_column = cfg.columns.prediction_column if cfg.task == "classification" else cfg.columns.score_column
        if predict_column is None:
            raise ConfigValidationError(["Не задана колонка с предсказанием: prediction_column (classification) или score_column (regression)"])

        # нормализуем ключи для пересечений
        primary_key = config.get("columns", {}).get("id_columns", None) or cfg.columns.id_column
        if isinstance(primary_key, str):
            key_cols = [primary_key]
        elif isinstance(primary_key, list):
            key_cols = primary_key
        else:
            raise ValueError("В config.columns ожидается id_column (str) или id_columns (List[str])")

        # Копия и приведение типов
        work = df.copy()
        for col in [predict_column, target_column]:
            if not pd.api.types.is_numeric_dtype(work[col]):
                work[col] = pd.to_numeric(work[col], errors='raise')

        # 1) Дубликаты (по всей таблице)
        duplicates_count = int(work.duplicated().sum())

        # 2) Пересечения TRAIN/TEST по первичным ключам
        if any(c not in work.columns for c in key_cols):
            raise KeyError(f"В данных отсутствуют колонки первичного ключа: {[c for c in key_cols if c not in work.columns]}")
        work["__key__"] = work[key_cols].astype(str).agg("_".join, axis=1)
        s = work[sample_column].astype(str).str.upper()
        keys_train = set(work.loc[s.eq('TRAIN'), "__key__"].unique())
        keys_test  = set(work.loc[s.eq('TEST'),  "__key__"].unique())
        overlap_count = len(keys_train.intersection(keys_test))
        work.drop(columns=["__key__"], inplace=True)

        # Извлекаем weight_column если есть
        weight_column = config.get("columns", {}).get("weight_column") or config.get("columns", {}).get("weight")

        # 3) Наблюдаемое vs Предсказанное (по сэмплам), порог 1%
        obs_pred_rows = []
        max_abs_dev = 0.0
        for sample in tqdm(work[sample_column].dropna().astype(str).unique(), desc="M 0.1 - Samples"):
            g = work[work[sample_column].astype(str) == sample]
            
            # Если есть weight_column, считаем rate с учетом экспозиции
            if weight_column and weight_column in g.columns:
                w = pd.to_numeric(g[weight_column], errors='coerce').fillna(0.0)
                total_w = float(w.sum())
                if total_w > 0:
                    # Weighted mean (симметричная формула для обоих)
                    obs = float((g[target_column] * w).sum()) / total_w
                    pred = float((g[predict_column] * w).sum()) / total_w
                else:
                    obs = float(g[target_column].sum())
                    pred = float(g[predict_column].sum())
            else:
                # Без весов: просто суммы или средние
                obs = float(g[target_column].sum())
                pred = float(g[predict_column].sum())
            
            dev = ((pred - obs) / obs * 100.0) if obs != 0 else float("nan")
            if pd.notnull(dev):
                max_abs_dev = max(max_abs_dev, abs(dev))
            obs_pred_rows.append({
                "Sample": sample,
                "Observed": round(obs, 6),
                "Prediction": round(pred, 6),
                "Deviation (%)": round(dev, 2) if pd.notnull(dev) else np.nan
            })
        obs_pred_df = pd.DataFrame(obs_pred_rows)

        # --- Сводка и сигнал ---
        duplicates_flag = duplicates_count > 0
        overlap_flag = overlap_count > 0
        dev_flag = max_abs_dev > 1.0
        self.test_signal = "red" if (duplicates_flag or overlap_flag or dev_flag) else "green"

        summary_html = f"""
        <h4>Summary (Traffic Light Rules)</h4>
        <table border="1" cellpadding="5" cellspacing="0">
            <tr><th>Check</th><th>Value</th><th>Rule</th><th>Flag</th></tr>
            <tr><td>Duplicates (all rows)</td><td>{duplicates_count}</td><td>> 0 → RED</td><td style='color:{'red' if duplicates_flag else 'green'}'><b>{('RED' if duplicates_flag else 'GREEN')}</b></td></tr>
            <tr><td>Overlaps TRAIN∩TEST (by ID)</td><td>{overlap_count}</td><td>> 0 → RED</td><td style='color:{'red' if overlap_flag else 'green'}'><b>{('RED' if overlap_flag else 'GREEN')}</b></td></tr>
            <tr><td>Max |Deviation| (Obs vs Pred)</td><td>{max_abs_dev:.2f}%</td><td>> 1% → RED</td><td style='color:{'red' if dev_flag else 'green'}'><b>{('RED' if dev_flag else 'GREEN')}</b></td></tr>
        </table>
        <p><b>Final Signal:</b> <span style='color:{self.test_signal}'><b>{self.test_signal.upper()}</b></span></p>
        """

        # Детальные секции
        # Дубликаты по сэмплам для справки
        dup_by_sample = work.groupby(sample_column).apply(lambda d: int(d.duplicated().sum())).reset_index(name="Duplicates")
        details_html = [
            summary_html,
            "<h4>Observed vs Predicted by Sample</h4>" + obs_pred_df.to_html(index=False),
            "<h4>Duplicates by Sample</h4>" + dup_by_sample.to_html(index=False),
        ]
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={_log_text})")
        return {"overview": "<hr>".join(details_html)}


# --- M 0.4 — Monthly Distributions (informational, no traffic light) ---
class M04_MonthlyDistributionsTest(BaseModelTest):
    """
    Информативные тепловые карты распределений значений по месяцам для признаков.

    - По оси X: месяцы (Period M, строка YYYY-MM)
    - По оси Y: категории/бакеты
    - Цвет: доля наблюдений для соответствующей категории в конкретном месяце

    Особенности:
      * Для категориальных признаков ограничиваем общее число категорий: не более max_categories
        (берём top-(max_categories-1), остальные объединяем в 'Other').
      * Для численных признаков выполняем биннинг в n_bins бакетов (qcut с fallback на cut),
        затем строим тепловую карту по бакетам.

    Возврат: {"DASHBOARD": HTML}, без светофора (self.test_signal не устанавливается).
    """

    def __init__(self, max_categories: int = 20, n_bins: int = 10):
        super().__init__("M 0.4", "Monthly Distributions (informational)")
        self.max_categories = int(max_categories)
        self.n_bins = int(n_bins)
        # Use Matplotlib 'hot' colormap inverted (hot_r): bright/yellow for low, dark/red→black for high
        # Matches request: plot_color_gradients('Sequential (2)', 'hot') with inversion
        self._cmap = plt.get_cmap('hot_r')

    # --- helpers ---
    @staticmethod
    def _to_base64(fig) -> str:
        buf = BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight", dpi=120)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    def _prepare_categorical(self, s: pd.Series) -> pd.Series:
        vc = s.astype(str).value_counts(dropna=False)
        if len(vc) <= self.max_categories:
            return s.astype(str)
        keep = set(vc.head(max(1, self.max_categories - 1)).index)
        return s.astype(str).apply(lambda v: v if v in keep else "Other")

    def _month_str(self, s: pd.Series) -> pd.Series:
        s = pd.to_datetime(s, errors="coerce")
        return s.dt.to_period("M").astype(str)

    def _heatmap_html(self, ct: pd.DataFrame, title: str) -> str:
        # ct: index=month (str), columns=categories/buckets (str), values=share [0..1]
        if ct.empty:
            return f"<p><i>No data for {title}</i></p>"

        # сортируем
        ct = ct.sort_index()
        # сортировка столбцов по имени, для стабильности отображения
        ct = ct[sorted(ct.columns)]

        fig, ax = plt.subplots(figsize=(max(8, len(ct.index) * 0.5), max(4, len(ct.columns) * 0.35)))
        vmax = float(ct.values.max()) if ct.values.size else 1.0
        im = ax.imshow(
            ct.T.values,
            aspect="auto",
            origin="lower",
            vmin=0,
            vmax=(vmax if vmax > 0 else 1),
            cmap=self._cmap,
        )
        ax.set_xticks(range(len(ct.index)))
        ax.set_xticklabels(ct.index, rotation=45, ha="right", fontsize=8)
        ax.set_yticks(range(len(ct.columns)))
        ax.set_yticklabels(ct.columns, fontsize=8)
        apply_standard_axis_style(
            ax,
            title=title,
            xlabel="Month",
            ylabel="Category / Bucket",
            legend_loc=None,
        )
        cbar = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.02)
        cbar.set_label("Share of observations")
        b64 = self._to_base64(fig)
        return f"<img src='data:image/png;base64,{b64}' />"

    def _build_categorical_heatmap(self, df: pd.DataFrame, date_col: str, feature: str, sample_name: str) -> str:
        d = df.copy()
        d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
        d = d.dropna(subset=[date_col])
        if feature not in d.columns:
            return f"<p style='color:red'>Missing column: {feature}</p>"
        d["__month"] = d[date_col].dt.to_period("M").astype(str)
        y_vals = self._prepare_categorical(d[feature])
        # сводная таблица: месяц x категория -> размер, нормировка по строке в доли
        ct = (d.assign(_y=y_vals)
                .pivot_table(index="__month", columns="_y", values=feature, aggfunc="size", fill_value=0))
        ct = ct.div(ct.sum(axis=1).replace(0, pd.NA), axis=0).fillna(0)
        title = f"{feature} ({sample_name}) — monthly category distribution"
        return self._heatmap_html(ct, title)

    def _build_numeric_heatmap(self, df: pd.DataFrame, date_col: str, feature: str, sample_name: str) -> str:
        d = df.copy()
        d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
        d = d.dropna(subset=[date_col])
        if feature not in d.columns:
            return f"<p style='color:red'>Missing column: {feature}</p>"
        d["__month"] = d[date_col].dt.to_period("M").astype(str)
        # биннинг
        vals = pd.to_numeric(d[feature], errors='coerce')
        # первичная попытка квантильного биннинга
        try:
            buckets = pd.qcut(vals, q=self.n_bins, duplicates='drop')
        except Exception:
            buckets = pd.cut(vals, bins=self.n_bins, include_lowest=True)

        # если после биннинга получился один бакет — принудительно делим на два
        if buckets is not None:
            uniq = pd.Series(buckets.astype(str)).nunique(dropna=True)
        else:
            uniq = 0
        if uniq <= 1:
            # Делаем два бакета по порядку наблюдений (стабильно и независимо от значения)
            n = len(vals)
            if n >= 2:
                idx = np.arange(n)
                half = max(1, n // 2)
                forced = np.where(idx < half, "Bucket_1", "Bucket_2")
                d["__bucket"] = forced.astype(str)
            else:
                # крайний случай: 1 наблюдение — оставим один бакет
                d["__bucket"] = pd.Series(["Bucket_1"] * n, index=d.index)
        else:
            d["__bucket"] = buckets.astype(str)
        d = d.dropna(subset=["__bucket"])  # удаляем NaN-бакеты
        ct = (d.pivot_table(index="__month", columns="__bucket", values=feature, aggfunc="size", fill_value=0))
        ct = ct.div(ct.sum(axis=1).replace(0, pd.NA), axis=0).fillna(0)
        title = f"{feature} ({sample_name}) — monthly distribution by buckets"
        return self._heatmap_html(ct, title)

    def run(self,
            df: pd.DataFrame,
            config: dict,
            samples: list | None = None,
            categorical_features: list | None = None,
            numeric_features: list | None = None) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        date_col = getattr(cfg.columns, 'date_column', None)
        sample_col = getattr(cfg.columns, 'sample_column', None)
        if not date_col or date_col not in df.columns:
            return {"DASHBOARD": "<p><i>Skipped: missing date_column in df/config.</i></p>"}
        if not sample_col or sample_col not in df.columns:
            return {"DASHBOARD": "<p><i>Skipped: missing sample_column in df/config.</i></p>"}

        cats = list(categorical_features) if categorical_features is not None else list(getattr(cfg.columns, 'categorical_features', []) or [])
        nums = list(numeric_features) if numeric_features is not None else list(getattr(cfg.columns, 'numeric_features', []) or [])

        # добавим SCORE в численные, если присутствует
        if 'SCORE' in df.columns and 'SCORE' not in nums:
            nums.append('SCORE')
        # полезная категориальная колонка из датасета (если присутствует)
        if 'SEAS_NERAVNOM_RISK_MONTHS' in df.columns and 'SEAS_NERAVNOM_RISK_MONTHS' not in cats:
            cats.append('SEAS_NERAVNOM_RISK_MONTHS')

        # выбор сэмплов
        if samples is None:
            sample_list = df[sample_col].dropna().astype(str).unique().tolist()
        else:
            sample_list = [str(s) for s in samples]

        html_blocks: list[str] = []
        try:
            # Progress over features (as requested)
            for f in tqdm(cats, desc="M 0.4 - Categorical features"):
                html_blocks.append(f"<h3>Feature: {f} (categorical)</h3>")
                for s in sample_list:
                    sub = df[df[sample_col].astype(str) == s].copy()
                    if sub.empty:
                        continue
                    html_blocks.append(f"<h4>Sample: {s}</h4>")
                    try:
                        html_blocks.append(self._build_categorical_heatmap(sub, date_col, f, s))
                    except Exception as e:
                        html_blocks.append(f"<p style='color:red'>Error plotting {f} (categorical, {s}): {e}</p>")

            for f in tqdm(nums, desc="M 0.4 - Numeric features"):
                html_blocks.append(f"<h3>Feature: {f} (numeric)</h3>")
                for s in sample_list:
                    sub = df[df[sample_col].astype(str) == s].copy()
                    if sub.empty:
                        continue
                    html_blocks.append(f"<h4>Sample: {s}</h4>")
                    try:
                        html_blocks.append(self._build_numeric_heatmap(sub, date_col, f, s))
                    except Exception as e:
                        html_blocks.append(f"<p style='color:red'>Error plotting {f} (numeric, {s}): {e}</p>")
        except Exception as e:
            return {"DASHBOARD": f"<p style='color:red'>Unexpected error: {str(e)}</p>"}

        if not html_blocks:
            return {"DASHBOARD": "<p><i>No plots generated.</i></p>"}
        # INFO banner and set blue signal
        self.test_signal = "blue"
        info_banner = (
            "<div style=\"background-color:#e6f0ff;padding:8px;border-left:4px solid #1f77b4;margin-bottom:10px;\">"
            "<b><span style='color:#1f77b4'>INFO</span>:</b> This test is informational and does not affect pass/fail."
            "</div>"
        )
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": info_banner + "".join(html_blocks)}


# --- M 0.5 — Mode and Missing share by period (informational) ---
class M05_ModeAndMissingByPeriodTest(BaseModelTest):
    """
    Информативный график по оси X — месяцы или кварталы (автовыбор),
    столбцы — число наблюдений, линии — доля совпадений с модой и доля пропусков.

    Работает для всех типов признаков:
      * категориальные — как есть;
      * численные — для вычисления моды значения округляются (по умолчанию 3 знака).

    Дополнительно формируется таблица по всем признакам: глобальная мода и её доля на TRAIN и TEST.

    Возврат: {"DASHBOARD": HTML}; светофор не устанавливается.
    """

    def __init__(self, month_threshold: int = 18, mse_yellow: float = 0.01, mse_red: float = 0.03):
        super().__init__("M 0.5", "Mode and Missing share by period")
        # Если уникальных месяцев больше этого порога — агрегируем по кварталам
        self.month_threshold = int(month_threshold)
        # Thresholds for MSE between Train/Test mode-share curves
        self.mse_yellow = float(mse_yellow)
        self.mse_red = float(mse_red)

    # --- helpers ---
    @staticmethod
    def _to_base64(fig) -> str:
        buf = BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight", dpi=120)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode("utf-8")

    def _pick_freq(self, dates: pd.Series) -> str:
        s = pd.to_datetime(dates, errors="coerce").dropna()
        if s.empty:
            return "M"
        n_months = s.dt.to_period("M").nunique()
        return "M" if n_months <= self.month_threshold else "Q"

    def _period_str(self, dates: pd.Series, freq: str) -> pd.Series:
        s = pd.to_datetime(dates, errors="coerce")
        return s.dt.to_period(freq).astype(str)

    @staticmethod
    def _missing_mask(s: pd.Series) -> pd.Series:
        # считаем пустые строки и явные NaN как пропуски
        return s.isna() | (s.astype(str).str.strip().isin(["", "nan", "None"]))

    @staticmethod
    def _normalize_for_mode(s: pd.Series, round_decimals: int = 3) -> pd.Series:
        """Подготовка значений для корректного поиска моды.
        - Для численных: округление до round_decimals и приведение к строке (чтобы унифицировать тип);
        - Для прочих: строковое представление.
        Пропуски сохраняем как NaN для последующей фильтрации маской.
        """
        if pd.api.types.is_numeric_dtype(s):
            return pd.Series(np.round(s.astype(float), round_decimals), index=s.index).astype(str)
        return s.astype(str)

    def _build_plot(self, df: pd.DataFrame, date_col: str, feature: str, sample_name: str) -> str:
        d = df.copy()
        d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
        d = d.dropna(subset=[date_col])
        if feature not in d.columns:
            return f"<p style='color:red'>Missing column: {feature}</p>"

        freq = self._pick_freq(d[date_col])
        d["__period"] = self._period_str(d[date_col], freq)

        periods = sorted(d["__period"].dropna().unique().tolist())
        if not periods:
            return f"<p><i>No data for {feature} ({sample_name})</i></p>"

        # агрегаты по периодам
        counts: list[int] = []
        mode_shares: list[float] = []
        miss_shares: list[float] = []
        for p in periods:
            g = d[d["__period"] == p]
            counts.append(int(len(g)))
            miss = self._missing_mask(g[feature]).mean()
            miss_shares.append(float(miss))
            # мода и её доля — среди НЕпропусков
            vals_norm = self._normalize_for_mode(g[feature])
            non_missing = vals_norm[~self._missing_mask(vals_norm)]
            if len(non_missing) == 0:
                mode_shares.append(float("nan"))
            else:
                mode_shares.append(float(non_missing.astype(str).value_counts(normalize=True).max()))

        # построение графика
        x = list(range(len(periods)))
        fig_w = max(10, len(periods) * 0.75)
        fig, ax = plt.subplots(figsize=(fig_w, 4.5))

        ax.bar(x, counts, color=COLORS['EMERALD'], alpha=0.2)
        ax.set_ylabel(OBSERVATION_COUNT_LABEL)
        ax.set_xticks(x)
        ax.set_xticklabels(periods, rotation=45, ha="right")

        ax2 = ax.twinx()
        ax2.plot(x, mode_shares, color=COLORS['EMERALD'], marker="o", label="Mode Match Share")
        ax2.plot(x, miss_shares, color=COLORS['GREEN'], marker="o", label="Missing Share")
        apply_secondary_axis_style(ax2, ylabel=SHARE_LABEL, legend_loc="upper right")
        # разумные пределы по правой оси
        y_max = max([v for v in mode_shares + miss_shares if pd.notnull(v)] + [0])
        ax2.set_ylim(0, min(1.0, y_max * 1.15 + 0.02))
        # заголовок в 2 строки
        title_top = f"{feature} ({sample_name}) ({'month' if self._pick_freq(d[date_col])=='M' else 'quarter'})"
        title_bottom = f"[{feature}]"
        fig.suptitle(f"{title_top}\n{title_bottom}")

        b64 = self._to_base64(fig)
        return f"<img src='data:image/png;base64,{b64}' />"

    def _build_train_test_plot(self, df: pd.DataFrame, date_col: str, sample_col: str, feature: str) -> str:
        d = df.copy()
        if feature not in d.columns:
            return f"<p style='color:red'>Missing column: {feature}</p>"
        d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
        d = d.dropna(subset=[date_col])
        if d.empty:
            return f"<p><i>No data for {feature}</i></p>"

        # Normalize sample names and choose period frequency
        d["__S"] = d[sample_col].astype(str).str.upper()
        freq = self._pick_freq(d[date_col])
        d["__period"] = self._period_str(d[date_col], freq)

        # Focus on TRAIN/TEST only
        d = d[d["__S"].isin(["TRAIN", "TEST"])].copy()
        if d.empty:
            return f"<p><i>No TRAIN/TEST data for {feature}</i></p>"

        periods = sorted(d["__period"].dropna().unique().tolist())
        if not periods:
            return f"<p><i>No periods for {feature}</i></p>"

        # Containers
        cnt_tr, cnt_te = [], []
        mode_tr, mode_te = [], []
        miss_tr, miss_te = [], []

        for p in periods:
            g = d[d["__period"] == p]
            g_tr = g[g["__S"] == "TRAIN"]
            g_te = g[g["__S"] == "TEST"]

            # counts
            cnt_tr.append(int(len(g_tr)))
            cnt_te.append(int(len(g_te)))

            # missing shares
            miss_tr.append(float(self._missing_mask(g_tr[feature]).mean()) if len(g_tr) else float("nan"))
            miss_te.append(float(self._missing_mask(g_te[feature]).mean()) if len(g_te) else float("nan"))

            # mode shares among non-missing normalized values
            def _mode_share(sub: pd.DataFrame) -> float:
                if sub.empty:
                    return float("nan")
                vals_norm = self._normalize_for_mode(sub[feature])
                non_missing = vals_norm[~self._missing_mask(vals_norm)]
                if non_missing.empty:
                    return float("nan")
                return float(non_missing.astype(str).value_counts(normalize=True).max())

            mode_tr.append(_mode_share(g_tr))
            mode_te.append(_mode_share(g_te))

        # Plot
        x = np.arange(len(periods))
        width = 0.4
        fig_w = max(10, len(periods) * 0.8)
        fig, ax = plt.subplots(figsize=(fig_w, 5))

        bars_tr = ax.bar(x - width / 2, cnt_tr, width=width, color=COLORS['BLUE'], alpha=0.35, label="Train Count")
        bars_te = ax.bar(x + width / 2, cnt_te, width=width, color=COLORS['EMERALD'], alpha=0.35, label="Test Count")
        ax.set_ylabel(OBSERVATION_COUNT_LABEL)
        ax.set_xticks(x)
        ax.set_xticklabels(periods, rotation=45, ha="right")

        ax2 = ax.twinx()
        # Train solid
        ax2.plot(x, mode_tr, color=COLORS['EMERALD'], marker="o", linestyle="-", label="Train: Mode Match Share")
        ax2.plot(x, miss_tr, color=COLORS['GREEN'], marker="o", linestyle="-", label="Train: Missing Share")
        # Test dashed
        ax2.plot(x, mode_te, color=COLORS['EMERALD'], marker="s", linestyle="--", label="Test: Mode Match Share")
        ax2.plot(x, miss_te, color=COLORS['GREEN'], marker="s", linestyle="--", label="Test: Missing Share")
        ax2.set_ylabel(SHARE_LABEL)
        # y-limits for shares
        share_vals = [v for v in mode_tr + miss_tr + mode_te + miss_te if pd.notnull(v)]
        y_max = max(share_vals) if share_vals else 1.0
        ax2.set_ylim(0, min(1.0, y_max * 1.15 + 0.02))

        # Legends
        apply_standard_axis_style(ax, legend_loc="upper left")
        apply_secondary_axis_style(ax2, legend_loc="upper right")

        # Title
        title_top = f"{feature} (TRAIN vs TEST) ({'month' if self._pick_freq(d[date_col])=='M' else 'quarter'})"
        title_bottom = f"[{feature}]"
        fig.suptitle(f"{title_top}\n{title_bottom}")

        b64 = self._to_base64(fig)
        return f"<img src='data:image/png;base64,{b64}' />"

    def _compute_train_test_series(self, df: pd.DataFrame, date_col: str, sample_col: str, feature: str):
        d = df.copy()
        if feature not in d.columns:
            return [], [], [], [], [], [], []
        d[date_col] = pd.to_datetime(d[date_col], errors="coerce")
        d = d.dropna(subset=[date_col])
        if d.empty:
            return [], [], [], [], [], [], []

        d["__S"] = d[sample_col].astype(str).str.upper()
        freq = self._pick_freq(d[date_col])
        d["__period"] = self._period_str(d[date_col], freq)
        d = d[d["__S"].isin(["TRAIN", "TEST"])].copy()
        periods = sorted(d["__period"].dropna().unique().tolist())
        if not periods:
            return [], [], [], [], [], [], []

        cnt_tr, cnt_te = [], []
        mode_tr, mode_te = [], []
        miss_tr, miss_te = [], []

        for p in periods:
            g = d[d["__period"] == p]
            g_tr = g[g["__S"] == "TRAIN"]
            g_te = g[g["__S"] == "TEST"]
            cnt_tr.append(int(len(g_tr)))
            cnt_te.append(int(len(g_te)))

            miss_tr.append(float(self._missing_mask(g_tr[feature]).mean()) if len(g_tr) else float("nan"))
            miss_te.append(float(self._missing_mask(g_te[feature]).mean()) if len(g_te) else float("nan"))

            def _mode_share(sub: pd.DataFrame) -> float:
                if sub.empty:
                    return float("nan")
                vals_norm = self._normalize_for_mode(sub[feature])
                non_missing = vals_norm[~self._missing_mask(vals_norm)]
                if non_missing.empty:
                    return float("nan")
                return float(non_missing.astype(str).value_counts(normalize=True).max())

            mode_tr.append(_mode_share(g_tr))
            mode_te.append(_mode_share(g_te))

        return periods, mode_tr, mode_te, miss_tr, miss_te, cnt_tr, cnt_te

    def run(
        self,
        df: pd.DataFrame,
        config: dict,
        samples: list | None = None,
        categorical_features: list | None = None,
        numeric_features: list | None = None,
    ) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        date_col = getattr(cfg.columns, "date_column", None)
        sample_col = getattr(cfg.columns, "sample_column", None)
        if not date_col or date_col not in df.columns:
            return {"DASHBOARD": "<p><i>Skipped: missing date_column in df/config.</i></p>"}
        if not sample_col or sample_col not in df.columns:
            return {"DASHBOARD": "<p><i>Skipped: missing sample_column in df/config.</i></p>"}

        cats = list(categorical_features) if categorical_features is not None else list(getattr(cfg.columns, 'categorical_features', []) or [])
        nums = list(numeric_features) if numeric_features is not None else list(getattr(cfg.columns, 'numeric_features', []) or [])
        features = [f for f in list(dict.fromkeys([*cats, *nums])) if f in df.columns]
        if not features:
            return {"DASHBOARD": "<p><i>No features provided (categorical or numeric).</i></p>"}

        # выбор сэмплов
        if samples is None:
            sample_list = df[sample_col].dropna().astype(str).unique().tolist()
        else:
            sample_list = [str(s) for s in samples]

    # --- Таблица мод на TRAIN/TEST для всех фичей ---
        s = df[sample_col].astype(str).str.upper()
        df_tr = df[s.eq('TRAIN')]
        df_te = df[s.eq('TEST')]

        def _mode_and_share(dsub: pd.DataFrame, feat: str):
            if dsub.empty or feat not in dsub.columns:
                return (None, np.nan)
            vals = self._normalize_for_mode(dsub[feat])
            non_miss = vals[~self._missing_mask(vals)]
            if non_miss.empty:
                return (None, np.nan)
            vc = non_miss.value_counts(normalize=True)
            v = vc.index[0]
            sh = float(vc.iloc[0])
            return (v, sh)

        rows = []
        mismatched_features: list[str] = []
        for f in tqdm(features, desc="M 0.5 - Features"):
            tr_v, tr_sh = _mode_and_share(df_tr, f)
            te_v, te_sh = _mode_and_share(df_te, f)
            # track mismatch if both modes present and not equal (string compare)
            if (tr_v is not None) and (te_v is not None) and (str(tr_v) != str(te_v)):
                mismatched_features.append(f)
            rows.append({
                "Feature": f,
                "Train mode": "—" if tr_v is None else str(tr_v),
                "Train mode share": None if np.isnan(tr_sh) else round(tr_sh, 4),
                "Test mode": "—" if te_v is None else str(te_v),
                "Test mode share": None if np.isnan(te_sh) else round(te_sh, 4),
            })
        mode_table_html = pd.DataFrame(rows).to_html(index=False)

        # Header alert if any feature has different TRAIN/TEST mode
        alert_html = ""
        if mismatched_features:
            feats = ", ".join(mismatched_features)
            alert_html = (
                "<div style=\"background-color:#ffe6e6;padding:8px;border-left:4px solid #d00;margin-bottom:10px;\">"
                f"<b>Alert:</b> Modes differ between TRAIN and TEST for feature(s): <b>{feats}</b>"
                "</div>"
            )

        # Compute MSE between TRAIN/TEST mode-share curves per feature and build dashboard
        metrics_rows = []
        overall_flags = []
        for f in features:
            periods, mode_tr, mode_te, _, _, _, _ = self._compute_train_test_series(df, date_col, sample_col, f)
            # pairwise MSE ignoring NaNs
            diffs = []
            for a, b in zip(mode_tr, mode_te):
                if pd.notnull(a) and pd.notnull(b):
                    diffs.append((a - b) ** 2)
            mse = float(np.mean(diffs)) if diffs else float('nan')
            # determine flag
            if not diffs:
                flag = 'gray'  # insufficient data
            elif mse >= self.mse_red:
                flag = 'red'
            elif mse >= self.mse_yellow:
                flag = 'orange'
            else:
                flag = 'green'
            if flag in ('red', 'orange', 'green'):
                overall_flags.append(flag)
            metrics_rows.append({"Feature": f, "MSE(mode TR vs TE)": None if np.isnan(mse) else round(mse, 6), "Flag": flag})

        # Overall signal from worst flag
        if 'red' in overall_flags:
            self.test_signal = 'red'
        elif 'orange' in overall_flags:
            self.test_signal = 'orange'
        elif 'green' in overall_flags:
            self.test_signal = 'green'
        else:
            self.test_signal = 'gray'

        # Build metrics table HTML with colored flags
        metrics_df = pd.DataFrame(metrics_rows)
        if not metrics_df.empty:
            def color_flag(flag: str) -> str:
                color = {'red': '#d62728', 'orange': '#ff7f0e', 'green': '#2ca02c', 'gray': '#7f7f7f'}.get(flag, '#7f7f7f')
                return f"<span style='color:{color};font-weight:bold'>{flag.upper()}</span>"
            metrics_df['Flag'] = metrics_df['Flag'].apply(color_flag)
            metrics_table_html = metrics_df.to_html(index=False, escape=False)
        else:
            metrics_table_html = "<p><i>No features to evaluate.</i></p>"

        header_banner = (
            f"<div style=\"background:#f7f7f7;padding:8px;border-left:4px solid #333;margin-bottom:10px;\">"
            f"<b>Dashboard:</b> Signal based on MSE between TRAIN/TEST mode-share curves. "
            f"Thresholds: yellow ≥ {self.mse_yellow:.3f}, red ≥ {self.mse_red:.3f}. "
            f"<b>Overall:</b> <span style='color:{self.test_signal};font-weight:bold'>{self.test_signal.upper()}</span>"
            f"</div>"
        )

        blocks: list[str] = []
        blocks.append(header_banner)
        if alert_html:
            blocks.append(alert_html)
        blocks.append("<h3>Global modes on TRAIN and TEST</h3>" + mode_table_html)
        blocks.append("<h3>Per-feature MSE between mode-share curves</h3>" + metrics_table_html)
        blocks.append("<hr>")
        # Combined plots: one per feature with TRAIN/TEST together
        for f in tqdm(features, desc="M 0.5 - Build plots", leave=False):
            try:
                blocks.append(f"<h3>{f}: TRAIN vs TEST</h3>")
                blocks.append(self._build_train_test_plot(df, date_col, sample_col, f))
            except Exception as e:
                blocks.append(f"<p style='color:red'>Error plotting {f} (TRAIN/TEST): {e}</p>")

        if not blocks:
            return {"DASHBOARD": "<p><i>No plots generated.</i></p>"}
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": "".join(blocks)}
