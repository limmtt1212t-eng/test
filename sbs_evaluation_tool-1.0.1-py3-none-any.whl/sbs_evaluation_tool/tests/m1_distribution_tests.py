# core import
from ..core.base_test import BaseModelTest
from ..core.data_utils import ensure_config,  split_frames, get_features
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from scipy.stats import norm
import statsmodels.api as sm
# module imports
from tqdm import tqdm
import itertools
from typing import List, Dict, Union
from .psi_calculator import PSICalculator, PSICalculatorExtended
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import ensure_config
import logging
logger = logging.getLogger(__name__)


# Реализация тестов M 1.1 и M 1.2: сравнение TRAIN и OOS против GENPOP
class M11_TrainVsGenpopPSITest(BaseModelTest):
    def __init__(self, psi_calc: PSICalculatorExtended):
        super().__init__("M 1.1", "TRAIN vs GENPOP PSI Stability")
        self.psi_calc = psi_calc

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        cfg = ensure_config(config, df)
        df_train, _, df_genpop = split_frames(df, cfg)
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        features = get_features(df, cfg, include_categorical=True)
        cat_features = getattr(cfg.columns, 'categorical_features', []) or []
        target_column = cfg.columns.target_column

        # Для регрессии не делим по таргету (target_0/target_1), иначе получаются пустые выборки
        is_classification = getattr(cfg, 'task', 'classification') == 'classification'
        target_expected_series = df_train[cfg.columns.target_column] if is_classification else None
        target_actual_series = df_genpop[cfg.columns.target_column] if is_classification else None

        psi_results = {}
        all_psi_tables = {}
        for feature in tqdm(features, desc="M 1.1 - Processing Features"):
            psi_result = self.psi_calc.calculate(
                expected=df_train[feature],
                actual=df_genpop[feature],
                target_expected=target_expected_series,
                target_actual=target_actual_series,
                is_categorical=feature in cat_features
            )
            psi_results[feature] = self.psi_calc.generate_html_block(psi_result, feature)
            all_psi_tables[feature] = psi_result

        html, signal = self.psi_calc.generate_dashboard_table(all_psi_tables, return_signal=True)
        psi_results["DASHBOARD"] = html
        self.test_signal = signal
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return psi_results



class M12_OOSVsGenpopPSITest(BaseModelTest):
    def __init__(self, psi_calc: PSICalculatorExtended):
        super().__init__("M 1.2", "OOS vs GENPOP PSI Stability")
        self.psi_calc = psi_calc

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        cfg = ensure_config(config, df)
        _, df_oot, df_genpop = split_frames(df, cfg)
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        features = get_features(df, cfg, include_categorical=True)
        cat_features = getattr(cfg.columns, 'categorical_features', []) or []
        target_column = cfg.columns.target_column

        # Для регрессии не делим по таргету (target_0/target_1)
        is_classification = getattr(cfg, 'task', 'classification') == 'classification'
        target_expected_series = df_oot[cfg.columns.target_column] if is_classification else None
        target_actual_series = df_genpop[cfg.columns.target_column] if is_classification else None

        psi_results = {}
        all_psi_tables = {}
        for feature in tqdm(features, desc="M 1.2 - Processing Features"):
            psi_result = self.psi_calc.calculate(
                expected=df_oot[feature],
                actual=df_genpop[feature],
                target_expected=target_expected_series,
                target_actual=target_actual_series,
                is_categorical=feature in cat_features
            )
            psi_results[feature] = self.psi_calc.generate_html_block(psi_result, feature)
            all_psi_tables[feature] = psi_result

        html, signal = self.psi_calc.generate_dashboard_table(all_psi_tables, return_signal=True)
        psi_results["DASHBOARD"] = html
        self.test_signal = signal
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return psi_results



# --- M 1.3 — Max Date Recency ---
class M13_MaxDateRecencyTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 1.3", "Max Date Recency Check")

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        cfg = ensure_config(config, df)
        date_column = cfg.columns.date_column
        logger.info(f"Test {self.test_code} {self.test_name}: starting")

        max_date = pd.to_datetime(df[date_column]).max()
        today = pd.Timestamp.today().normalize()
        days_diff = (today - max_date).days

        if days_diff <= 180:
            signal = "green"
        elif days_diff <= 365:
            signal = "yellow"
        else:
            signal = "red"

        self.test_signal = signal

        html = f"""
        <h4>Max Date Recency</h4>
        <p><b>Max date in dataset:</b> {max_date.date()}</p>
        <p><b>Today:</b> {today.date()}</p>
        <p><b>Days difference:</b> <span style='color:red'><b>{days_diff} days</b></span></p>
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"date_recency": html}


## M 1.5 and M 1.6 were removed to avoid duplication with M0 informational tests



