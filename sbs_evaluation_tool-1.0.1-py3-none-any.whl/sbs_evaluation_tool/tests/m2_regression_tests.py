"""Regression-focused M2 tests split into multiple smaller test classes:
 - M21_GainCurveTest: train/test gain curves (normalized gini)
 - M22_RegressionMetricsTest: overall metrics table + comparison plot (R2/MAE/RMSE)
 - M23_CrunchedResidualsTest: crunched residuals tables and precise dependence plot
"""

import logging
import math
from io import BytesIO
import base64
from typing import Dict, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

from ..core.base_test import BaseModelTest
from ..core.styles import COLORS
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import ensure_config,  split_frames, get_score_col
from .m2_gini_tests import gini_normalized

logger = logging.getLogger(__name__)


# _split_frames_from_cfg, _score_from_cfg removed
# _gini_raw and normalized_gini removed (use tests.m2_gini_tests.gini_normalized)

def gini_gain_curve(y: np.ndarray, pred: np.ndarray, plot: bool = True) -> Tuple[pd.DataFrame, Optional[BytesIO]]:
    df = pd.DataFrame({'y': np.asarray(y, dtype=float), 'score': np.asarray(pred, dtype=float)})
    df = df.sort_values('score', ascending=False).reset_index(drop=True)
    df['cum_pop'] = (np.arange(len(df)) + 1) / len(df)
    total = df['y'].sum() if df['y'].sum() > 0 else 1.0
    df['cum_target'] = df['y'].cumsum() / total

    img_buf = None
    if plot:
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(df['cum_pop'], df['cum_target'], label='Gain curve')
        ax.plot([0, 1], [0, 1], linestyle='--', color=COLORS['GRAY'], label='Random')
        ax.set_xlabel('Share of Population')
        ax.set_ylabel('Share of Target Captured')
        try:
            g = gini_normalized(y, pred)
        except Exception:
            g = float('nan')
        ax.set_title(f'Gain Curve - Normalized Gini {g:.4f}')
        ax.legend(frameon=False)
        buf = BytesIO()
        fig.savefig(buf, format='png', bbox_inches='tight')
        buf.seek(0)
        img_buf = buf
        plt.close(fig)

    return df[['cum_pop', 'cum_target']], img_buf


def _fig_to_base64_buf(fig) -> BytesIO:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    plt.close(fig)
    return buf


def _embed_buf(buf: Optional[BytesIO]) -> str:
    if buf is None:
        return ''
    b64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    return f'<img src="data:image/png;base64,{b64}"/>'


def bootstrap_ci(metric_fn, y, pred, n_boot=200, alpha=0.05):
    rng = np.random.default_rng(42)
    n = len(y)
    if n == 0:
        return float('nan'), float('nan'), float('nan')
    vals = []
    idx = np.arange(n)
    for _ in range(n_boot):
        sel = rng.choice(idx, size=n, replace=True)
        vals.append(metric_fn(y[sel], pred[sel]))
    arr = np.array(vals)
    lower = np.quantile(arr, alpha / 2)
    upper = np.quantile(arr, 1 - alpha / 2)
    return float(np.mean(arr)), float(lower), float(upper)


def crunched_residuals(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    n_groups: int,
) -> pd.DataFrame:
    """
    Считает 'crunched residuals' по n_groups последовательных блокам.

    Метрики на группу:
      - residuals_c = sum(y_true - y_pred) / sqrt(n * Var(y_pred))
      - mean_pred    : среднее предсказаний
      - variance     : дисперсия предсказаний (ddof=1)
      - min_pred/max_pred
      - group_size

    Возвращает: pd.DataFrame с одной строкой на группу.
    """
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)

    if y_true.shape != y_pred.shape:
        raise ValueError("y_true и y_pred должны иметь одинаковую длину.")
    if not (1 <= n_groups <= len(y_pred)):
        raise ValueError("n_groups должен быть в диапазоне [1, len(y)].")

    # Разбиваем индексы на группы; «хвост» корректно распределяется по первым группам
    idx_groups = np.array_split(np.arange(len(y_pred)), n_groups)

    rows = []
    for g, idx in enumerate(idx_groups, start=1):
        yp = y_pred[idx]
        yt = y_true[idx]
        n = len(idx)

        var = float(np.var(yp, ddof=1)) if n > 1 else 0.0
        sum_err = float(np.sum(yt - yp))
        denom = np.sqrt(n * var)
        resid_c = sum_err / denom if denom > 0 else 0.0

        rows.append({
            "group": g,
            "residuals_c": resid_c,
            "mean_pred": float(np.mean(yp)) if n else np.nan,
            "variance": var,
            "min_pred": float(np.min(yp)) if n else np.nan,
            "max_pred": float(np.max(yp)) if n else np.nan,
            "group_size": int(n),
        })

    return pd.DataFrame(rows)


class M21_GainCurveTest(BaseModelTest):
    """Produce gain curves (normalized gini) for train and test."""

    def __init__(self):
        super().__init__('M 2.1', 'Gain curve (regression)')

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_train, df_test, _ = split_frames(df, cfg)
        try:
            score_col = get_score_col(cfg)
        except ConfigValidationError:
            return {"error": "Columns.score_column not set in config"}
        target_col = cfg.columns.target_column

        outputs: Dict[str, str] = {}

        # guard
        if target_col is None or score_col is None:
            return {"error": "target or score column not set in config"}

        y_tr = df_train[target_col].to_numpy(dtype=float)
        s_tr = df_train[score_col].to_numpy(dtype=float)
        y_te = df_test[target_col].to_numpy(dtype=float)
        s_te = df_test[score_col].to_numpy(dtype=float)

        _, train_buf = gini_gain_curve(y_tr, s_tr, plot=True)
        _, test_buf = gini_gain_curve(y_te, s_te, plot=True)

        outputs['gain_train'] = f"<h4>Train gain curve (normalized gini={gini_normalized(y_tr, s_tr):.4f})</h4>" + _embed_buf(train_buf)
        outputs['gain_test'] = f"<h4>Test gain curve (normalized gini={gini_normalized(y_te, s_te):.4f})</h4>" + _embed_buf(test_buf)

        # Informational test — no traffic-light; log as info/blue
        self.test_signal = 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return outputs


class M22_RegressionMetricsTest(BaseModelTest):
    """Compute overall metrics (R2/MAE/RMSE) and show table + comparison plot."""

    def __init__(self, n_boot: int = 200):
        super().__init__('M 2.2', 'Regression metrics and comparison plot')
        self.n_boot = int(n_boot)

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_train, df_test, _ = split_frames(df, cfg)
        try:
            score_col = get_score_col(cfg)
        except ConfigValidationError:
            return {"error": "Columns.score_column not set in config"}
        target_col = cfg.columns.target_column

        outputs: Dict[str, str] = {}

        if target_col is None or score_col is None:
            return {"error": "target or score column not set in config"}

        y_tr = df_train[target_col].to_numpy(dtype=float)
        s_tr = df_train[score_col].to_numpy(dtype=float)
        y_te = df_test[target_col].to_numpy(dtype=float)
        s_te = df_test[score_col].to_numpy(dtype=float)

        def rmse(y, p):
            return math.sqrt(mean_squared_error(y, p))

        metrics = {
            'Train': {
                'R2': r2_score(y_tr, s_tr) if len(y_tr) > 0 else float('nan'),
                'MAE': mean_absolute_error(y_tr, s_tr) if len(y_tr) > 0 else float('nan'),
                'RMSE': rmse(y_tr, s_tr) if len(y_tr) > 0 else float('nan')
            },
            'Test': {
                'R2': r2_score(y_te, s_te) if len(y_te) > 0 else float('nan'),
                'MAE': mean_absolute_error(y_te, s_te) if len(y_te) > 0 else float('nan'),
                'RMSE': rmse(y_te, s_te) if len(y_te) > 0 else float('nan')
            }
        }

        # table
        mt = pd.DataFrame(metrics).T.round(4)
        outputs['metrics_table'] = '<h4>Overall metrics</h4>' + mt.to_html(float_format='%.4f')

        # bar plot comparing Train vs Test for each metric
        fig, ax = plt.subplots(figsize=(6, 4))
        labels = ['R2', 'MAE', 'RMSE']
        train_vals = [metrics['Train'][k] for k in labels]
        test_vals = [metrics['Test'][k] for k in labels]
        x = np.arange(len(labels))
        width = 0.35
        ax.bar(x - width/2, train_vals, width, label='Train', color=COLORS['BLUE'])
        ax.bar(x + width/2, test_vals, width, label='Test', color=COLORS['EMERALD'])
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.set_title('Train vs Test - R2 / MAE / RMSE')
        ax.legend(frameon=False)
        buf = _fig_to_base64_buf(fig)
        outputs['metrics_plot'] = _embed_buf(buf)

        # --- stability over time (monthly) for R2 / MAE / RMSE (train vs test)
        time_col = getattr(cfg.columns, 'date_column', None)
        sample_col = getattr(cfg.columns, 'sample_column', None)
        if time_col and time_col in df.columns and sample_col and sample_col in df.columns:
            try:
                tmp = df[[time_col, sample_col, score_col, target_col]].copy()
                tmp[time_col] = pd.to_datetime(tmp[time_col], errors='coerce')
                tmp = tmp.dropna(subset=[time_col, score_col, target_col, sample_col])
                tmp['_period_'] = tmp[time_col].dt.to_period('M').astype(str)
                periods = sorted(tmp['_period_'].unique())

                rows = []
                train_series = {'period': [], 'R2': [], 'MAE': [], 'RMSE': []}
                test_series = {'period': [], 'R2': [], 'MAE': [], 'RMSE': []}
                for p in periods:
                    g = tmp[tmp['_period_'] == p]
                    g_tr = g[g[sample_col].astype(str).str.lower() == 'train']
                    g_te = g[g[sample_col].astype(str).str.lower() == 'test']

                    def safe_metrics(sub):
                        if len(sub) == 0:
                            return float('nan'), float('nan'), float('nan')
                        y = sub[target_col].to_numpy(dtype=float)
                        s = sub[score_col].to_numpy(dtype=float)
                        return (
                            r2_score(y, s) if len(y) > 0 else float('nan'),
                            mean_absolute_error(y, s) if len(y) > 0 else float('nan'),
                            math.sqrt(mean_squared_error(y, s)) if len(y) > 0 else float('nan')
                        )

                    r2_tr, mae_tr, rmse_tr = safe_metrics(g_tr)
                    r2_te, mae_te, rmse_te = safe_metrics(g_te)

                    train_series['period'].append(p)
                    train_series['R2'].append(r2_tr)
                    train_series['MAE'].append(mae_tr)
                    train_series['RMSE'].append(rmse_tr)

                    test_series['period'].append(p)
                    test_series['R2'].append(r2_te)
                    test_series['MAE'].append(mae_te)
                    test_series['RMSE'].append(rmse_te)

                    rows.append({
                        'period': p,
                        'n_train': len(g_tr), 'r2_train': r2_tr, 'mae_train': mae_tr, 'rmse_train': rmse_tr,
                        'n_test': len(g_te), 'r2_test': r2_te, 'mae_test': mae_te, 'rmse_test': rmse_te,
                    })

                if rows:
                    per_df = pd.DataFrame(rows)
                    outputs['metrics_by_period_table'] = '<h4>Metrics by period (monthly)</h4>' + per_df.to_html(index=False, float_format='%.4f')

                    # plot three subplots
                    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
                    x = np.arange(len(train_series['period']))
                    xticks = train_series['period']

                    # R2 (higher better)
                    axes[0].plot(x, train_series['R2'], marker='o', color=COLORS['BLUE'], label='Train')
                    axes[0].plot(x, test_series['R2'], marker='o', color=COLORS['EMERALD'], label='Test')
                    axes[0].set_ylabel('R2')
                    axes[0].legend(frameon=False)
                    axes[0].grid(True, linestyle='--', alpha=0.5)

                    # MAE (lower better)
                    axes[1].plot(x, train_series['MAE'], marker='o', color=COLORS['BLUE'], label='Train')
                    axes[1].plot(x, test_series['MAE'], marker='o', color=COLORS['EMERALD'], label='Test')
                    axes[1].set_ylabel('MAE')
                    axes[1].legend(frameon=False)
                    axes[1].grid(True, linestyle='--', alpha=0.5)

                    # RMSE (lower better)
                    axes[2].plot(x, train_series['RMSE'], marker='o', color=COLORS['BLUE'], label='Train')
                    axes[2].plot(x, test_series['RMSE'], marker='o', color=COLORS['EMERALD'], label='Test')
                    axes[2].set_ylabel('RMSE')
                    axes[2].set_xticks(x)
                    axes[2].set_xticklabels(xticks, rotation=45, ha='right')
                    axes[2].legend(frameon=False)
                    axes[2].grid(True, linestyle='--', alpha=0.5)

                    fig.suptitle('Metric Stability over Time (Monthly)')
                    buf = _fig_to_base64_buf(fig)
                    outputs['metrics_stability_plot'] = _embed_buf(buf)
            except Exception:
                # non-fatal; skip stability plot
                pass

        self.test_signal = 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return outputs


class M23_CrunchedResidualsTest(BaseModelTest):
    """Produce crunched residuals tables for train/test and a precise dependence plot.

    The plot shows group mean_pred vs residuals_c with a smoothing/regression line to visualise dependence.
    """

    def __init__(self, n_groups: int = 500):
        super().__init__('M 2.3', 'Crunched residuals')
        self.n_groups = int(n_groups)

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_train, df_test, _ = split_frames(df, cfg)
        try:
            score_col = get_score_col(cfg)
        except ConfigValidationError:
            return {"error": "Columns.score_column not set in config"}
        target_col = cfg.columns.target_column

        outputs: Dict[str, str] = {}

        if target_col is None or score_col is None:
            return {"error": "target or score column not set in config"}

        y_tr = df_train[target_col].to_numpy(dtype=float)
        s_tr = df_train[score_col].to_numpy(dtype=float)
        y_te = df_test[target_col].to_numpy(dtype=float)
        s_te = df_test[score_col].to_numpy(dtype=float)

        try:
            cr_tr = crunched_residuals(y_tr, s_tr, n_groups=self.n_groups)
            cr_te = crunched_residuals(y_te, s_te, n_groups=self.n_groups)
            outputs['crunched_train_table'] = '<h4>Crunched residuals (train)</h4>' + cr_tr.to_html(index=False, float_format='%.4f')
            outputs['crunched_test_table'] = '<h4>Crunched residuals (test)</h4>' + cr_te.to_html(index=False, float_format='%.4f')

            # precise dependence plot: mean_pred vs residuals_c for train and test
            fig, ax = plt.subplots(figsize=(10, 6))
            # use cross markers, smaller edge width and semi-transparent points
            ax.scatter(
                cr_tr['mean_pred'], cr_tr['residuals_c'], label='Train', color=COLORS['BLUE'],
                marker='x', s=60, linewidths=0.8, alpha=0.6
            )
            ax.scatter(
                cr_te['mean_pred'], cr_te['residuals_c'], label='Test', color=COLORS['EMERALD'],
                marker='x', s=60, linewidths=0.8, alpha=0.6
            )

            # (no per-point labels) — compute average group size for title and add grid
            combined_sizes = []
            if 'group_size' in cr_tr.columns and len(cr_tr) > 0:
                combined_sizes.append(cr_tr['group_size'].to_numpy())
            if 'group_size' in cr_te.columns and len(cr_te) > 0:
                combined_sizes.append(cr_te['group_size'].to_numpy())
            if combined_sizes:
                all_sizes = np.concatenate(combined_sizes)
                avg_size = float(np.mean(all_sizes))
            else:
                avg_size = float('nan')

            ax.grid(True, linestyle='--', alpha=0.6)

            # add linear trend lines if enough points
            if len(cr_tr) > 1:
                z = np.polyfit(cr_tr['mean_pred'], cr_tr['residuals_c'], 1)
                p = np.poly1d(z)
                xs = np.linspace(min(cr_tr['mean_pred']), max(cr_tr['mean_pred']), 100)
                ax.plot(xs, p(xs), color=COLORS['BLUE'], alpha=0.9, linewidth=1.8)
            if len(cr_te) > 1:
                z2 = np.polyfit(cr_te['mean_pred'], cr_te['residuals_c'], 1)
                p2 = np.poly1d(z2)
                xs2 = np.linspace(min(cr_te['mean_pred']), max(cr_te['mean_pred']), 100)
                ax.plot(xs2, p2(xs2), color=COLORS['EMERALD'], alpha=0.9, linewidth=1.8)
            ax.set_xlabel('Mean Prediction (Group)')
            ax.set_ylabel('Crunched Residuals')
            size_str = f"{avg_size:.0f}" if np.isfinite(avg_size) else 'n/a'
            ax.set_title(f"Crunched Residuals: Mean Prediction vs Residuals (groups={self.n_groups}, avg_size≈{size_str})")
            ax.legend(frameon=False)
            buf = _fig_to_base64_buf(fig)
            outputs['crunched_dependence_plot'] = _embed_buf(buf)
        except Exception as exc:
            outputs['error'] = f'Failed to compute crunched residuals: {exc}'

        self.test_signal = 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return outputs
