import base64
from io import BytesIO
import matplotlib.pyplot as plt
from uuid import uuid4


SCALE_TITLE_LINEAR = "Linear Scale"
SCALE_TITLE_LOG = "Log Scale"
OBSERVATION_COUNT_LABEL = "Observation Count"
SHARE_LABEL = "Share"
MEAN_RATE_LABEL = "Mean Rate"
TARGET_RATE_LABEL = "Target Rate"

PERIOD_LABELS = {
    "W": "Weekly",
    "M": "Monthly",
    "Q": "Quarterly",
}


def build_scale_specs(show_both_scales: bool, use_log_scale: bool) -> list[tuple[bool, str]]:
    if show_both_scales:
        return [
            (False, SCALE_TITLE_LINEAR),
            (True, SCALE_TITLE_LOG),
        ]
    return [
        (use_log_scale, SCALE_TITLE_LOG if use_log_scale else SCALE_TITLE_LINEAR),
    ]


def build_period_specs(requested_period: str | None) -> list[tuple[str, str]]:
    if requested_period is None:
        return [("W", PERIOD_LABELS["W"]), ("M", PERIOD_LABELS["M"]), ("Q", PERIOD_LABELS["Q"])]
    return [(requested_period, PERIOD_LABELS[requested_period])]


def figure_to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
    plt.close(fig)
    return encoded


def apply_standard_axis_style(
    ax,
    *,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    legend_loc: str | None = "best",
    title_size: int = 13,
    label_size: int = 11,
) -> None:
    if title is not None:
        ax.set_title(title, fontsize=title_size, fontweight="bold", pad=12)
    if xlabel is not None:
        ax.set_xlabel(xlabel, fontsize=label_size)
    if ylabel is not None:
        ax.set_ylabel(ylabel, fontsize=label_size)
    ax.grid(True, linestyle="--", linewidth=0.6, alpha=0.3)
    handles, labels = ax.get_legend_handles_labels()
    if legend_loc and handles:
        ax.legend(loc=legend_loc, frameon=False)


def apply_secondary_axis_style(
    ax,
    *,
    ylabel: str | None = None,
    legend_loc: str | None = None,
    label_size: int = 11,
) -> None:
    if ylabel is not None:
        ax.set_ylabel(ylabel, fontsize=label_size)
    handles, labels = ax.get_legend_handles_labels()
    if legend_loc and handles:
        ax.legend(loc=legend_loc, frameon=False)


def build_tabbed_sections_html(
    tabs: list[dict],
    *,
    root_prefix: str = "tabs",
) -> str:
    root_id = f"{root_prefix}-{uuid4().hex}"
    button_html = []
    panel_html = []

    for idx, tab in enumerate(tabs):
        active = "true" if idx == 0 else "false"
        display = "block" if idx == 0 else "none"
        color = tab.get("color", "#2b2f38")
        button_html.append(
            f"""
            <button type="button"
                    data-tab-target="{root_id}-panel-{idx}"
                    data-tab-button="{root_id}"
                    aria-selected="{active}"
                    style="padding:8px 14px; border:1px solid #d9dee8; background:#fff; cursor:pointer; border-radius:8px; color:{color}; font-weight:600;">
                {tab['label']}
            </button>
            """
        )
        panel_html.append(
            f"""
            <div id="{root_id}-panel-{idx}" data-tab-panel="{root_id}" style="display:{display}; margin-top:16px;">
                {tab['html']}
            </div>
            """
        )

    script = f"""
    <script>
    (function() {{
        var root = document.getElementById('{root_id}');
        if (!root) return;
        var buttons = root.querySelectorAll('button[data-tab-button="{root_id}"]');
        var panels = root.querySelectorAll('div[data-tab-panel="{root_id}"]');
        buttons.forEach(function(btn) {{
            btn.addEventListener('click', function() {{
                var targetId = btn.getAttribute('data-tab-target');
                buttons.forEach(function(other) {{ other.setAttribute('aria-selected', 'false'); }});
                panels.forEach(function(panel) {{ panel.style.display = 'none'; }});
                btn.setAttribute('aria-selected', 'true');
                var target = document.getElementById(targetId);
                if (target) target.style.display = 'block';
            }});
        }});
    }})();
    </script>
    """

    return f"""
    <div id="{root_id}">
        <div style="display:flex; gap:8px; flex-wrap:wrap; margin:14px 0 8px 0;">
            {''.join(button_html)}
        </div>
        {''.join(panel_html)}
    </div>
    {script}
    """
