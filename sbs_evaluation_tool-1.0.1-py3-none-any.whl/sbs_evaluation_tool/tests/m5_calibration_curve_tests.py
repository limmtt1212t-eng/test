# Core import
from ..core.base_test import BaseModelTest
from ..core.styles import COLORS, STATUS_COLORS
import logging

#Math
import numpy as np
from scipy.stats import binom
from scipy.stats import norm
import statsmodels.api as sm
from io import BytesIO
import base64

# Data
import pandas as pd
import numpy as np

# default imports
import matplotlib.pyplot as plt
import base64

# Settings
from typing import Optional, List, Dict
from sklearn.utils.multiclass import type_of_target
from ._visual_utils import MEAN_RATE_LABEL, OBSERVATION_COUNT_LABEL, TARGET_RATE_LABEL

# Module logger
logger = logging.getLogger(__name__)


def _weighted_mean(y: pd.Series, w: Optional[pd.Series] = None) -> float:
    y = pd.to_numeric(y, errors="coerce")
    if w is None:
        return float(y.mean())
    w = pd.to_numeric(w, errors="coerce").reindex(y.index).fillna(0.0)
    sw = w.sum()
    if sw <= 0:
        return float(y.mean())
    return float((y * w).sum() / sw)

def binning_data_for_binom(y_true, y_pred):
    # для входных данных формирует новый столбец для биннирования
    pass



def calculate_binom_test(n: int, obs_rate: float, pred_rate: float) -> float:
    """
    Вычисляет метрику симметрии хвостов биномиального распределения
    для оценки соответствия между фактической и предсказанной долей успехов
    в рамках одного бакета.

    Формула:
        result = |P(X ≤ k) - P(X ≥ k)|,
        где X ~ Bin(n, pred_rate),
              k = round(n * obs_rate)

    Интерпретация результата:
        - result ≈ 0  — фактическая доля хорошо согласуется с прогнозом.
        - result ≈ 1  — наблюдаемая доля лежит в одном из хвостов распределения, предсказание плохо согласуется с фактом.

    Параметры:
        * n (int): Общее количество наблюдений в бакете.
        * obs_rate (float): Фактическая доля успехов (mean_true).
        * pred_rate (float): Предсказанная вероятность успеха (mean_pred).

    Возвращает:
        * float: метрика калибровочной симметрии.
    """
    k = np.round(obs_rate * n, 0).astype(int)
    cdf = binom.cdf(k, n, pred_rate)  # Левый хвост        
    pmf = binom.pmf(k, n, pred_rate)  # P(X = k)        
    return abs(cdf - (1 - cdf + pmf)) # Разность хвостов


class M51_TargetRateTest(BaseModelTest): 
    def __init__(self, test_num='M 5.1', test_name='Predicted vs Observed Rate of Target'):
        super().__init__(test_num, test_name)

    # --- CI helpers (аналитические, без тяжёлого бутстрапа) ---
    @staticmethod
    def _ci_mean_classification(y: np.ndarray, z: float, w: Optional[np.ndarray] = None) -> tuple:
        y = np.asarray(y).astype(float)
        if w is not None:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            sw = np.sum(w)
            if sw <= 0:
                w = None
        n = max(1, y.size)
        if w is None:
            p = float(y.mean())
            se = np.sqrt(max(p * (1 - p), 0.0) / n)
        else:
            p = float(np.sum(y * w) / np.sum(w))
            var = max(p * (1 - p), 0.0)
            se = np.sqrt(var / max(1.0, np.sum(w)))
        return (p - z * se, p + z * se)

    @staticmethod
    def _ci_mean_regression(y: np.ndarray, z: float, w: Optional[np.ndarray] = None) -> tuple:
        y = np.asarray(y).astype(float)
        if w is not None:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            sw = np.sum(w)
            if sw <= 0:
                w = None
        n = max(1, y.size)
        if w is None:
            m = float(y.mean())
            s = float(np.nanstd(y, ddof=1)) if n > 1 else 0.0
        else:
            m = float(np.sum(y * w) / np.sum(w))
            s2 = np.sum(w * (y - m) ** 2) / max(1.0, np.sum(w))
            s = float(np.sqrt(max(s2, 0.0)))
        se = s / np.sqrt(n) if n > 0 else 0.0
        return (m - z * se, m + z * se)

    def determine_signal(self, mean_pred, ci_95: tuple, ci_99: tuple) -> str:
        """
        Определяет сигнал на основе среднего значения и доверительных интервалов.

        Параметры:
            * mean_true (float): Среднее значение.
            * ci_95 (tuple): Доверительный интервал 95%.
            * ci_99 (tuple): Доверительный интервал 99%.

        Возвращает:
            * str: Сигнал ("green", "orange" или "red").
        """
        if ci_95[0] <= mean_pred <= ci_95[1]:
            return "green"
        elif ci_99[0] <= mean_pred <= ci_99[1]:
            return "orange"
        return "red"

    def plot_target_rate(self, mean_true, mean_pred, ci_95, ci_99) -> str:
        """
        Создает график, сравнивающий наблюдаемый и предсказанный показатели c доверительным интервалом.

        Параметры:
            * mean_true (float): Наблюдаемый показатель.
            * mean_pred (float): Предсказанный показатель.
            * ci_99 (tuple): Доверительный интервал 99%.
            * ci_95 (tuple): Доверительный интервал 95%.

        Возвращает:
            * str: Кодированный в base64 изображение графика.
        """
        
        from matplotlib.lines import Line2D
        fig, ax = plt.subplots(figsize=(8, 4.5))
        xmin, xmax = -0.2, 0.2
        # 99% CI — красные линии
        ax.hlines([ci_99[0], ci_99[1]], xmin=xmin, xmax=xmax, colors=COLORS['RED'], linewidth=2)
        # 95% CI — жёлтые линии
        ax.hlines([ci_95[0], ci_95[1]], xmin=xmin, xmax=xmax, colors=COLORS['YELLOW'], linewidth=3)

        # Точки средних
        ax.scatter([0], [mean_true], color=COLORS['BLUE'], s=60, label="Observed Mean")
        ax.scatter([0], [mean_pred], color=COLORS['GRAY'], s=60, label="Predicted Mean")

        # Оформление осей и легенды
        ax.set_xlim(-0.5, 0.5)
        ymin = min(ci_99[0], ci_95[0], mean_true, mean_pred)
        ymax = max(ci_99[1], ci_95[1], mean_true, mean_pred)
        ax.set_ylim(ymin - 0.02 * (ymax - ymin), ymax + 0.02 * (ymax - ymin))
        ax.set_xticks([])
        ax.set_title("Observed vs Predicted Mean with 95%/99% CI")

        legend_lines = [
            Line2D([0], [0], color=COLORS['YELLOW'], lw=3, label="95% CI"),
            Line2D([0], [0], color=COLORS['RED'], lw=2, label="99% CI"),
        ]
        scatter = [
            Line2D([0], [0], marker='o', color='w', label='Observed Mean', markerfacecolor=COLORS['BLUE'], markersize=8),
            Line2D([0], [0], marker='o', color='w', label='Predicted Mean', markerfacecolor=COLORS['GRAY'], markersize=8),
        ]
        ax.legend(handles=legend_lines + scatter, loc='upper right')
        plt.tight_layout()
        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, score: pd.Series, target: pd.Series, weight: Optional[pd.Series] = None) -> Dict[str, str]:
        """
        Выполняет тест для сравнения предсказанного и наблюдаемого показателей, возвращая HTML-код с результатами.

        Этот метод вычисляет средние значения для наблюдаемых и предсказанных данных, определяет доверительные интервалы
        для предсказанных значений с уровнями значимости 95% и 99%, определяет светофор на основе среднего значения и
        доверительных интервалов, создает график для визуализации результатов и формирует HTML-код с результатами теста.


        Параметры:
            * score (pd.Series): Серия предсказанных значений.
            * target (pd.Series): Серия наблюдаемых значений.

        Возвращает:
            * Dict[str, str]: Словарь с HTML-кодом графика и результатами анализа.

        Исключения:
            * ValueError: Если Score или Target не являются числовыми или содержат NaN.
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        if not pd.api.types.is_numeric_dtype(score) or not pd.api.types.is_numeric_dtype(target):
            raise ValueError("Score и Target должны быть числовыми")
        if score.isnull().any() or target.isnull().any():
            raise ValueError("Score и Target не должны содержать NaN")

        w = None
        if weight is not None:
            w_s = pd.to_numeric(weight, errors="coerce").reindex(target.index).fillna(0.0)
            if (w_s > 0).sum() > 0:
                w = w_s.to_numpy(dtype=float)

        mean_true = _weighted_mean(target, weight if weight is not None else None)
        mean_pred = _weighted_mean(score, weight if weight is not None else None)

        # Определяем режим и строим CI вокруг среднего таргета
        mode = 'classification' if type_of_target(target) == 'binary' else 'regression'
        if mode == 'classification':
            ci_95 = self._ci_mean_classification(target.values, 1.96, w)
            ci_99 = self._ci_mean_classification(target.values, 2.58, w)
        else:
            ci_95 = self._ci_mean_regression(target.values, 1.96, w)
            ci_99 = self._ci_mean_regression(target.values, 2.58, w)

        signal = self.determine_signal(mean_pred, ci_95, ci_99)
        self.test_signal = signal

        plot_encoded = self.plot_target_rate(mean_true, mean_pred, ci_95, ci_99)

        html = f"""
        <h4>Predicted vs Observed Rate of Target</h4>
    <p><b>Observed mean:</b> {mean_true:.6f}</p>
    <p><b>Predicted mean:</b> {mean_pred:.6f}</p>
        <p><b>95% CI:</b> ({ci_95[0]:.4f}, {ci_95[1]:.4f})</p>
        <p><b>99% CI:</b> ({ci_99[0]:.4f}, {ci_99[1]:.4f})</p>
        <p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span></p>
        <img src="data:image/png;base64,{plot_encoded}">
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M52_CalibrationCurveByPredictBins(BaseModelTest):
    def __init__(self, test_num='M 5.2', test_name='Calibration Curve (Grouped by Predict Bins)'):
        self.test_signal = None
        super().__init__(test_num, test_name)
    
 
    def determine_signal(self, metric_values: pd.Series, mode: str) -> tuple:
        """
        Определяет сигнал на основе результатов биномиального теста.

        Функция анализирует количество значений в столбце, превышающих пороговые значения 0.99 и 0.95,
        и на основе этого определяет сигнал: "red", "orange" или "green".

        Параметры:
            * metric_values (pd.Series): Столбец с метрикой соответствия:
                - для классификации: разность хвостов биномиального распределения (0..1), выше — хуже;
                - для регрессии: |z|-оценка отклонения среднего (0..inf), выше — хуже.
            * mode (str): 'classification' или 'regression'

        Возвращает:
            * tuple: Кортеж, содержащий сигнал (str) и количество значений, превышающих пороги 0.99 и 0.95 (int, int).

        Логика определения сигнала:
            - "red": если более 10% значений превышают 0.99 или более 30% значений превышают 0.95.
            - "orange": если более 10% значений превышают 0.99 или более 10% значений превышают 0.95.
            - "green": в остальных случаях.
        """
        
        if mode == 'classification':
            n_99 = (metric_values > 0.99).sum()
            n_95 = (metric_values > 0.95).sum()
        else:
            # regression: z-score thresholds ~ 2.58 (99%), 1.96 (95%)
            n_99 = (metric_values > 2.58).sum()
            n_95 = (metric_values > 1.96).sum()

        if n_99 > int(len(metric_values) * 0.1) and n_95 > int(len(metric_values) * 0.3): 
            signal = "red"
        elif n_99 > int(len(metric_values) * 0.1) or n_95 > int(len(metric_values) * 0.1):
            signal = "orange"
        else:
            signal = "green"

        
        return signal, n_99, n_95


    def plot_calibration_curve(self, grouped: pd.DataFrame, mode: str) -> str:
        """
        Строит кривую калибровки для заданного DataFrame. Функция строит график, отображающий кривую среднего предсказания и точки со средним таргетом.
        Подписи осей и заголовок графика настроены для лучшей читаемости.

        Параметры:
        ----------
        * grouped : pd.DataFrame
            DataFrame, содержащий столбцы 'bin', 'mean_true' и 'mean_pred', 'count'.
            - 'bin': интервалы предсказанных вероятностей.
            - 'mean_true': среднее значение истинного таргета в каждом интервале.
            - 'mean_pred': среднее значение предсказанного таргета в каждом интервале.
            - 'count': количество наблюдений в каждом интервале.

        Возвращает:
        -------
        * str
            График в формате base64, который можно встроить в HTML.
        """
        fig, ax = plt.subplots(figsize=(10, 6))

        # X as numeric positions for proper fill_between
        x = np.arange(len(grouped))
        labels = grouped["bin"].astype(str).tolist()

        # Compute CI bands
        if mode == 'classification':
            p = grouped["mean_pred"].clip(0, 1)
            n = grouped["count"].replace(0, np.nan)
            se = np.sqrt((p * (p - 1)).abs() / n)  # guard; use p*(1-p)
            se = np.sqrt(p * (1 - p)) / np.sqrt(n)
            ci95_low = (p - 1.96 * se).clip(lower=0)
            ci95_high = (p + 1.96 * se).clip(upper=1)
            ci99_low = (p - 2.58 * se).clip(lower=0)
            ci99_high = (p + 2.58 * se).clip(upper=1)
        else:
            n = grouped["count"].replace(0, np.nan)
            se = grouped.get("std_true", pd.Series([np.nan]*len(grouped))) / np.sqrt(n)
            m = grouped["mean_pred"]
            ci95_low = (m - 1.96 * se)
            ci95_high = (m + 1.96 * se)
            ci99_low = (m - 2.58 * se)
            ci99_high = (m + 2.58 * se)

        # Shaded CI areas (draw wider 99% first)
        ax.fill_between(x, ci99_low, ci99_high, color=COLORS['RED'], alpha=0.15, label="99% CI")
        ax.fill_between(x, ci95_low, ci95_high, color=COLORS['YELLOW'], alpha=0.25, label="95% CI")

        # Plot the observed mean target and predicted line
        ax.plot(x, grouped["mean_true"], label="Observed", marker="o", linestyle='-', color=COLORS['BLUE'])
        ax.plot(x, grouped["mean_pred"], label="Predicted", linestyle="--", color=COLORS['GRAY'])

        # Add labels and title
        ax.set_xlabel("Prediction Bins")
        ax.set_ylabel(MEAN_RATE_LABEL)
        ax.set_title("Calibration Curve by Prediction Bins")

        # X ticks as bin labels
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=45, ha='right')

        # Add legend
        ax.legend(frameon=False)

        # Create a secondary y-axis for the count of observations
        ax2 = ax.twinx()
        ax2.bar(x, grouped["count"], alpha=0.25, color=COLORS['EMERALD'], label="Count")
        ax2.set_ylabel(OBSERVATION_COUNT_LABEL)

        # Tight layout for better spacing
        plt.tight_layout()

        # Save the plot to a bytes buffer
        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)

        return base64.b64encode(buf.getvalue()).decode()


    def run(self, score: pd.Series, target: pd.Series, num_groups:int = 20, bins_step: float = None,
             weight: Optional[pd.Series] = None) -> dict:
        """
        Выполняет тест калибровочной кривой, группируя предсказания по интервалам и оценивая соответствие между фактическими и предсказанными значениями.

        Метод разбивает предсказания на интервалы, вычисляет средние фактические и предсказанные значения для каждого интервала,
        определяет сигнал на основе биномиального теста и строит график калибровочной кривой.

        Параметры:
            * score (pd.Series): Серия с предсказанными значениями.
            * target (pd.Series): Серия с фактическими значениями.
            * num_groups (int, optional): Количество групп для разбиения предсказаний. По умолчанию 20.
            * bins_step (float, optional): Шаг для разбиения предсказаний на интервалы. По умолчанию None.

        Возвращает:
            * dict: Словарь, содержащий HTML-код с результатами теста, включая график калибровочной кривой, сигнал и статистику по группам.

        Логика выполнения:
            1. Разбивает предсказания на интервалы с использованием заданного шага или количества групп.
            2. Вычисляет средние фактические и предсказанные значения для каждого интервала.
            3. Применяет биномиальный тест для оценки соответствия между фактическими и предсказанными значениями.
            4. Определяет сигнал на основе результатов биномиального теста.
            5. Формирует HTML-код с результатами теста, включая график, сигнал и статистику по группам.
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        if not pd.api.types.is_numeric_dtype(score) or not pd.api.types.is_numeric_dtype(target):
            raise ValueError("Score и Target должны быть числовыми.")
        if score.isnull().any() or target.isnull().any():
            raise ValueError("Score и Target не должны содержать NaN.")
        if not bins_step and len(score) < num_groups:
            raise ValueError("Недостаточно данных для указанного числа групп. Используйте bins_step или уменьшете кол-во групп.")
        if len(score) != len(target):
            raise ValueError("Длина Score и Target должна быть одинаковой.")

        df = pd.DataFrame({"score": score, "target": target})
        if weight is not None:
            df["weight"] = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)

        # Bin the predictions
        if bins_step:
            bins = np.arange(0, score.max() + bins_step, bins_step)
            df["bin"] = pd.cut(df["score"], bins=bins, include_lowest=True)
        else: 
            df['bin'] = pd.qcut(df['score'], q=num_groups)

        if "weight" in df.columns:
            grouped = df.groupby("bin", observed=False).apply(
                lambda g: pd.Series({
                    "count": float(g["weight"].sum()),
                    "mean_true": float(np.average(g["target"], weights=g["weight"])),
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    "std_true": float(np.sqrt(np.average((g["target"] - np.average(g["target"], weights=g["weight"])) ** 2,
                                                         weights=g["weight"])) if g["weight"].sum() > 0 else 0.0),
                })
            ).reset_index()
        else:
            grouped = df.groupby("bin", observed=False).agg(
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        # Determine target type
        mode = 'classification' if type_of_target(target) == 'binary' else 'regression'
        if mode == 'classification':
            grouped['metric'] = grouped.apply(lambda row: calculate_binom_test(int(row['count']), float(row['mean_true']), float(row['mean_pred'])), axis=1)
        else:
            # z-score for mean difference per bin; guard against zero std
            def _z(row):
                se = (row['std_true'] / np.sqrt(row['count'])) if row['std_true'] and row['count'] > 0 else np.nan
                if pd.isna(se) or se == 0:
                    return 0.0
                return abs((row['mean_true'] - row['mean_pred']) / se)
            grouped['metric'] = grouped.apply(_z, axis=1)

        # Determine signal using appropriate thresholds
        self.test_signal, n_99, n_95 = self.determine_signal(grouped['metric'], mode)

        # Plot
        img_encoded = self.plot_calibration_curve(grouped, mode)

        html = f"""
        <h4>Calibration Curve by Prediction Bins</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>
        <img src='data:image/png;base64,{img_encoded}'>
        <br>
        <h5>Confidence Interval Exceedances</h5>
        <table border="1">
            <tr>
                <th>Yellow</th>
                <th>Red</th>
            </tr>
            <tr>
                <td>Beyond 95% CI: >{int(len(grouped) * 0.1)}</td>
                <td>Beyond 95% CI: >{int(len(grouped) * 0.3)}</td>
            </tr>
            <tr>
                <td>Beyond 99% CI: >{int(len(grouped) * 0.1)}</td>
                <td>Beyond 99% CI: >{int(len(grouped) * 0.1)}</td>
            </tr>
        </table>
        <p><b>Actual number of exceedances beyond 95% CI:</b> {n_95}</p>
        <p><b>Actual number of exceedances beyond 99% CI:</b> {n_99}</p>
        <p><b>Traffic Light Test:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal}</span></p>
        <br>
        <h5>Group Stats</h5>
        {grouped.to_html(index=False, float_format="%.4f")}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M53_CalibrationCurveByDates(BaseModelTest):
    def __init__(self, test_num='M 5.3', test_name='Calibration Curve (Grouped by Dates)'):
        self.test_signal = None
        super().__init__(test_num, test_name)

    def determine_signal(self, metric_values: pd.Series, mode: str) -> tuple:
        """
        Определяет сигнал на основе результатов биномиального теста.

        Функция анализирует количество значений в столбце, превышающих пороговые значения 0.99 и 0.95,
        и на основе этого определяет сигнал: "red", "orange" или "green".

        Параметры:
            * binom_test_result (pd.Series): Столбец с результатами биномиального теста.

        Возвращает:
            * tuple: Кортеж, содержащий сигнал (str) и количество значений, превышающих пороги 0.99 и 0.95 (int, int).

        Логика определения сигнала:
            - "red": если более 10% значений превышают 0.99 или более 30% значений превышают 0.95.
            - "orange": если более 10% значений превышают 0.99 или более 10% значений превышают 0.95.
            - "green": в остальных случаях.
        """
        
        if mode == 'classification':
            n_99 = (metric_values > 0.99).sum()
            n_95 = (metric_values > 0.95).sum()
        else:
            n_99 = (metric_values > 2.58).sum()
            n_95 = (metric_values > 1.96).sum()

        if n_99 > int(len(metric_values) * 0.1) or n_95 > int(len(metric_values) * 0.3): 
            signal = "red"
        elif n_99 > int(len(metric_values) * 0.1) or n_95 > int(len(metric_values) * 0.1):
            signal = "orange"
        else:
            signal = "green"

        return signal, n_99, n_95
    
    def plot_calibration_over_time(self, grouped: pd.DataFrame, mode: str) -> str:
        """
        Строит кривую калибровки для заданного DataFrame по временной колнке. Функция строит график, отображающий кривую среднего предсказания и точки со средним таргетом.
        Подписи осей и заголовок графика настроены для лучшей читаемости.

        Параметры:
        ----------
        * grouped : pd.DataFrame
            DataFrame, содержащий столбцы 'date_str', 'mean_true' и 'mean_pred', 'count'.
            - 'date_str': дата в виде строки в формате "YYYY-MM-DD".
            - 'mean_true': среднее значение истинного таргета в каждом периоде.
            - 'mean_pred': среднее значение предсказанного таргета в каждом периоде.
            - 'count': количество наблюдений в каждом периоде.

        Возвращает:
        -------
        * str
            График в формате base64, который можно встроить в HTML.

        """
        fig, ax = plt.subplots(figsize=(10, 6))

        # X as numeric positions for CI shading
        x = np.arange(len(grouped))
        labels = grouped["date_str"].tolist()

        # Compute CI bands
        if mode == 'classification':
            p = grouped["mean_pred"].clip(0, 1)
            n = grouped["count"].replace(0, np.nan)
            se = np.sqrt(p * (1 - p)) / np.sqrt(n)
            ci95_low = (p - 1.96 * se).clip(lower=0)
            ci95_high = (p + 1.96 * se).clip(upper=1)
            ci99_low = (p - 2.58 * se).clip(lower=0)
            ci99_high = (p + 2.58 * se).clip(upper=1)
        else:
            n = grouped["count"].replace(0, np.nan)
            se = grouped.get("std_true", pd.Series([np.nan]*len(grouped))) / np.sqrt(n)
            m = grouped["mean_pred"]
            ci95_low = (m - 1.96 * se)
            ci95_high = (m + 1.96 * se)
            ci99_low = (m - 2.58 * se)
            ci99_high = (m + 2.58 * se)

        # Shaded CI areas
        ax.fill_between(x, ci99_low, ci99_high, color=COLORS['RED'], alpha=0.15, label="99% CI")
        ax.fill_between(x, ci95_low, ci95_high, color=COLORS['YELLOW'], alpha=0.25, label="95% CI")

        # Observed and predicted lines
        ax.plot(x, grouped["mean_true"], label="Observed", marker="o", linestyle='-', color=COLORS['BLUE'])
        ax.plot(x, grouped["mean_pred"], label="Predicted", linestyle="--", color=COLORS['GRAY'])

        # Add labels and title
        ax.set_xlabel("Date")
        ax.set_ylabel(TARGET_RATE_LABEL)
        ax.set_title("Calibration Over Time")

        # X ticks
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=45, ha='right')

        # Add legend
        ax.legend(loc='upper left', frameon=False)

        # Create a secondary y-axis for the count of observations
        ax2 = ax.twinx()
        ax2.bar(x, grouped["count"], alpha=0.25, color=COLORS['EMERALD'], label="Count")
        ax2.set_ylabel(OBSERVATION_COUNT_LABEL)

        # Add legend for the secondary y-axis
        ax2.legend(loc='upper right', frameon=False)

        # Tight layout for better spacing
        plt.tight_layout()

        # Save the plot to a bytes buffer
        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)

        return base64.b64encode(buf.getvalue()).decode()


    def run(self, date_column: pd.Series, score_column: pd.Series, target_column: pd.Series,
             period: str = 'M', weight: Optional[pd.Series] = None) -> dict:
        """
        Выполняет тест калибровочной кривой, группируя данные по временным периодам, и оценивает соответствие между фактическими и предсказанными значениями.

        Метод разбивает данные на временные периоды (недели, месяцы, кварталы, годы), вычисляет средние фактические и предсказанные значения для каждого периода,
        определяет сигнал на основе биномиального теста и строит график калибровочной кривой по времени.

        Параметры:
            * date_column (pd.Series): Серия с датами.
            * score_column (pd.Series): Серия с предсказанными значениями.
            * target_column (pd.Series): Серия с фактическими значениями.
            * period (str, optional): Период группировки данных. Возможные значения:
                - 'W': недельная частота.
                - 'M': месячная частота (по умолчанию).
                - 'Q': квартальная частота.
                - 'Y': годовая частота.

        Возвращает:
            * dict: Словарь, содержащий HTML-код с результатами теста, включая график калибровочной кривой, сигнал и статистику по периодам.

        Пример использования:
            ```python
            model_test = M43_CalibrationCurveByDates()
            result = model_test.run(date_column, score_column, target_column, period='M')
            print(result['combined'])
            ```
        """

        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        if not pd.api.types.is_numeric_dtype(score_column) or not pd.api.types.is_numeric_dtype(target_column):
            raise ValueError("Score и Target должны быть числовыми.")
        if score_column.isnull().any() or target_column.isnull().any():
            raise ValueError("Score и Target не должны содержать NaN.")
        if not (len(score_column) == len(target_column) == len(date_column)):
            raise ValueError("Длины date, score и target должны совпадать.")            

        # Подготовим данные для анализа
        df = pd.DataFrame({"date": date_column, "score": score_column, "target": target_column})
        if weight is not None:
            df["weight"] = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)

        try:
            df["date"] = pd.to_datetime(df["date"])
        except:
            raise ValueError("Колонка с датой должна содержать даты и быть в формате даты.")            
        
        
        # Группируем данные с заданным шагом
        if "weight" in df.columns:
            grouped = df.groupby(df["date"].dt.to_period(period)).apply(
                lambda g: pd.Series({
                    "count": float(g["weight"].sum()),
                    "mean_true": float(np.average(g["target"], weights=g["weight"])),
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    "std_true": float(np.sqrt(np.average((g["target"] - np.average(g["target"], weights=g["weight"])) ** 2,
                                                         weights=g["weight"])) if g["weight"].sum() > 0 else 0.0),
                })
            ).reset_index()
        else:
            grouped = df.groupby(df["date"].dt.to_period(period)).agg(
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        grouped["date_str"] = grouped["date"].dt.strftime("%Y-%m-%d")
        mode = 'classification' if type_of_target(target_column) == 'binary' else 'regression'
        if mode == 'classification':
            grouped["metric"] = grouped.apply(lambda row: calculate_binom_test(int(row['count']), float(row['mean_true']), float(row['mean_pred'])), axis=1)
        else:
            def _z(row):
                se = (row['std_true'] / np.sqrt(row['count'])) if row['std_true'] and row['count'] > 0 else np.nan
                if pd.isna(se) or se == 0:
                    return 0.0
                return abs((row['mean_true'] - row['mean_pred']) / se)
            grouped['metric'] = grouped.apply(_z, axis=1)

        # Determine signal
        self.test_signal, n_99, n_95 = self.determine_signal(grouped['metric'], mode)

        # Plot
        img_encoded = self.plot_calibration_over_time(grouped=grouped, mode=mode)

        html = f"""
        <h4>Calibration Curve by Date</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>
        <img src='data:image/png;base64,{img_encoded}'>
        <br>
        <h5>Confidence Interval Exceedances</h5>
        <table border="1">
            <tr>
                <th>Yellow</th>
                <th>Red</th>
            </tr>
            <tr>
                <td>Beyond 95% CI: >{int(len(grouped) * 0.1)}</td>
                <td>Beyond 95% CI: >{int(len(grouped) * 0.3)}</td>
            </tr>
            <tr>
                <td>Beyond 99% CI: >{int(len(grouped) * 0.1)}</td>
                <td>Beyond 99% CI: >{int(len(grouped) * 0.1)}</td>
            </tr>
        </table>
        <p><b>Actual number of exceedances beyond 95% CI:</b> {n_95}</p>
        <p><b>Actual number of exceedances beyond 99% CI:</b> {n_99}</p>
        <p><b>Traffic Light Test:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal}</span></p>
        <br>
        <h5>Group Stats</h5>
        {grouped.to_html(index=False, float_format="%.4f")}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M44_CalibrationCurveByMobs(BaseModelTest):
    def __init__(self, test_num='M 4.4', test_name='Calibration Curve (Grouped by Mobs)'):
        self.test_signal = None
        super().__init__(test_num, test_name)
   
    def determine_signal(self, metric_values: pd.Series, mode: str) -> tuple:
        """
        Определяет сигнал на основе результатов биномиального теста.

        Функция анализирует количество значений в столбце, превышающих пороговые значения 0.99 и 0.95,
        и на основе этого определяет сигнал: "red", "orange" или "green".

        Параметры:
            * binom_test_result (pd.Series): Столбец с результатами биномиального теста.

        Возвращает:
            * tuple: Кортеж, содержащий сигнал (str) и количество значений, превышающих пороги 0.99 и 0.95 (int, int).

        Логика определения сигнала:
            - "red": если более 10% значений превышают 0.99 или более 30% значений превышают 0.95.
            - "orange": если более 10% значений превышают 0.99 или более 10% значений превышают 0.95.
            - "green": в остальных случаях.
        """
        
        if mode == 'classification':
            n_99 = (metric_values > 0.99).sum()
            n_95 = (metric_values > 0.95).sum()
        else:
            n_99 = (metric_values > 2.58).sum()
            n_95 = (metric_values > 1.96).sum()

        if n_99 > int(len(metric_values) * 0.1) or n_95 > int(len(metric_values) * 0.3): 
            signal = "red"
        elif n_99 > int(len(metric_values) * 0.1) or n_95 > int(len(metric_values) * 0.1):
            signal = "orange"
        else:
            signal = "green"

        return signal, n_99, n_95

    def plot_calibration_over_mob(self, grouped: pd.DataFrame) -> str:
        """
        Строит кривую калибровки для заданного DataFrame по колнке для мобов. Функция строит график, отображающий кривую среднего предсказания и точки со средним таргетом.
        Подписи осей и заголовок графика настроены для лучшей читаемости.

        Параметры:
        ----------
        * grouped : pd.DataFrame
            DataFrame, содержащий столбцы 'mob_group', 'mean_true' и 'mean_pred', 'count'.
            - 'mob_group': значение для группировки данных.
            - 'mean_true': среднее значение истинного таргета в каждом периоде.
            - 'mean_pred': среднее значение предсказанного таргета в каждом периоде.
            - 'count': количество наблюдений в каждом периоде.

        Возвращает:
        -------
        * str
            График в формате base64, который можно встроить в HTML.

        """
        fig, ax = plt.subplots(figsize=(10, 6))

        # Plot the observed mean target
        ax.plot(grouped["mob_group"], grouped["mean_true"], label="Observed", marker="o", linestyle='-', color=COLORS['BLUE'])

        # Plot the predicted mean score
        ax.plot(grouped["mob_group"], grouped["mean_pred"], label="Predicted", linestyle="--", color=COLORS['GRAY'])

        # Add labels and title
        ax.set_xlabel("MOB")
        ax.set_ylabel(TARGET_RATE_LABEL)
        ax.set_title("Calibration by MOB")

        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45, ha='right')

        # Add legend
        ax.legend(loc='upper left', frameon=False)

        # Create a secondary y-axis for the count of observations
        ax2 = ax.twinx()
        ax2.bar(grouped["mob_group"], grouped["count"], alpha=0.3, color=COLORS['EMERALD'], label="Count")
        ax2.set_ylabel(OBSERVATION_COUNT_LABEL)

        # Add legend for the secondary y-axis
        ax2.legend(loc='upper right', frameon=False)

        # Tight layout for better spacing
        plt.tight_layout()

        # Save the plot to a bytes buffer
        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)

        return base64.b64encode(buf.getvalue()).decode()

    def run(self, score_column: pd.Series, target_column: pd.Series, mob_column: pd.Series,
             weight: Optional[pd.Series] = None) -> dict:
        """
        Выполняет тест калибровочной кривой, группируя данные по значениям мобов, и оценивает соответствие между фактическими и предсказанными значениями.

        Метод группирует данные по уникальным значениям мобов, вычисляет средние фактические и предсказанные значения для каждой группы,
        определяет сигнал на основе биномиального теста и строит график калибровочной кривой по мобам.

        Параметры:
            score_column (pd.Series): Серия с предсказанными значениями.
            target_column (pd.Series): Серия с фактическими значениями.
            mob_column (pd.Series): Серия с идентификаторами мобов.

        Возвращает:
            dict: Словарь, содержащий HTML-код с результатами теста, включая график калибровочной кривой, сигнал и статистику по группам мобов.

        Описание:
            Метод выполняет следующие шаги:
            1. Группирует данные по уникальным значениям мобов.
            2. Вычисляет средние фактические и предсказанные значения для каждой группы мобов.
            3. Применяет биномиальный тест для оценки соответствия между фактическими и предсказанными значениями.
            4. Определяет сигнал на основе результатов биномиального теста.
            5. Формирует HTML-код с результатами теста, включая график, сигнал и статистику по группам мобов.

        Пример использования:
            ```python
            model_test = M44_CalibrationCurveByMobs()
            result = model_test.run(score_column, target_column, mob_column)
            print(result['combined'])
            ```
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        if not pd.api.types.is_numeric_dtype(score_column) or not pd.api.types.is_numeric_dtype(target_column):
            raise ValueError("Score и Target должны быть числовыми.")
        if score_column.isnull().any() or target_column.isnull().any():
            raise ValueError("Score и Target не должны содержать NaN.")
        if not (len(score_column) == len(target_column) == len(mob_column)):
            raise ValueError("Длины score, target и mob должны совпадать.")            

        # Подготовка данных
        df = pd.DataFrame({"score": score_column, "target": target_column, "mob_group": mob_column.astype(str)})
        if weight is not None:
            df["weight"] = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)
        
        if "weight" in df.columns:
            grouped = df.groupby("mob_group").apply(
                lambda g: pd.Series({
                    "count": float(g["weight"].sum()),
                    "mean_true": float(np.average(g["target"], weights=g["weight"])),
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    "std_true": float(np.sqrt(np.average((g["target"] - np.average(g["target"], weights=g["weight"])) ** 2,
                                                         weights=g["weight"])) if g["weight"].sum() > 0 else 0.0),
                })
            ).reset_index()
        else:
            grouped = df.groupby("mob_group").agg(
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        # Определение режима
        mode = 'classification' if type_of_target(target_column) == 'binary' else 'regression'
        if mode == 'classification':
            grouped['metric'] = grouped.apply(lambda row: calculate_binom_test(int(row['count']), float(row['mean_true']), float(row['mean_pred'])), axis=1)
        else:
            def _z(row):
                se = (row['std_true'] / np.sqrt(row['count'])) if row['std_true'] and row['count'] > 0 else np.nan
                if pd.isna(se) or se == 0:
                    return 0.0
                return abs((row['mean_true'] - row['mean_pred']) / se)
            grouped['metric'] = grouped.apply(_z, axis=1)

        # Определение сигнала
        self.test_signal, n_99, n_95 = self.determine_signal(grouped['metric'], mode)
        # График кривой калибровки
        img_encoded = self.plot_calibration_over_mob(grouped)
        # Сводная информация
        html = f"""
        <h4>Calibration Curve by MOB</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>
        <img src='data:image/png;base64,{img_encoded}'>
        <br>
        <h5>Confidence Interval Exceedances</h5>
        <table border="1">
            <tr>
                <th>Yellow</th>
                <th>Red</th>
            </tr>
            <tr>
                <td>Beyond 95% CI: >{int(len(grouped) * 0.1)}</td>
                <td>Beyond 95% CI: >{int(len(grouped) * 0.3)}</td>
            </tr>
            <tr>
                <td>Beyond 99% CI: >{int(len(grouped) * 0.1)}</td>
                <td>Beyond 99% CI: >{int(len(grouped) * 0.1)}</td>
            </tr>
        </table>
        <p><b>Actual number of exceedances beyond 95% CI:</b> {n_95}</p>
        <p><b>Actual number of exceedances beyond 99% CI:</b> {n_99}</p>
        <p><b>Traffic Light Test:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal}</span></p>
        <br>
        <h5>Group Stats</h5>
        {grouped.to_html(index=False, float_format="%.4f")}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


# Summary block for group M4
def generate_group4_summary(test_results: dict) -> str:
    rows = []
    for code, result in test_results.items():
        signal = result.get("signal", "unknown")
        description = result.get("description", "")
        color = signal if signal in ["green", "orange", "red"] else "gray"
        rows.append(f"<tr><td>{code}</td><td>{description}</td><td style='color:{color}'><b>{signal.upper()}</b></td></tr>")

    summary = f"""
    <h4>Group M5 Summary</h4>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr><th>Test</th><th>Description</th><th>Signal</th></tr>
        {''.join(rows)}
    </table>
    """
    return summary
