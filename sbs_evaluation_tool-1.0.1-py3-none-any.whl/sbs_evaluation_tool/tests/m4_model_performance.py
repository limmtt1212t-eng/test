# -*- coding: utf-8 -*-
"""Focused M4 tests: clear separation between classification and regression.

This module implements M41..M45 with compact, robust logic and small
informative stubs for other M4 tests to avoid import-time failures.
"""
from __future__ import annotations
import base64
from io import BytesIO
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import logging

from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, r2_score, mean_squared_error
from sklearn.utils import resample
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from tqdm.auto import tqdm
from sklearn.utils.multiclass import type_of_target

from ..core.base_test import BaseModelTest
from ..core.styles import COLORS, STATUS_COLORS
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import ensure_config,  split_frames, get_weight_col, get_col_name, get_vectors, get_features
from ._visual_utils import (
    MEAN_RATE_LABEL,
    OBSERVATION_COUNT_LABEL,
    SHARE_LABEL,
    build_tabbed_sections_html,
    build_period_specs,
    build_scale_specs,
    figure_to_base64,
)

import matplotlib.dates as mdates
from math import log

# SHAP availability at module import time (used by some tests)
SHAP_AVAILABLE = False
shap = None

# Module logger
logger = logging.getLogger(__name__)

# Replaced with core.data_utils imports


def _subset_by_sample(df: pd.DataFrame, config: dict, sample: str) -> pd.DataFrame:
    # Use split_frames logic
    cfg = ensure_config(config, df)
    df_tr, df_te, df_all = split_frames(df, cfg)
    return {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)


def _safe_threshold_labels(s: pd.Series) -> pd.Series:
    if pd.api.types.is_integer_dtype(s) or (pd.Series(s).dropna().nunique() <= 2):
        return s.astype(int)
    if pd.api.types.is_float_dtype(s):
        return (s >= 0.5).astype(int)
    return pd.to_numeric(s, errors='coerce').fillna(0).astype(int)


def _bootstrap_metric(y: pd.Series, y_pred: pd.Series, metric_func, n_iter: int = 200) -> List[float]:
    vals = []
    for _ in tqdm(range(int(n_iter)), desc='Бутстрэп (итерации)', leave=True):
        y_s, y_pred_s = resample(y, y_pred)
        try:
            vals.append(float(metric_func(y_s, y_pred_s)))
        except Exception:
            vals.append(float('nan'))
    return vals


def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


class M41_MetricConfidenceIntervalTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification', n_iterations: int = 300):
        super().__init__('M 4.1', 'Metric Confidence Interval')
        if model_type not in ('classification', 'regression'):
            raise ValueError("model_type must be 'classification' or 'regression'")
        self.model_type = model_type
        self.n_iterations = int(n_iterations)

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'test', **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)
        task = getattr(cfg, 'task', None) or self.model_type

        html_parts = [f"<h4>M4.1 Metric CI ({task})</h4>"]
        results = {}

        try:
            if str(task).lower() == 'classification':
                y, pred, score = get_vectors(df_used, cfg, for_classification=True)
                labels = _safe_threshold_labels(pred if pred is not None else score)
                f1_vals = _bootstrap_metric(y, labels, lambda a, b: f1_score(a, b, zero_division=0), self.n_iterations)
                results['f1'] = {'original': float(f1_score(y, labels, zero_division=0)), 'ci_5': float(np.nanpercentile(f1_vals, 5)), 'ci_95': float(np.nanpercentile(f1_vals, 95))}
                prec_vals = _bootstrap_metric(y, labels, lambda a, b: precision_score(a, b, zero_division=0), self.n_iterations)
                rec_vals = _bootstrap_metric(y, labels, lambda a, b: recall_score(a, b, zero_division=0), self.n_iterations)
                results['precision'] = {'original': float(precision_score(y, labels, zero_division=0)), 'ci_5': float(np.nanpercentile(prec_vals, 5)), 'ci_95': float(np.nanpercentile(prec_vals, 95))}
                results['recall'] = {'original': float(recall_score(y, labels, zero_division=0)), 'ci_5': float(np.nanpercentile(rec_vals, 5)), 'ci_95': float(np.nanpercentile(rec_vals, 95))}
                if score is not None:
                    try:
                        auc_val = float(roc_auc_score(y, score))
                        results['roc_auc'] = {'original': auc_val}
                    except Exception:
                        pass
            else:
                y, pred, score = get_vectors(df_used, cfg, for_classification=False)
                r2_vals = _bootstrap_metric(y, score, lambda a, b: r2_score(a, b), self.n_iterations)
                mse_vals = _bootstrap_metric(y, score, lambda a, b: mean_squared_error(a, b), self.n_iterations)
                results['r2'] = {'original': float(r2_score(y, score)), 'ci_5': float(np.nanpercentile(r2_vals, 5)), 'ci_95': float(np.nanpercentile(r2_vals, 95))}
                results['mse'] = {'original': float(mean_squared_error(y, score)), 'ci_5': float(np.nanpercentile(mse_vals, 5)), 'ci_95': float(np.nanpercentile(mse_vals, 95))}
                # add normalized gini for regression
                try:
                    gn_vals = _bootstrap_metric(y, score, lambda a, b: gini_normalized(np.asarray(a), np.asarray(b)), self.n_iterations)
                    results['gini_normalized'] = {
                        'original': float(gini_normalized(np.asarray(y), np.asarray(score))),
                        'ci_5': float(np.nanpercentile(gn_vals, 5)),
                        'ci_95': float(np.nanpercentile(gn_vals, 95))
                    }
                except Exception:
                    pass
        except ConfigValidationError as e:
            self.test_signal = self.test_signal or 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.1 skipped</h4><p>{'; '.join(e.args[0])}</p>"}
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.1 error</h4><p>{str(e)}</p>"}

        # build table
        rows = []
        for k, v in results.items():
            if 'ci_5' in v:
                rows.append({'metric': k, 'value': f"{v['original']:.4f}", 'ci_5_95': f"[{v['ci_5']:.4f}, {v['ci_95']:.4f}]"})
            else:
                rows.append({'metric': k, 'value': f"{v['original']:.4f}", 'ci_5_95': ''})
        html_parts.append(pd.DataFrame(rows).to_html(index=False))
        # Informational test
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": "\n".join(html_parts)}


class M42_SampleSizeAdequacyTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification', step: float = 0.1):
        super().__init__('M 4.2', 'Sample Size Adequacy')
        self.model_type = model_type
        self.step = float(step)

    def run(self, df: pd.DataFrame, config: dict, model=None, model_class=None, sample: str = 'train') -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_tr)
        task = getattr(cfg, 'task', None) or self.model_type

        feats = get_features(df, cfg, include_categorical=False)
        if not feats:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.2 skipped</h4><p>No numeric features configured (columns.numeric_features)</p>"}

        X = df_used[feats].apply(pd.to_numeric, errors='coerce').fillna(0)
        y = df_used[cfg.columns.target_column]

        sizes = np.arange(self.step, 1.01, self.step)
        scores = []
        for s in sizes:
            n = max(10, int(len(X) * s))
            if model is None and model_class is not None:
                model = model_class()
            if model is None:
                # minimal fallback
                from sklearn.dummy import DummyClassifier
                model = DummyClassifier(strategy='most_frequent') if task == 'classification' else None
            try:
                if model is not None:
                    idx = np.random.choice(len(X), n, replace=False)
                    Xs = X.iloc[idx]
                    ys = y.iloc[idx]
                    model.fit(Xs, ys)
                    preds = model.predict(Xs)
                    score = float(f1_score(ys, _safe_threshold_labels(preds), zero_division=0)) if task == 'classification' else float(r2_score(ys, preds))
                else:
                    score = float('nan')
            except Exception:
                score = float('nan')
            scores.append(score)

        fig = plt.figure(figsize=(8, 4))
        plt.plot(sizes[:len(scores)], scores, marker='o')
        plt.xlabel('Training fraction')
        plt.ylabel('Score')
        html = f"<h4>M4.2 Sample Size Adequacy ({task})</h4><img src='data:image/png;base64,{_to_base64(fig)}' />"
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}


# === New Calibration-focused M4 tests per request ===
class M41_TargetRateTest(BaseModelTest):
    """Predicted vs Observed Rate of Target with simple CI-based traffic light.

    Signal logic:
    - GREEN if mean_pred within 95% CI of mean_true
    - YELLOW if within 99% CI (but not 95%)
    - RED if outside 99% CI
    """
    def __init__(self, test_num='M 4.1', test_name='Predicted vs Observed Rate of Target'):
        super().__init__(test_num, test_name)

    @staticmethod
    def _weighted_mean(y: np.ndarray, w: Optional[np.ndarray] = None) -> float:
        """Взвешенное среднее: Sum(y * w) / Sum(w).
        Используется для predicted rate.
        """
        y = np.asarray(y, dtype=float)
        if w is None:
            return float(np.mean(y))
        w = np.asarray(w, dtype=float)
        if y.shape != w.shape:
            w = w[: y.shape[0]]
        sw = np.sum(w)
        if sw <= 0:
            return float(np.mean(y))
        return float(np.sum(y * w) / sw)
    
    @staticmethod
    def _rate_mean(y: np.ndarray, w: Optional[np.ndarray] = None) -> float:
        """Среднее для rate/frequency: Sum(y) / Sum(w).
        Используется для observed rate в страховании.
        В страховании: частота = количество событий / экспозиция.
        """
        y = np.asarray(y, dtype=float)
        if w is None:
            return float(np.mean(y))
        w = np.asarray(w, dtype=float)
        if y.shape != w.shape:
            w = w[: y.shape[0]]
        sw = np.sum(w)
        if sw <= 0:
            return float(np.mean(y))
        # Для rate: просто сумма событий / сумма экспозиции
        return float(np.sum(y) / sw)

    @staticmethod
    def _ci_mean_classification(y: np.ndarray, z: float, w: Optional[np.ndarray] = None) -> tuple:
        """Вычисляет доверительный интервал для среднего (вероятности) в классификации.
        
        Для взвешенной выборки используется эффективный размер выборки:
        n_eff = (sum(w))^2 / sum(w^2)
        
        Это корректно учитывает неравномерность весов при расчете стандартной ошибки.
        """
        y = np.asarray(y).astype(float)
        if w is not None:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            sw = np.sum(w)
            if sw <= 0:
                w = None
        
        if w is None:
            # Невзвешенный случай
            n = max(1, y.size)
            p = float(np.mean(y))
            se = np.sqrt(max(p * (1 - p), 0.0) / n)
        else:
            # Взвешенный случай - для RATE (sum(y) / sum(w))
            sw = np.sum(w)
            p = float(np.sum(y) / sw)  # Rate: sum(events) / sum(exposure)
            
            # Эффективный размер выборки для взвешенных данных
            n_eff = (sw ** 2) / np.sum(w ** 2)
            n_eff = max(1.0, n_eff)
            
            var = max(p * (1 - p), 0.0)
            se = np.sqrt(var / n_eff)
        return (p - z * se, p + z * se)

    @staticmethod
    def _ci_mean_regression(y: np.ndarray, z: float, w: Optional[np.ndarray] = None) -> tuple:
        """Вычисляет доверительный интервал для среднего в регрессии (для RATE).
        
        Для взвешенной выборки используется:
        - среднее для rate: sum(y) / sum(w) (не sum(y*w)/sum(w)!)
        - дисперсия для rate: var(y/w) при равных w, или через bootstrap
        - эффективный размер выборки: n_eff = (sum(w))^2 / sum(w^2)
        - стандартная ошибка: SE = sqrt(s^2 / n_eff)
        """
        y = np.asarray(y).astype(float)
        if w is not None:
            w = np.asarray(w, dtype=float)
            if y.shape != w.shape:
                w = w[: y.shape[0]]
            sw = np.sum(w)
            if sw <= 0:
                w = None
        
        if w is None:
            # Невзвешенный случай
            n = max(1, y.size)
            m = float(np.mean(y))
            s = float(np.nanstd(y, ddof=1)) if n > 1 else 0.0
            se = s / np.sqrt(n) if n > 0 else 0.0
        else:
            # Взвешенный случай - для RATE
            sw = np.sum(w)
            m = float(np.sum(y) / sw)  # Rate: sum(events) / sum(exposure)
            
            # Для rate дисперсия считается как для индивидуальных rate_i = y_i / exposure_total
            # Приближенная формула: используем дисперсию y относительно m*w
            s2 = np.sum((y - m * w) ** 2 / w) / len(y) if np.all(w > 0) else np.var(y / w) if np.all(w > 0) else 0.0
            s = float(np.sqrt(max(s2, 0.0)))
            
            # Эффективный размер выборки
            n_eff = (sw ** 2) / np.sum(w ** 2)
            n_eff = max(1.0, n_eff)
            
            se = s / np.sqrt(n_eff) if n_eff > 0 else 0.0
        return (m - z * se, m + z * se)

    @staticmethod
    def _determine_signal(mean_pred: float, ci_95: tuple, ci_99: tuple) -> str:
        if ci_95[0] <= mean_pred <= ci_95[1]:
            return 'green'
        elif ci_99[0] <= mean_pred <= ci_99[1]:
            return 'orange'
        return 'red'

    def _plot(self, mean_true: float, mean_pred: float, ci_95: tuple, ci_99: tuple) -> str:
        from matplotlib.lines import Line2D
        fig, ax = plt.subplots(figsize=(8, 4.5))
        # Corporate CI lines
        ax.hlines([ci_99[0], ci_99[1]], xmin=-0.2, xmax=0.2, colors=COLORS['RED'], linewidth=2)
        ax.hlines([ci_95[0], ci_95[1]], xmin=-0.2, xmax=0.2, colors=COLORS['YELLOW'], linewidth=3)
        # Points
        ax.scatter([0], [mean_true], color=COLORS['BLUE'], s=60, label="Observed mean")
        ax.scatter([0], [mean_pred], color=COLORS['EMERALD'], s=60, label="Predicted mean")
        ax.set_xlim(-0.5, 0.5)
        ymin = min(ci_99[0], ci_95[0], mean_true, mean_pred)
        ymax = max(ci_99[1], ci_95[1], mean_true, mean_pred)
        ax.set_ylim(ymin - 0.02 * (ymax - ymin), ymax + 0.02 * (ymax - ymin))
        ax.set_xticks([])
        ax.set_title("Observed vs Predicted Mean with 95%/99% CI")
        legend_lines = [
            Line2D([0], [0], color=COLORS['YELLOW'], lw=3, label="95% CI"),
            Line2D([0], [0], color=COLORS['RED'], lw=2, label="99% CI"),
        ]
        scatter = [
            Line2D([0], [0], marker='o', color='w', label='Observed mean', markerfacecolor=COLORS['BLUE'], markersize=8),
            Line2D([0], [0], marker='o', color='w', label='Predicted mean', markerfacecolor=COLORS['EMERALD'], markersize=8),
        ]
        ax.legend(handles=legend_lines + scatter, loc='upper right')
        buf = BytesIO()
        plt.tight_layout()
        plt.savefig(buf, format='png', bbox_inches='tight')
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode('utf-8')

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
            score: Optional[pd.Series] = None, target: Optional[pd.Series] = None,
            sample: str = 'genpop', **kwargs) -> Dict[str, str]:
        """Supports two invocation styles:
        - New (preferred): run(df=..., config=..., sample='train'|'test'|'genpop')
          Takes score/target columns from config.
        - Backward-compatible: run(score=..., target=...)
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven path
        if df is not None and config is not None:
            try:
                cfg = ensure_config(config, df)
                df_tr, df_te, df_all = split_frames(df, cfg)
                df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(str(sample).lower(), df_all)
                # For both tasks obtain target and score/pred
                task = getattr(cfg, 'task', None)
                y, pred, sc = get_vectors(df_used, cfg, for_classification=(str(task).lower() == 'classification'))
                target = y
                score = sc if sc is not None else pred
            except Exception as e:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>Predicted vs Observed Rate of Target</h4><p>Config error: {str(e)}</p>"}

        if score is None or target is None:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": "<h4>Predicted vs Observed Rate of Target</h4><p>Missing score/target data.</p>"}

        if not pd.api.types.is_numeric_dtype(score) or not pd.api.types.is_numeric_dtype(target):
            raise ValueError("Score and target must be numeric.")
        if score.isnull().any() or target.isnull().any():
            raise ValueError("Score and target must not contain NaN values.")

        w_series = None
        if df is not None and config is not None:
            try:
                # используем исходный df_used и config для весов
                w_series = get_weight_col(df_used, cfg)
            except Exception:
                w_series = None
        w = None
        if w_series is not None:
            # выровнять по индексу score/target
            w_series = w_series.reindex(target.index)
            w = w_series.to_numpy(dtype=float)
        
        # Для страховой частоты:
        # Observed rate = Sum(events) / Sum(exposure)
        # Predicted rate = Sum(prediction * exposure) / Sum(exposure) = weighted mean(prediction)
        mean_true = self._rate_mean(target.to_numpy(), w)      # Sum(y) / Sum(w)
        mean_pred = self._weighted_mean(score.to_numpy(), w)   # Sum(score * w) / Sum(w)
        mode = 'classification' if type_of_target(target) == 'binary' else 'regression'
        if mode == 'classification':
            ci_95 = self._ci_mean_classification(target.values, 1.96, w)
            ci_99 = self._ci_mean_classification(target.values, 2.58, w)
        else:
            ci_95 = self._ci_mean_regression(target.values, 1.96, w)
            ci_99 = self._ci_mean_regression(target.values, 2.58, w)

        sig = self._determine_signal(mean_pred, ci_95, ci_99)
        self.test_signal = sig
        img = self._plot(mean_true, mean_pred, ci_95, ci_99)
        html = f"""
        <h4>Predicted vs Observed Rate of Target</h4>
        <p><b>Observed mean:</b> {mean_true:.6f}</p>
        <p><b>Predicted mean:</b> {mean_pred:.6f}</p>
        <p><b>95% CI (from observed):</b> ({ci_95[0]:.6f}, {ci_95[1]:.6f})</p>
        <p><b>99% CI (from observed):</b> ({ci_99[0]:.6f}, {ci_99[1]:.6f})</p>
        <p><b>Signal:</b> <span style='color:{sig}; font-weight:bold'>{sig.upper()}</span></p>
        <img src='data:image/png;base64,{img}' />
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M42_CalibrationCurveByPredictBinsLn(BaseModelTest):
    """Калибровка по бинам предсказаний.

    По умолчанию тест строит две версии графика:
    - обычная шкала
    - логарифмическая шкала

    Для обратной совместимости можно отключить двойной вывод и оставить только
    одну из шкал через show_both_scales=False + use_log_scale.
    """
    def __init__(
        self,
        test_num='M 4.2',
        test_name='Calibration Curve (Predict Bins)',
        use_log_scale: bool = False,
        show_both_scales: bool = True,
    ):
        resolved_name = test_name
        if not show_both_scales and use_log_scale:
            resolved_name += ' (ln scale)'
        super().__init__(test_num, resolved_name)
        self.use_log_scale = use_log_scale
        self.show_both_scales = show_both_scales

    @staticmethod
    def _safe_log(x):
        x = np.asarray(x, dtype=float)
        return np.log(np.clip(x, 1e-12, None))

    def _compute_grouped(self, score: pd.Series, target: pd.Series, weight: Optional[pd.Series] = None,
                         num_groups: int = 20, bins_step: float = None) -> pd.DataFrame:
        df = pd.DataFrame({"score": score, "target": target})
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)
            df["weight"] = w
        if bins_step:
            bins = np.arange(float(score.min()), float(score.max()) + float(bins_step), float(bins_step))
            if len(bins) < 2:
                bins = np.linspace(float(score.min()), float(score.max()), max(3, num_groups))
            df["bin"] = pd.cut(df["score"], bins=bins, include_lowest=True)
        else:
            df['bin'] = pd.qcut(df['score'], q=min(num_groups, max(1, df['score'].nunique())), duplicates='drop')
        if "weight" in df.columns:
            grouped = df.groupby("bin", observed=False).apply(
                lambda g: pd.Series({
                    "count": float(g["weight"].sum()),
                    # Для страховой частоты: observed rate = sum(events) / sum(exposure)
                    "mean_true": float(g["target"].sum() / g["weight"].sum()) if g["weight"].sum() > 0 else 0.0,
                    # Для predicted: взвешенное среднее = sum(score * exposure) / sum(exposure)
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    # Для rate стандартное отклонение считается от индивидуальных rate_i относительно среднего rate
                    "std_true": float(np.sqrt(np.sum((g["target"] - (g["target"].sum() / g["weight"].sum()) * g["weight"]) ** 2 / g["weight"]) / len(g)) if g["weight"].sum() > 0 and np.all(g["weight"] > 0) else g["target"].std()),
                })
            ).reset_index()
        else:
            grouped = df.groupby("bin", observed=False).agg(
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        return grouped

    def _plot(self, grouped: pd.DataFrame, mode: str, use_log_scale: bool) -> tuple[str, str, Dict[str, bool]]:
        fig, ax1 = plt.subplots(figsize=(12, 5))
        x = np.arange(len(grouped))
        labels = grouped['bin'].astype(str).tolist()

        # CI around observed mean
        # Для взвешенных данных count = sum(weights) в каждом бине
        # Эффективный размер выборки учитывает неравномерность весов
        n = grouped['count'].replace(0, np.nan)
        if mode == 'classification':
            p = grouped['mean_true'].clip(0, 1)
            # Для взвешенной выборки используем count как эффективный n
            # (уже учтено в _compute_grouped для взвешенного случая)
            se = np.sqrt(p * (1 - p)) / np.sqrt(n)
            ci95_low = (p - 1.96 * se).clip(lower=0)
            ci95_high = (p + 1.96 * se).clip(upper=1)
            ci99_low = (p - 2.58 * se).clip(lower=0)
            ci99_high = (p + 2.58 * se).clip(upper=1)
        else:
            # Для регрессии используем взвешенное std и count
            se = grouped['std_true'] / np.sqrt(n)
            m = grouped['mean_true']
            ci95_low = m - 1.96 * se
            ci95_high = m + 1.96 * se
            ci99_low = m - 2.58 * se
            ci99_high = m + 2.58 * se

        # Bright shaded CI areas (plot on ln scale values if requested)
        if use_log_scale:
            y_obs = self._safe_log(grouped['mean_true'])
            y_pred = self._safe_log(grouped['mean_pred'])
            ci99_l = self._safe_log(ci99_low)
            ci99_h = self._safe_log(ci99_high)
            ci95_l = self._safe_log(ci95_low)
            ci95_h = self._safe_log(ci95_high)
            ylabel = f"ln({MEAN_RATE_LABEL})"
        else:
            y_obs = grouped['mean_true']
            y_pred = grouped['mean_pred']
            ci99_l = ci99_low
            ci99_h = ci99_high
            ci95_l = ci95_low
            ci95_h = ci95_high
            ylabel = MEAN_RATE_LABEL

        ax1.fill_between(x, ci99_l, ci99_h, color=COLORS['RED'], alpha=0.30, label="99% CI (observed)")
        ax1.fill_between(x, ci95_l, ci95_h, color=COLORS['YELLOW'], alpha=0.45, label="95% CI (observed)")

        obs_label = "Observed mean (ln)" if use_log_scale else "Observed mean"
        pred_label = "Predicted mean (ln)" if use_log_scale else "Predicted mean"
        ax1.plot(x, y_obs, label=obs_label, marker='o', color=COLORS['BLUE'])
        ax1.plot(x, y_pred, label=pred_label, linestyle='--', color='#6d6d6d')

        # Mark red-zone violations with red stars (predicted outside 99% CI)
        # Note: logic remains on original scale values for mask check
        red_mask = (grouped['mean_pred'] > ci99_high) | (grouped['mean_pred'] < ci99_low)
        ax1.scatter(np.where(red_mask)[0], y_pred[red_mask], color=COLORS['RED'], marker='*', s=120, zorder=5, label="Pred>99% CI (red)")

        ax1.set_xlabel("Prediction Bins")
        ax1.set_ylabel(ylabel)
        ax1.set_xticks(x)
        ax1.set_xticklabels(labels, rotation=45, ha='right')
        ax1.grid(True, linestyle='--', alpha=0.3)

        # Secondary axis: bin share %
        ax2 = ax1.twinx()
        share_pct = grouped['count'] / max(1.0, grouped['count'].sum()) * 100.0
        ax2.bar(x, share_pct, alpha=0.35, color=COLORS['EMERALD'], label="Bin Share (%)")
        ax2.set_ylabel(f"{SHARE_LABEL} (%)")

        # Legends
        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')
        plt.tight_layout()
        img_b64 = figure_to_base64(fig)
        plt.close(fig)

        # Determine per-bin statuses
        yellow_mask = ((grouped['mean_pred'] > ci95_high) | (grouped['mean_pred'] < ci95_low)) & (~red_mask)
        flags = {
            'any_red': bool(np.any(red_mask)),
            'any_yellow': bool(np.any(yellow_mask))
        }
        return img_b64, grouped.to_html(index=False, float_format='%.6f'), flags

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
        score: Optional[pd.Series] = None, target: Optional[pd.Series] = None,
            num_groups: int = 20, bins_step: float = None, sample: str = 'genpop', **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven path
        w_series = None
        if df is not None and config is not None:
            try:
                cfg = ensure_config(config, df)
                df_tr, df_te, df_all = split_frames(df, cfg)
                df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(str(sample).lower(), df_all)
                task = getattr(cfg, 'task', None)
                y, pred, sc = get_vectors(df_used, cfg, for_classification=(str(task).lower() == 'classification'))
                target = y
                score = sc if sc is not None else pred
                w_series = get_weight_col(df_used, cfg)
            except Exception as e:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>Calibration Curve by Predict Bins</h4><p>Config error: {str(e)}</p>"}

        if score is None or target is None:
            return {"combined": "<h4>Calibration Curve by Predict Bins</h4><p>Missing score/target data.</p>"}

        if not pd.api.types.is_numeric_dtype(score) or not pd.api.types.is_numeric_dtype(target):
            raise ValueError("Score and target must be numeric.")
        if score.isnull().any() or target.isnull().any():
            raise ValueError("Score and target must not contain NaN values.")
        if not bins_step and len(score) < num_groups:
            raise ValueError("Not enough rows for the requested number of groups. Use bins_step or reduce num_groups.")
        if len(score) != len(target):
            raise ValueError("Score and target must have the same length.")

        grouped = self._compute_grouped(score, target, weight=w_series, num_groups=num_groups, bins_step=bins_step)
        mode = 'classification' if type_of_target(target) == 'binary' else 'regression'
        scale_specs = build_scale_specs(self.show_both_scales, self.use_log_scale)
        rendered_tabs = []
        flags = {'any_red': False, 'any_yellow': False}
        table_html = grouped.to_html(index=False, float_format='%.6f')
        for idx, (scale_flag, scale_title) in enumerate(scale_specs):
            img_b64, _, plot_flags = self._plot(grouped, mode, use_log_scale=scale_flag)
            if idx == 0:
                flags = plot_flags
            rendered_tabs.append(
                {
                    "label": scale_title,
                    "html": f"<img src='data:image/png;base64,{img_b64}' style='display:block; width:100%; max-width:1100px; height:auto;' />",
                    "color": COLORS['BLUE'] if not scale_flag else COLORS['EMERALD'],
                }
            )

        if flags['any_red']:
            sig = 'red'
        elif flags['any_yellow']:
            sig = 'orange'
        else:
            sig = 'green'
        self.test_signal = sig

        title = "Calibration Curve by Prediction Bins"
        if not self.show_both_scales and self.use_log_scale:
            title += " (ln scale)"

        html = f"""
        <h4>{title}</h4>
        <p><b>Signal:</b> <span style='color:{sig}; font-weight:bold'>{sig.upper()}</span></p>
        {build_tabbed_sections_html(rendered_tabs, root_prefix="m42-scale")}
        <br>
        <h5>Group Stats</h5>
        {table_html}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M43_CalibrationCurveByDatesLn(BaseModelTest):
    """Калибровка по времени.

    Поведение по умолчанию:
    - period=None: строятся месяцы и кварталы
    - для каждой разбивки строятся обычный и логарифмический графики

    Для inline-использования можно передать period='W' | 'M' | 'Q', чтобы
    отрисовать только одну временную разбивку.
    """
    def __init__(
        self,
        test_num='M 4.3',
        test_name='Calibration Curve (Dates)',
        use_log_scale: bool = False,
        show_both_scales: bool = True,
    ):
        resolved_name = test_name
        if not show_both_scales and use_log_scale:
            resolved_name += ' (ln scale)'
        super().__init__(test_num, resolved_name)
        self.use_log_scale = use_log_scale
        self.show_both_scales = show_both_scales

    @staticmethod
    def _safe_log(x):
        x = np.asarray(x, dtype=float)
        return np.log(np.clip(x, 1e-12, None))

    @staticmethod
    def _format_period_label(period_value, period: str) -> str:
        if pd.isna(period_value):
            return ""
        if period == 'M':
            return f"{period_value.year}-{period_value.month:02d}"
        if period == 'Q':
            return f"{period_value.year}-Q{period_value.quarter}"
        if period == 'W':
            return period_value.start_time.strftime('%Y-%m-%d')
        return str(period_value)

    def _group(self, date: pd.Series, score: pd.Series, target: pd.Series,
               weight: Optional[pd.Series], period: str) -> pd.DataFrame:
        try:
            date_converted = pd.to_datetime(date, errors='coerce')
        except Exception:
            # If conversion fails, return empty DataFrame
            return pd.DataFrame()
        
        df = pd.DataFrame({"date": date_converted, "score": score, "target": target}).dropna(subset=['date'])
        if df.empty:
            return df
            
        period = str(period).upper()
        if period not in {'W', 'M', 'Q'}:
            raise ValueError("period должен быть одним из: 'W', 'M', 'Q'")

        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").reindex(df.index).fillna(0.0)
            df["weight"] = w
        if "weight" in df.columns:
            grouped = df.groupby(df['date'].dt.to_period(period)).apply(
                lambda g: pd.Series({
                    "count": float(g["weight"].sum()),
                    # Для страховой частоты: observed rate = sum(events) / sum(exposure)
                    "mean_true": float(g["target"].sum() / g["weight"].sum()) if g["weight"].sum() > 0 else 0.0,
                    # Для predicted: взвешенное среднее = sum(score * exposure) / sum(exposure)
                    "mean_pred": float(np.average(g["score"], weights=g["weight"])),
                    # Для rate стандартное отклонение
                    "std_true": float(np.sqrt(np.sum((g["target"] - (g["target"].sum() / g["weight"].sum()) * g["weight"]) ** 2 / g["weight"]) / len(g)) if g["weight"].sum() > 0 and np.all(g["weight"] > 0) else g["target"].std()),
                })
            ).reset_index()
        else:
            grouped = df.groupby(df['date'].dt.to_period(period)).agg(
                count=("target", "count"),
                mean_true=("target", "mean"),
                mean_pred=("score", "mean"),
                std_true=("target", "std"),
            ).reset_index()
        grouped['date_str'] = grouped['date'].apply(lambda p: self._format_period_label(p, period))
        return grouped

    def _plot(self, grouped: pd.DataFrame, mode: str, title_suffix: str, use_log_scale: bool) -> tuple[str, Dict[str, bool]]:
        fig, ax1 = plt.subplots(figsize=(12, 5))
        x = np.arange(len(grouped))
        labels = grouped['date_str'].tolist()

        # CI around observed mean
        # Для взвешенных данных count = sum(weights) в каждом периоде
        # Эффективный размер выборки учитывает неравномерность весов
        n = grouped['count'].replace(0, np.nan)
        if mode == 'classification':
            p = grouped['mean_true'].clip(0, 1)
            # Для взвешенной выборки используем count как эффективный n
            # (уже учтено в _group для взвешенного случая)
            se = np.sqrt(p * (1 - p)) / np.sqrt(n)
            ci95_low = (p - 1.96 * se).clip(lower=0)
            ci95_high = (p + 1.96 * se).clip(upper=1)
            ci99_low = (p - 2.58 * se).clip(lower=0)
            ci99_high = (p + 2.58 * se).clip(upper=1)
        else:
            # Для регрессии используем взвешенное std и count
            se = grouped['std_true'] / np.sqrt(n)
            m = grouped['mean_true']
            ci95_low = m - 1.96 * se
            ci95_high = m + 1.96 * se
            ci99_low = m - 2.58 * se
            ci99_high = m + 2.58 * se

        if use_log_scale:
            y_obs = self._safe_log(grouped['mean_true'])
            y_pred = self._safe_log(grouped['mean_pred'])
            ci99_l = self._safe_log(ci99_low)
            ci99_h = self._safe_log(ci99_high)
            ci95_l = self._safe_log(ci95_low)
            ci95_h = self._safe_log(ci95_high)
            ylabel = "ln(Mean Rate)"
        else:
            y_obs = grouped['mean_true']
            y_pred = grouped['mean_pred']
            ci99_l = ci99_low
            ci99_h = ci99_high
            ci95_l = ci95_low
            ci95_h = ci95_high
            ylabel = MEAN_RATE_LABEL

        ax1.fill_between(x, ci99_l, ci99_h, color=COLORS['RED'], alpha=0.30, label="99% CI (observed)")
        ax1.fill_between(x, ci95_l, ci95_h, color=COLORS['YELLOW'], alpha=0.45, label="95% CI (observed)")

        obs_label = "Observed mean (ln)" if use_log_scale else "Observed mean"
        pred_label = "Predicted mean (ln)" if use_log_scale else "Predicted mean"
        ax1.plot(x, y_obs, label=obs_label, marker='o', color=COLORS['BLUE'])
        ax1.plot(x, y_pred, label=pred_label, linestyle='--', color='#6d6d6d')

        red_mask = (grouped['mean_pred'] > ci99_high) | (grouped['mean_pred'] < ci99_low)
        ax1.scatter(np.where(red_mask)[0], y_pred[red_mask], color=COLORS['RED'], marker='*', s=120, zorder=5, label="Pred>99% CI (red)")

        ax1.set_xlabel("Period")
        ax1.set_ylabel(ylabel)
        ax1.set_xticks(x)
        ax1.set_xticklabels(labels, rotation=45, ha='right')
        ax1.set_title(f"Calibration Over Time - {title_suffix}")
        ax1.grid(True, linestyle='--', alpha=0.3)

        ax2 = ax1.twinx()
        share_pct = grouped['count'] / max(1.0, grouped['count'].sum()) * 100.0
        ax2.bar(x, share_pct, alpha=0.35, color=COLORS['EMERALD'], label="Share (%)")
        ax2.set_ylabel(f"{SHARE_LABEL} (%)")

        ax1.legend(loc='upper left')
        ax2.legend(loc='upper right')
        plt.tight_layout()
        img_b64 = figure_to_base64(fig)
        plt.close(fig)

        yellow_mask = ((grouped['mean_pred'] > ci95_high) | (grouped['mean_pred'] < ci95_low)) & (~red_mask)
        flags = {
            'any_red': bool(np.any(red_mask)),
            'any_yellow': bool(np.any(yellow_mask))
        }
        return img_b64, flags

    def run(self, df: Optional[pd.DataFrame] = None, config: Optional[dict] = None,
            date_column: Optional[pd.Series] = None, score_column: Optional[pd.Series] = None,
            target_column: Optional[pd.Series] = None, sample: str = 'genpop',
            period: Optional[str] = None, **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven path
        w_series = None
        if df is not None and config is not None:
            try:
                cfg = ensure_config(config, df)
                df_tr, df_te, df_all = split_frames(df, cfg)
                df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(str(sample).lower(), df_all)
                dcol = getattr(cfg.columns, 'date_column', None)
                scol = getattr(cfg.columns, 'score_column', None) or getattr(cfg.columns, 'prediction_column', None)
                tcol = getattr(cfg.columns, 'target_column', None)
                if dcol is None or dcol not in df_used.columns:
                    self.test_signal = 'blue'
                    logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                    return {"combined": "<h4>Calibration Curve by Dates</h4><p>date_column is missing in the selected data.</p>"}
                date_column = df_used[dcol]
                target_column = df_used[tcol]
                score_column = df_used[scol]
                w_series = get_weight_col(df_used, cfg)
            except Exception as e:
                self.test_signal = 'red'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"combined": f"<h4>Calibration Curve by Dates</h4><p>Config error: {str(e)}</p>"}

        if score_column is None or target_column is None or date_column is None:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": "<h4>Calibration Curve by Dates</h4><p>Missing date/score/target data.</p>"}

        if not pd.api.types.is_numeric_dtype(score_column) or not pd.api.types.is_numeric_dtype(target_column):
            raise ValueError("Score and target must be numeric.")
        if score_column.isnull().any() or target_column.isnull().any():
            raise ValueError("Score and target must not contain NaN values.")
        if not (len(score_column) == len(target_column) == len(date_column)):
            raise ValueError("date, score, and target must have the same length.")

        requested_period = None if period is None else str(period).upper()
        if requested_period not in {None, 'W', 'M', 'Q'}:
            raise ValueError("period must be None, 'W', 'M', or 'Q'.")

        mode = 'classification' if type_of_target(target_column) == 'binary' else 'regression'
        period_specs = build_period_specs(requested_period)
        scale_specs = build_scale_specs(self.show_both_scales, self.use_log_scale)

        any_red = False
        any_yellow = False
        period_tabs = []
        non_empty_periods = 0

        for period_code, period_title in period_specs:
            grouped = self._group(date_column, score_column, target_column, w_series, period=period_code)
            if grouped.empty:
                continue

            non_empty_periods += 1
            scale_tabs = []
            for idx, (scale_flag, scale_title) in enumerate(scale_specs):
                img_b64, flags = self._plot(grouped, mode, period_title, use_log_scale=scale_flag)
                if idx == 0:
                    any_red = any_red or flags['any_red']
                    any_yellow = any_yellow or flags['any_yellow']
                scale_tabs.append(
                    {
                        "label": scale_title,
                        "html": f"<img src='data:image/png;base64,{img_b64}' style='display:block; width:100%; max-width:1100px; height:auto;' />",
                        "color": COLORS['BLUE'] if not scale_flag else COLORS['EMERALD'],
                    }
                )
            period_tabs.append(
                {
                    "label": period_title,
                    "html": build_tabbed_sections_html(scale_tabs, root_prefix=f"m43-scale-{period_code.lower()}"),
                    "color": COLORS['BLUE'],
                }
            )

        if non_empty_periods == 0:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"combined": "<h4>Calibration Curve by Dates</h4><p>No data available for the selected grouping.</p>"}
        if any_red:
            sig = 'red'
        elif any_yellow:
            sig = 'orange'
        else:
            sig = 'green'
        self.test_signal = sig

        title = "Calibration Curve by Dates"
        if not self.show_both_scales and self.use_log_scale:
            title += " (ln scale)"
        html = f"""
        <h4>{title}</h4>
        <p><b>Signal:</b> <span style='color:{sig}; font-weight:bold'>{sig.upper()}</span></p>
        {build_tabbed_sections_html(period_tabs, root_prefix="m43-period")}
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M43_CalibrationTest(BaseModelTest):
    def __init__(self, n_bins: int = 10):
        super().__init__('M 4.3', 'Model Calibration')
        self.n_bins = int(n_bins)

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'test') -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        task = getattr(cfg, 'task', None)
        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)
        try:
            if task == 'classification':
                y, pred, score = get_vectors(df_used, cfg, for_classification=True)
                if score is None:
                    return {"report": "<h4>M4.3 skipped</h4><p>No score_column available for calibration plot.</p>"}
                from sklearn.calibration import calibration_curve
                frac_pos, mean_pred = calibration_curve(y, score, n_bins=self.n_bins)
                fig = plt.figure(figsize=(6, 4))
                plt.plot(mean_pred, frac_pos, marker='o')
                plt.plot([0, 1], [0, 1], '--', color='gray')
                plt.xlabel('Predicted probability')
                plt.ylabel('Fraction positive')
                html = f"<h4>M4.3 Calibration (classification)</h4><img src='data:image/png;base64,{_to_base64(fig)}' />"
                self.test_signal = self.test_signal or 'blue'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"report": html}
            else:
                # Regression calibration: bin by predicted, plot mean predicted vs mean observed
                y, pred, score = get_vectors(df_used, cfg, for_classification=False)
                s = pd.Series(score).astype(float)
                yv = pd.Series(y).astype(float)
                # quantile bins
                bins = pd.qcut(s.rank(method='first')/len(s), q=self.n_bins, duplicates='drop').astype(str)
                df_cal = pd.DataFrame({'pred': s, 'obs': yv, 'bin': bins}).groupby('bin').agg({'pred':'mean','obs':'mean'}).reset_index()
                fig = plt.figure(figsize=(6, 4))
                plt.plot(df_cal['pred'], df_cal['obs'], marker='o', color='#1f77b4')
                # draw y=x line using range of predictions
                mn, mx = float(df_cal['pred'].min()), float(df_cal['pred'].max())
                plt.plot([mn, mx], [mn, mx], '--', color='gray')
                plt.xlabel('Mean Prediction')
                plt.ylabel('Mean Observed')
                plt.title('Calibration (Regression)')
                html = f"<h4>M4.3 Calibration (regression)</h4><img src='data:image/png;base64,{_to_base64(fig)}' />"
                self.test_signal = self.test_signal or 'blue'
                logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
                return {"report": html}
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.3 error</h4><p>{str(e)}</p>"}


class M44_OverfittingTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification'):
        super().__init__('M 4.4', 'Overfitting Detection')
        self.model_type = model_type

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        df_tr, df_te, _ = split_frames(df, cfg)
        task = getattr(cfg, 'task', None) or self.model_type

        try:
            if str(task).lower() == 'classification':
                y_tr, pred_tr, score_tr = get_vectors(df_tr, cfg, for_classification=True)
                y_te, pred_te, score_te = get_vectors(df_te, cfg, for_classification=True)
                pred_tr_lbl = _safe_threshold_labels(pred_tr if pred_tr is not None else score_tr)
                pred_te_lbl = _safe_threshold_labels(pred_te if pred_te is not None else score_te)
                metrics = {
                    'F1': (
                        float(f1_score(y_tr, pred_tr_lbl, zero_division=0)),
                        float(f1_score(y_te, pred_te_lbl, zero_division=0))
                    )
                }
            else:
                y_tr, _, score_tr = get_vectors(df_tr, cfg, for_classification=False)
                y_te, _, score_te = get_vectors(df_te, cfg, for_classification=False)
                # Compute regression metrics
                g_tr = float(gini_normalized(np.asarray(y_tr), np.asarray(score_tr)))
                g_te = float(gini_normalized(np.asarray(y_te), np.asarray(score_te)))
                mse_tr = float(mean_squared_error(y_tr, score_tr))
                mse_te = float(mean_squared_error(y_te, score_te))
                # MAPE (handle zeros)
                eps = 1e-8
                mape_tr = float(np.mean(np.abs((np.asarray(y_tr) - np.asarray(score_tr)) / np.maximum(eps, np.abs(np.asarray(y_tr))))))
                mape_te = float(np.mean(np.abs((np.asarray(y_te) - np.asarray(score_te)) / np.maximum(eps, np.abs(np.asarray(y_te))))))
                metrics = {
                    'gini_normalized': (g_tr, g_te),
                    'mse': (mse_tr, mse_te),
                    'mape': (mape_tr, mape_te),
                }
        except ConfigValidationError as e:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.4 skipped</h4><p>{'; '.join(e.args[0])}</p>"}
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.4 error</h4><p>{str(e)}</p>"}

        # Determine signal: red if any metric shows large overfit
        sig = 'green'
        rows = []
        for name, (tr, te) in metrics.items():
            diff = abs(te - tr)
            # Heuristics: stricter for gini, relative for mse/mape
            if name == 'gini_normalized':
                if diff > 0.1:
                    sig = 'red'
                elif diff > 0.05 and sig != 'red':
                    sig = 'orange'
            elif name in ('mse', 'mape'):
                rel = (te - tr) / max(1e-8, tr)
                if rel > 0.3:
                    sig = 'red'
                elif rel > 0.15 and sig != 'red':
                    sig = 'orange'
            rows.append({'metric': name, 'train': f"{tr:.6f}", 'test': f"{te:.6f}", 'abs_diff': f"{diff:.6f}"})

        self.test_signal = sig
        df_res = pd.DataFrame(rows)
        html = f"<h4>M4.4 Overfitting ({task})</h4><p>Signal: <b style='color:{sig}'>{sig}</b></p>{df_res.to_html(index=False)}"
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}


class M45_MetricStabilityTest(BaseModelTest):
    def __init__(self):
        super().__init__('M 4.5', 'Metric Stability Over Time')

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'test', freq: str = 'M', n_bins: int = 20) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        task = getattr(cfg, 'task', None)
        if task not in ('classification', 'regression'):
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.5 skipped</h4><p>Unknown task in config; expected 'classification' or 'regression'.</p>"}

        date_col = cfg.columns.date_column
        if date_col not in df.columns:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.5 skipped</h4><p>Config must provide a valid date_column for stability over time.</p>"}

        df_tr, df_te, df_all = split_frames(df, cfg)
        df_used = {'train': df_tr, 'test': df_te, 'genpop': df_all}.get(sample, df_te)
        df_used = df_used.copy()
        df_used[date_col] = pd.to_datetime(df_used[date_col], errors='coerce')
        df_used = df_used.dropna(subset=[date_col])

        # Helper: CI via normal approx for mean of a series
        def _ci_mean(vals: np.ndarray, alpha: float):
            vals = np.asarray(vals, dtype=float)
            n = len(vals)
            if n < 2:
                return (np.nan, np.nan)
            m = float(np.nanmean(vals))
            s = float(np.nanstd(vals, ddof=1))
            z = 1.96 if alpha == 0.05 else 2.575
            se = s / max(1.0, np.sqrt(n))
            return (m - z * se, m + z * se)

        # Build metric series per period
        period_groups = df_used.groupby(pd.Grouper(key=date_col, freq=freq))

        plots = []
        metrics_to_plot = []
        if task == 'classification':
            metrics_to_plot = ['f1']
        else:
            metrics_to_plot = ['gini_normalized', 'mse', 'mape']

        for metric in metrics_to_plot:
            dates = []
            vals = []
            ci95_l, ci95_h, ci99_l, ci99_h = [], [], [], []
            obs = []
            for period, g in period_groups:
                if g is None or len(g) == 0 or pd.isna(period):
                    continue
                try:
                    if task == 'classification':
                        y, pred, score = get_vectors(g, cfg, for_classification=True)
                        labels = _safe_threshold_labels(pred if pred is not None else score)
                        v = float(f1_score(y, labels, zero_division=0))
                        # build pseudo-sample for CI: treat as mean of per-row scores (approx)
                        per_row = labels == y
                        low95, high95 = _ci_mean(np.asarray(per_row, dtype=float), 0.05)
                        low99, high99 = _ci_mean(np.asarray(per_row, dtype=float), 0.01)
                    else:
                        y, _, s = get_vectors(g, cfg, for_classification=False)
                        if metric == 'gini_normalized':
                            v = float(gini_normalized(np.asarray(y), np.asarray(s)))
                            # approximate CI like in M2.4
                            n = len(g)
                            z95, z99 = 1.96, 2.575
                            se = np.sqrt(max(1e-9, v * (1 - v)) / max(1, n))
                            low95, high95 = v - z95 * se, v + z95 * se
                            low99, high99 = v - z99 * se, v + z99 * se
                        elif metric == 'mse':
                            err = np.asarray(y) - np.asarray(s)
                            per = err**2
                            v = float(np.mean(per))
                            low95, high95 = _ci_mean(per, 0.05)
                            low99, high99 = _ci_mean(per, 0.01)
                        else:  # mape
                            eps = 1e-8
                            yv = np.asarray(y, dtype=float)
                            sv = np.asarray(s, dtype=float)
                            mask = np.abs(yv) > eps
                            per = np.abs((yv[mask] - sv[mask]) / np.maximum(eps, np.abs(yv[mask])))
                            if len(per) == 0:
                                continue
                            v = float(np.mean(per))
                            low95, high95 = _ci_mean(per, 0.05)
                            low99, high99 = _ci_mean(per, 0.01)
                    dates.append(pd.to_datetime(period))
                    vals.append(v)
                    ci95_l.append(low95)
                    ci95_h.append(high95)
                    ci99_l.append(low99)
                    ci99_h.append(high99)
                    obs.append(int(len(g)))
                except Exception:
                    continue
            if not dates:
                continue

            order = np.argsort(pd.to_datetime(dates))
            d = np.array(dates)[order]
            v = np.array(vals)[order]
            l95 = np.array(ci95_l)[order]
            h95 = np.array(ci95_h)[order]
            l99 = np.array(ci99_l)[order]
            h99 = np.array(ci99_h)[order]
            nobs = np.array(obs)[order]

            fig, ax1 = plt.subplots(figsize=(12, 4))
            ax2 = ax1.twinx()
            # Bars: observations
            ax2.bar(d, nobs, alpha=0.6, color='#2ca02c', label=OBSERVATION_COUNT_LABEL)
            # CI fills (continuous)
            ax1.fill_between(d, l99, h99, alpha=0.3, color='#ff4444', label='99% CI')
            ax1.fill_between(d, l95, h95, alpha=0.5, color='#ffcc00', label='95% CI')
            # Main line
            ax1.plot(d, v, color='black', linewidth=2, marker='o', markersize=4, label=metric)
            # Thresholds for gini
            if metric == 'gini_normalized':
                ax1.axhline(y=0.15, color='red', linestyle='--', alpha=0.7)
                ax1.axhline(y=0.35, color='orange', linestyle='--', alpha=0.7)
            ax1.set_xlabel('Period')
            ylabel = {
                'gini_normalized': 'Normalized Gini',
                'mse': 'MSE',
                'mape': 'MAPE',
                'f1': 'F1'
            }.get(metric, 'Metric')
            ax1.set_ylabel(ylabel)
            ax2.set_ylabel(OBSERVATION_COUNT_LABEL)
            ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
            ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
            plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')
            ax1.legend(loc='upper left')
            fig.tight_layout()
            plots.append((metric, _to_base64(fig)))

        if not plots:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.5 skipped</h4><p>No metric could be computed by periods.</p>"}

        # Assemble HTML with all plots
        parts = [f"<h4>M4.5 Metric Stability ({task})</h4>"]
        for metric, img in plots:
            title = {
                'gini_normalized': 'Normalized Gini over Time with Confidence Intervals',
                'mse': 'MSE over Time with Confidence Intervals',
                'mape': 'MAPE over Time with Confidence Intervals',
                'f1': 'F1 over Time with Confidence Intervals'
            }.get(metric, metric)
            parts.append(f"<h5>{title}</h5><img src='data:image/png;base64,{img}' />")
        self.test_signal = self.test_signal or 'blue'
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": "".join(parts)}




class M47_ShapImportanceTest(BaseModelTest):
    """
    Section 4.3.1. SHAP importance comparison between training and validation
    (Test disabled as SHAP is removed from dependencies)
    """
    def __init__(self):
        super().__init__("M 4.7", "SHAP Importance Comparison")

    def run(self, df: pd.DataFrame, config: dict, model, top_n: int = 20) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting (DISABLED)")
        self.test_signal = 'blue'
        return {"report": "<h4>SHAP Importance Comparison Test</h4><p>This test is disabled because SHAP library has been removed.</p>"}


class M48_FeatureContributionTest(BaseModelTest):
    """
    M4.8: Feature reduction / informativeness test.

    Цель: выявить признаки, которые не вносят вклад в улучшение метрики и могут быть удалены
    без ухудшения качества/стабильности модели. Основной метод — SHAP importance.
    В качестве валидатора используется forward selection (fallback) или backward selection.

    Поведение:
      * пытается вычислить SHAP importance; если shap недоступен — использует forward selection;
      * строит uplift-кривые (train / valid / test при наличии);
      * вычисляет бутстрэпный CI для разницы метрик между лучшей reduced-моделью и моделью на всех признаках;
      * выставляет сигнал по критериям 99%/95% CI на validation (или на train при отсутствии validation).
    """

    def __init__(self, model_type: str = 'classification', step: int = 1, n_bootstrap: int = 300):
        super().__init__("M 4.8", "Feature Contribution / Reduction Test")
        self.model_type = model_type
        self.step = int(step)
        self.n_bootstrap = int(n_bootstrap)

    def run(self, df: pd.DataFrame, config: dict, model_class=None, model=None, sample_col_name: str = None) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        # determine samples
        sample_col = getattr(cfg.columns, 'sample_column', None) if sample_col_name is None else sample_col_name
        df_tr, df_te, df_all = split_frames(df, cfg)
        # detect validation split if present
        val_split = None
        if sample_col and sample_col in df.columns:
            uniq = df[sample_col].astype(str).str.lower().unique().tolist()
            for cand in ('validation', 'valid', 'val'):
                if cand in uniq:
                    val_split = cand
                    break

        df_val = None
        if val_split:
            df_val = df[df[sample_col].astype(str).str.lower() == val_split].copy()

        # pick eval set for signal: prefer validation, else use train
        signal_set = 'validation' if df_val is not None else 'train'

        # feature list
        feats = get_features(df, cfg, include_categorical=True)
        if not feats:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 skipped</h4><p>No features configured (numeric/categorical).</p>"}

        # prepare data
        df_train = df_tr.copy()
        df_valid = df_val.copy() if df_val is not None else None
        df_test = df_te.copy()

        target = cfg.columns.target_column
        if target not in df.columns:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 skipped</h4><p>target_column missing in df.</p>"}

        y_tr = df_train[target]
        y_val = df_valid[target] if df_valid is not None else None
        y_te = df_test[target]

        # metric selection
        is_class = (str(getattr(cfg, 'task', None) or self.model_type).lower() == 'classification')
        metric_func = (lambda a, b: f1_score(a, b, zero_division=0)) if is_class else (lambda a, b: r2_score(a, b))

        # get feature importance ordering: only fallback (SHAP removed)
        SHAP_AVAILABLE = False
        importance_order: List[str] = []

        # fallback: forward selection (validator)
        if not importance_order:
            # simple forward selection based on improvement on validation (or train)
            base_pool = feats.copy()
            chosen = []
            eval_df = df_valid if df_valid is not None else df_train
            X_eval_base = eval_df
            y_eval_base = y_val if df_valid is not None else y_tr
            while base_pool:
                best_feat = None
                best_score = -np.inf
                for f in tqdm(base_pool, desc='Forward selection: перебор кандидатов', leave=True):
                    cand = chosen + [f]
                    try:
                        m = model_class() if model_class is not None else (model if model is not None else None)
                        if m is None:
                            continue
                        Xc = df_train[cand]
                        m.fit(Xc, y_tr)
                        preds = m.predict(X_eval_base[cand])
                        if is_class:
                            preds = _safe_threshold_labels(preds)
                        sc = metric_func(y_eval_base, preds)
                    except Exception:
                        sc = -np.inf
                    if sc > best_score:
                        best_score = sc
                        best_feat = f
                if best_feat is None:
                    break
                chosen.append(best_feat)
                base_pool.remove(best_feat)
            importance_order = chosen if chosen else feats

        # ensure order contains only available feats
        importance_order = [f for f in importance_order if f in feats]

        # build uplift curves: train / valid / test
        results = []  # tuples (k, score_train, score_val, score_test)
        full_model = model_class() if model_class is not None else (model if model is not None else None)
        if full_model is None:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 skipped</h4><p>Provide model_class or prefit model.</p>"}

        # fit full model
        try:
            full_model.fit(df_train[importance_order], y_tr)
            preds_full_val = full_model.predict(df_valid[importance_order]) if df_valid is not None else None
            preds_full_tr = full_model.predict(df_train[importance_order])
            preds_full_te = full_model.predict(df_test[importance_order])
            if is_class:
                if preds_full_val is not None:
                    preds_full_val = _safe_threshold_labels(preds_full_val)
                preds_full_tr = _safe_threshold_labels(preds_full_tr)
                preds_full_te = _safe_threshold_labels(preds_full_te)
        except Exception as e:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": f"<h4>M4.8 error</h4><p>Failed to fit full model: {e}</p>"}

        # baseline metrics
        base_val_score = metric_func(y_val, preds_full_val) if df_valid is not None else None
        base_tr_score = metric_func(y_tr, preds_full_tr)
        base_te_score = metric_func(y_te, preds_full_te)

        for k in tqdm(range(self.step, len(importance_order) + 1, self.step), desc='Оценка reduced-моделей по k признакам', leave=True):
            use_feats = importance_order[:k]
            try:
                m = model_class()
                m.fit(df_train[use_feats], y_tr)
                p_tr = m.predict(df_train[use_feats])
                p_te = m.predict(df_test[use_feats])
                p_val = m.predict(df_valid[use_feats]) if df_valid is not None else None
                if is_class:
                    p_tr = _safe_threshold_labels(p_tr)
                    p_te = _safe_threshold_labels(p_te)
                    if p_val is not None:
                        p_val = _safe_threshold_labels(p_val)
                s_tr = metric_func(y_tr, p_tr)
                s_te = metric_func(y_te, p_te)
                s_val = metric_func(y_val, p_val) if df_valid is not None else None
            except Exception:
                s_tr = float('nan'); s_val = float('nan'); s_te = float('nan')
            results.append((k, s_tr, s_val, s_te))

        res_df = pd.DataFrame(results, columns=['#Features', 'Train', 'Valid', 'Test'])

        # find best reduced model on validation (or train)
        if df_valid is not None and not res_df['Valid'].isna().all():
            best_idx = int(res_df['Valid'].idxmax())
            best_row = res_df.iloc[best_idx]
            best_k = int(best_row['#Features'])
            best_score = float(best_row['Valid'])
            baseline_score = base_val_score
            y_eval = y_val
            preds_full_eval = preds_full_val
            # get preds for best reduced
            try:
                m_best = model_class(); m_best.fit(df_train[importance_order[:best_k]], y_tr)
                preds_best_eval = m_best.predict(df_valid[importance_order[:best_k]])
                if is_class: preds_best_eval = _safe_threshold_labels(preds_best_eval)
            except Exception:
                preds_best_eval = None
        else:
            # no validation -> use train
            best_idx = int(res_df['Train'].idxmax())
            best_row = res_df.iloc[best_idx]
            best_k = int(best_row['#Features'])
            best_score = float(best_row['Train'])
            baseline_score = base_tr_score
            y_eval = y_tr
            preds_full_eval = preds_full_tr
            try:
                m_best = model_class(); m_best.fit(df_train[importance_order[:best_k]], y_tr)
                preds_best_eval = m_best.predict(df_train[importance_order[:best_k]])
                if is_class: preds_best_eval = _safe_threshold_labels(preds_best_eval)
            except Exception:
                preds_best_eval = None

        # if best_k equals full features -> no insignificant features
        if best_k >= len(importance_order):
            self.test_signal = 'green'
            html = f"<h4>M4.8 No insignificant features found</h4><p>Best model uses full set of features (k={best_k}).</p>" + res_df.to_html(index=False)
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": html}

        # bootstrap difference distribution
        if preds_best_eval is None or preds_full_eval is None:
            self.test_signal = 'red'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.8 error</h4><p>Could not obtain predictions for comparison.</p>"}

        diffs = []
        rng = np.random.RandomState(42)
        n = len(y_eval)
        for _ in tqdm(range(self.n_bootstrap), desc='Бутстрэп разницы метрик', leave=True):
            idx = rng.randint(0, n, n)
            y_s = y_eval.iloc[idx].values
            full_s = np.array(preds_full_eval)[idx]
            best_s = np.array(preds_best_eval)[idx]
            try:
                diffs.append(metric_func(y_s, best_s) - metric_func(y_s, full_s))
            except Exception:
                diffs.append(float('nan'))

        diffs = np.array(diffs)
        lo99, hi99 = np.nanpercentile(diffs, [0.5, 99.5])
        lo95, hi95 = np.nanpercentile(diffs, [2.5, 97.5])

        # determine signal per spec
        if lo99 > 0:
            signal = 'green'
            reason = '99% CI of metric difference > 0 (improvement)'
        elif lo95 > 0:
            signal = 'orange'
            reason = '95% CI of metric difference > 0 (improvement)'
        else:
            signal = 'red'
            reason = '0 in 95% CI of metric difference or no significant improvement'

        self.test_signal = signal

        # build plots: uplift curves
        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(res_df['#Features'], res_df['Train'], marker='o', label='Train')
        if 'Valid' in res_df.columns and not res_df['Valid'].isna().all():
            ax.plot(res_df['#Features'], res_df['Valid'], marker='o', label='Valid')
        if 'Test' in res_df.columns and not res_df['Test'].isna().all():
            ax.plot(res_df['#Features'], res_df['Test'], marker='o', label='Test')
        ax.set_xlabel('# Features')
        ax.set_ylabel('Metric')
        ax.set_title('Feature Uplift Curves')
        ax.legend()
        plt.tight_layout()
        plot_b64 = _to_base64(fig)

        html = f"<h4>M4.8 Feature Reduction Test (best_k={best_k})</h4>"
        html += f"<p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span> — {reason}</p>"
        html += f"<p>Best k = {best_k}, improvement = {best_score - baseline_score:.4f} (95% CI [{lo95:.4f}, {hi95:.4f}], 99% CI [{lo99:.4f}, {hi99:.4f}])</p>"
        html += f"<img src=\"data:image/png;base64,{plot_b64}\"/>"
        html += "<h5>Uplift table</h5>" + res_df.to_html(index=False, float_format='%.4f')

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}

class M49_UpliftTest(BaseModelTest):
    def __init__(self, model_type: str = 'classification', step: int = 1):
        super().__init__("M 4.9", "Feature Uplift Test")
        self.model_type = model_type
        self.step = step

    def run(self,
            df: pd.DataFrame = None,
            config: dict = None,
            model_class=None,
            feature_importance: pd.Series | None = None,
            X_train: pd.DataFrame | None = None, y_train: pd.Series | None = None,
            X_test: pd.DataFrame | None = None, y_test: pd.Series | None = None
            ) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")

        # --- Backward compatibility ---
        if df is None and all(v is not None for v in [X_train, y_train, X_test, y_test, model_class]) and config is None:
            feats_order = list(feature_importance.index) if isinstance(feature_importance, pd.Series) else list(X_train.columns)
        else:
            if df is None or config is None or model_class is None:
                raise ValueError("Please provide df, config and model_class.")
            
            cfg = ensure_config(config, df)
            sample_col = get_col_name(cfg, "sample_column")
            target_col = get_col_name(cfg, "target_column")

            df_tr = _subset_by_sample(df, config, "train")
            df_te = _subset_by_sample(df, config, "test")
            feats = get_features(df, cfg, include_categorical=True)
            X_train = df_tr[feats].copy()
            X_test  = df_te[feats].copy()
            y_train = df_tr[target_col]
            y_test  = df_te[target_col]

            # порядок признаков: если передали — используем, иначе — учим модель и берём feature_importances_
            if isinstance(feature_importance, pd.Series):
                feats_order = [f for f in feature_importance.sort_values(ascending=False).index if f in X_train.columns]
            else:
                base_model = model_class()
                base_model.fit(X_train, y_train)
                if hasattr(base_model, "feature_importances_"):
                    importances = pd.Series(base_model.feature_importances_, index=X_train.columns).sort_values(ascending=False)
                    feats_order = list(importances.index)
                else:
                    # fallback: как пришли
                    feats_order = list(X_train.columns)

        # основной цикл добавления признаков
        results = []
        best_test = -np.inf
        optimal_features = 0

        for k in tqdm(range(self.step, len(feats_order) + 1, self.step), desc='Uplift: добавление признаков', leave=True):
            use_feats = feats_order[:k]
            model = model_class()
            model.fit(X_train[use_feats], y_train)

            if self.model_type == "classification":
                y_pred = model.predict(X_test[use_feats])
                score = f1_score(y_test, y_pred)
            else:
                y_pred = model.predict(X_test[use_feats])
                score = r2_score(y_test, y_pred)

            results.append((k, score))
            if score > best_test:
                best_test = score
                optimal_features = k

        res_df = pd.DataFrame(results, columns=["#Features", "TestScore"])
        max_test_score = res_df["TestScore"].max()

        # светофор
        if len(res_df) >= 3 and res_df["TestScore"].iloc[-1] < max_test_score * 0.98:
            signal = "red"      # явное ухудшение к концу — лишние фичи
        elif len(res_df) >= 3 and res_df["TestScore"].iloc[-1] < max_test_score * 0.995:
            signal = "orange"   # лёгкое ухудшение
        else:
            signal = "green"

        # график
        plt.figure(figsize=(12, 8))
        plt.plot(res_df["#Features"], res_df["TestScore"], marker="o")
        plt.axvline(optimal_features, linestyle="--")
        plt.xlabel("#Features")
        plt.ylabel("Score")
        plt.title("Feature Uplift Curve")
        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight")
        plt.close()
        plot_img = base64.b64encode(buf.getvalue()).decode("utf-8")

        self.test_signal = signal
        html_content = f"""
        <h4>Feature Uplift Test</h4>
        <p><strong>Signal:</strong> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span></p>
        <p><strong>Optimal number of features:</strong> {optimal_features}</p>
        <p><strong>Max test score:</strong> {max_test_score:.4f}</p>
        <img src="data:image/png;base64,{plot_img}" />
        <p><strong>Интерпретация:</strong> Если кривая test выходит на плато или начинает снижаться, 
        это может указывать на наличие избыточных признаков.</p>
        """
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html_content}


class M410_MissingValuesImpactTest(BaseModelTest):
    """
    Тест 4.10. Определение признаков с большим количеством пропущенных значений
    """
    def __init__(self, threshold=0.8):
        super().__init__('M 4.10', 'Features with High Missing Value Ratio')
        self.threshold = threshold

    def run(self,
            df: pd.DataFrame = None,
            config: dict = None,
            X: pd.DataFrame = None,              # legacy-режим (обратная совместимость)
            time_column: str | None = None       # legacy-режим
            ) -> Dict[str, str]:
        """
        Новый контракт: передавайте df + config.
        Legacy: X + time_column продолжает работать.
        """
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        import io, base64
        import numpy as np
        import pandas as pd
        import matplotlib.pyplot as plt

        # --- Новый путь: df + config ---
        if df is not None and config is not None:
            # поддержка вложенного вида config["columns"]
            cols = config["columns"] if isinstance(config, dict) and "columns" in config else config

            # соберём список фич из конфига
            num = cols.get("numeric_features", []) or []
            cat = cols.get("categorical_features", []) or []
            features = list(dict.fromkeys([*num, *cat]))  # порядок + без дублей

            # исключим служебные колонки
            reserved = {
                cols.get("date_column"),
                cols.get("target_column"),
                cols.get("sample_column"),
                cols.get("id_column"),
                cols.get("score_column"),
                cols.get("prediction_column"),
            }
            features = [f for f in features if f and f not in reserved]

            if not features:
                raise ValueError("Пустой список признаков: задайте numeric_features и/или categorical_features в config.columns")

            missing = [c for c in features if c not in df.columns]
            if missing:
                raise KeyError(f"В DataFrame отсутствуют колонки из списка фич: {missing}")

            X_use = df[features].copy()
            time_col = cols.get("date_column", None)

            # приведём дату к datetime для временных графиков
            if time_col and time_col in df.columns:
                try:
                    df = df.copy()
                    df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
                except Exception:
                    pass

        # --- Legacy путь: X + time_column ---
        elif X is not None:
            X_use = X.copy()
            time_col = time_column
            # в legacy режиме у нас может не быть df; временная динамика будет недоступна, если time_col не в X_use
            if time_col is not None and time_col not in X_use.columns:
                # ок, просто игнорируем динамику
                time_col = None
        else:
            raise ValueError("Передайте либо (df, config), либо (X, time_column)")

        # ===== 1) Доля пропусков по признакам =====
        feature_columns = [c for c in X_use.columns if c != time_col]  # не анализируем саму колонку времени
        X_features = X_use[feature_columns]

        missing_ratios = X_features.isnull().mean().sort_values(ascending=False)
        high_missing = missing_ratios[missing_ratios > self.threshold]

        # ===== 2) Визуализация: топ-30 признаков по доле пропусков (barh) =====
        plots_html = []
        if len(missing_ratios) > 0:
            top = missing_ratios.head(30)[::-1]  # для горизонтального барчарта снизу вверх
            fig, ax = plt.subplots(figsize=(12, 8))
            ax.barh(top.index, top.values)
            ax.set_xlim(0, 1)
            ax.set_xlabel("Missing ratio")
            ax.set_title("Missing values ratio by feature (top 30)")
            ax.grid(True, linestyle="--", linewidth=0.5, axis="x")
            plt.tight_layout()

            buf = io.BytesIO()
            plt.savefig(buf, format="png", dpi=120, bbox_inches="tight")
            plt.close(fig)
            img_bar = base64.b64encode(buf.getvalue()).decode("utf-8")
            plots_html.append(f'<h5>Top-30 missing ratios</h5><img src="data:image/png;base64,{img_bar}">')

        # ===== 3) Таблица признаков с высокой долей пропусков =====
        table_html = "<p><i>Нет признаков с долей пропусков выше порога.</i></p>"
        if len(high_missing) > 0:
            tbl = high_missing.to_frame(name="MissingRatio").reset_index().rename(columns={"index": "Feature"})
            tbl["MissingRatio"] = (tbl["MissingRatio"] * 100).round(2)
            table_html = tbl.to_html(index=False)

        # ===== 4) Динамика пропусков по времени (heatmap для high_missing) =====
        heatmap_html = ""
        if time_col is not None and time_col in getattr(df, "columns", []) and len(high_missing) > 0:
            # соберём фрейм: время + интересующие признаки
            tmp = pd.concat([df[[time_col]].reset_index(drop=True),
                            X_use[high_missing.index].reset_index(drop=True)], axis=1)
            tmp = tmp.dropna(subset=[time_col])
            if len(tmp) > 0:
                # месячная агрегация по умолчанию
                tmp[time_col] = pd.to_datetime(tmp[time_col], errors="coerce")
                tmp = tmp.dropna(subset=[time_col])
                grouped = tmp.groupby(pd.Grouper(key=time_col, freq="M"))
                # матрица: периоды x признаки (доля пропусков)
                periods = []
                rows = []
                for period, g in grouped:
                    if period is pd.NaT:
                        continue
                    periods.append(period)
                    rows.append(g[high_missing.index].isnull().mean().values)
                if len(rows) > 0:
                    M = np.vstack(rows)  # shape: (#periods, #features)
                    # строим heatmap (features x periods)
                    fig2, ax2 = plt.subplots(figsize=(max(10, len(periods) * 0.4),
                                                    max(4, len(high_missing) * 0.5)))
                    im = ax2.imshow(M.T, aspect="auto", origin="lower", vmin=0, vmax=1)
                    ax2.set_yticks(np.arange(len(high_missing.index)))
                    ax2.set_yticklabels(high_missing.index)
                    ax2.set_xticks(np.arange(len(periods)))
                    ax2.set_xticklabels([p.strftime("%Y-%m") for p in periods],
                                        rotation=45, ha="right")
                    ax2.set_title("Missing ratio over time (features with high missing)")
                    ax2.grid(False)
                    cbar = fig2.colorbar(im, ax=ax2, fraction=0.025, pad=0.02)
                    cbar.set_label("Missing ratio")
                    plt.tight_layout()

                    buf2 = io.BytesIO()
                    plt.savefig(buf2, format="png", dpi=120, bbox_inches="tight")
                    plt.close(fig2)
                    img_heat = base64.b64encode(buf2.getvalue()).decode("utf-8")
                    heatmap_html = f'<h5>Dynamics heatmap (monthly)</h5><img src="data:image/png;base64,{img_heat}">'

        # ===== 5) Сигнал по доле «плохих» признаков =====
        share_high = (len(high_missing) / max(len(feature_columns), 1)) if len(feature_columns) else 0.0
        if share_high == 0:
            signal = "green"
        elif share_high <= 0.10:
            signal = "yellow"
        else:
            signal = "red"
        self.test_signal = signal

        # ===== 6) Сборка HTML =====
        header = f"""
        <h4>Features with High Missing Value Ratio (threshold = {int(self.threshold*100)}%)</h4>
        <p><b>Signal:</b> <span style="color:{signal}; font-weight:bold">{signal.upper()}</span></p>
        <p>Всего фич (без time): <b>{len(feature_columns)}</b>. 
        Фич с пропусками &gt; {int(self.threshold*100)}%: <b>{len(high_missing)}</b> 
        ({round(share_high*100, 2)}%).</p>
        """

        html = header + "".join(plots_html) + "<h5>Features above threshold</h5>" + table_html + heatmap_html
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": html}


class M411_TwoForestSelectionTest(BaseModelTest):
    """
    M4.11 Двухлесовой отбор (Two-Forest Selection)

    Для каждого признака вычисляется распределение разниц важности между честной
    моделью и моделью с перемешанным признаком, при обучении на первой половине
    и проверке на второй, и наоборот. p-value строится по эмпирическому распределению
    согласно описанию пользователя.
    """
    def __init__(self, model_type: str = 'classification', n_repeat: int = 300, test_size: float = 0.5, random_state: int = 42):
        super().__init__('M 4.11', 'Two-Forest Selection')
        self.model_type = model_type
        self.n_repeat = int(n_repeat)
        self.test_size = float(test_size)
        self.random_state = int(random_state)

    def run(self, df: pd.DataFrame, config: dict, sample: str = 'train') -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        # features
        feats = list(getattr(cfg.columns, 'numeric_features', []) or []) + list(getattr(cfg.columns, 'categorical_features', []) or [])
        feats = [f for f in feats if f in df.columns]
        if not feats:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.11 skipped</h4><p>No features configured.</p>"}

        # pick sample subset
        df_tr = _subset_by_sample(df, config if isinstance(config, dict) else {'columns': cfg.columns}, sample)
        if df_tr is None or len(df_tr) < 4:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.11 skipped</h4><p>Not enough rows in selected sample.</p>"}

        target = get_col_name(cfg, 'target_column')
        if target not in df_tr.columns:
            self.test_signal = 'blue'
            logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
            return {"report": "<h4>M4.11 skipped</h4><p>target_column missing in df.</p>"}

        X = df_tr[feats].copy()
        y = df_tr[target].copy()

        # choose model class
        is_class = (str(getattr(cfg, 'task', None) or self.model_type).lower() == 'classification')
        Model = RandomForestClassifier if is_class else RandomForestRegressor

        rng = np.random.RandomState(self.random_state)

        # store diffs per feature for both directions
        diffs_A = {f: [] for f in feats}  # train on A, test on B
        diffs_B = {f: [] for f in feats}  # train on B, test on A

        # helper: compute importance score as mean agreement with target on holdout
        def importance_score(model, X_hold, y_hold, feature):
            try:
                preds = model.predict(X_hold)
                # for classification we compare predicted label to y_hold
                if is_class:
                    return float((preds == y_hold).mean())
                else:
                    # regression: use negative MSE as higher-is-better proxy
                    from sklearn.metrics import mean_squared_error
                    return -float(mean_squared_error(y_hold, preds))
            except Exception:
                return float('nan')

        n = len(X)
        idx_all = np.arange(n)
        for direction in (0, 1):
            # direction 0: train on split A -> test on B; direction 1: train on B -> test on A
            for rep in range(self.n_repeat):
                # random split into two halves
                i_tr, i_te = train_test_split(idx_all, test_size=self.test_size, random_state=rng.randint(0, 2**31-1))

                X_A, X_B = X.iloc[i_tr].reset_index(drop=True), X.iloc[i_te].reset_index(drop=True)
                y_A, y_B = y.iloc[i_tr].reset_index(drop=True), y.iloc[i_te].reset_index(drop=True)

                if direction == 0:
                    X_train, y_train, X_test, y_test = X_A, y_A, X_B, y_B
                else:
                    X_train, y_train, X_test, y_test = X_B, y_B, X_A, y_A

                # fit honest model on X_train
                try:
                    m = Model(random_state=rng.randint(0, 2**31-1))
                    m.fit(X_train, y_train)
                except Exception:
                    # skip this repetition
                    continue

                # compute importance per feature as score when predicting on X_test
                base_scores = {}
                for f in tqdm(feats, desc='Вычисление базовых скорoв (по фиче)', leave=True):
                    base_scores[f] = importance_score(m, X_test, y_test, f)

                # now permute each feature on train and refit
                for f in tqdm(feats, desc='Перестановки и переобучение (по фиче)', leave=True):
                    X_perm = X_train.copy()
                    X_perm[f] = X_perm[f].sample(frac=1.0, random_state=rng.randint(0, 2**31-1)).reset_index(drop=True)
                    try:
                        m2 = Model(random_state=rng.randint(0, 2**31-1))
                        m2.fit(X_perm, y_train)
                    except Exception:
                        continue
                    perm_score = importance_score(m2, X_test, y_test, f)
                    diff = base_scores.get(f, float('nan')) - perm_score
                    if direction == 0:
                        diffs_A[f].append(diff)
                    else:
                        diffs_B[f].append(diff)

        # compute p-values per feature: follow user's spec
        import scipy.stats as st
        results = []
        x_vals = []
        y_vals = []
        for f in feats:
            dA = np.array(diffs_A.get(f, []) or [0.0])
            dB = np.array(diffs_B.get(f, []) or [0.0])

            # build null distribution from negative and zero scores as described
            negA = -dA[dA <= 0]
            negB = -dB[dB <= 0]
            posA = dA[dA > 0]
            posB = dB[dB > 0]

            # empirical CDF: p = 1 - CDF( observed_positive ) over flipped negative set
            # handle empty sets
            def emp_pval(observed, null_set):
                if len(null_set) == 0:
                    return 1.0
                return 1.0 - (np.searchsorted(np.sort(null_set), observed, side='right') / len(null_set))

            # combine positive diffs from both directions appropriately
            obsA = posA.mean() if len(posA) > 0 else 0.0
            obsB = posB.mean() if len(posB) > 0 else 0.0

            pA = emp_pval(obsA, negA) if len(negA) > 0 else 1.0
            pB = emp_pval(obsB, negB) if len(negB) > 0 else 1.0

            # aggregate p-values conservatively (max)
            pval = max(pA, pB)

            results.append({'feature': f, 'p_value': float(pval), 'mean_diff_A': float(np.nanmean(dA)), 'mean_diff_B': float(np.nanmean(dB)), 'nA': int(len(dA)), 'nB': int(len(dB))})
            x_vals.append(np.nanmean(dA))
            y_vals.append(np.nanmean(dB))

        res_df = pd.DataFrame(results).sort_values('p_value')

        # scatter plot mean diffs
        fig = plt.figure(figsize=(6, 6))
        plt.scatter(x_vals, y_vals)
        plt.axhline(0, color='gray', linestyle='--')
        plt.axvline(0, color='gray', linestyle='--')
        plt.xlabel('Mean diff (train A -> test B)')
        plt.ylabel('Mean diff (train B -> test A)')
        plt.title('Two-Forest mean importance diffs')
        for i, f in enumerate(feats):
            plt.text(x_vals[i], y_vals[i], f, fontsize=8)
        plt.tight_layout()
        plot_b64 = _to_base64(fig)

        html = f"<h4>M4.11 Two-Forest Selection</h4><p>n_repeat={self.n_repeat}, sample fraction test_size={self.test_size}</p>"
        html += f"<img src='data:image/png;base64,{plot_b64}' />"
        html += "<h5>Feature p-values (sorted)</h5>" + res_df.to_html(index=False, float_format='%.4g')

        # signal: features with p < 0.05 are considered stable important
        sig_count = (res_df['p_value'] < 0.05).sum()
        self.test_signal = 'green' if sig_count > 0 else 'red'

        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"report": html}

