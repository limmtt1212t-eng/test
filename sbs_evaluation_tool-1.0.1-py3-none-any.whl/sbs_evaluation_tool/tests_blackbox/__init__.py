"""Public black-box test suite namespace for SBS Evaluation Tool.

Examples
--------
    from sbs_evaluation_tool.tests_blackbox.m1_sampling_tests import M11_SamplingTest
"""
