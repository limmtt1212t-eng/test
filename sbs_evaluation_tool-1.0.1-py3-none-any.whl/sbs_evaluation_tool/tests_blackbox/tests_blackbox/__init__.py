"""Black-box test variants for SBS Evaluation Tool (optional).

These tests are primarily used for external / black-box validation flows.
"""
