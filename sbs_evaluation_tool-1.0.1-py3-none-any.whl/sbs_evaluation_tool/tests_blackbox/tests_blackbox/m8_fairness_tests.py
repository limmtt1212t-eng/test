import logging
import math
import warnings
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score

# Suppress sklearn warnings about single class ROC AUC
warnings.filterwarnings('ignore', 'Only one class is present in y_true', UserWarning, 'sklearn')
warnings.filterwarnings('ignore', 'invalid value encountered', RuntimeWarning)

from core.base_test import BaseModelTest
from core.config_validation import validate_config

logger = logging.getLogger(__name__)


def _to_base64(fig):
	import io, base64
	buf = io.BytesIO()
	fig.savefig(buf, format='png', bbox_inches='tight')
	buf.seek(0)
	img = base64.b64encode(buf.read()).decode('utf-8')
	plt.close(fig)
	return img


def _gini_from_probs(y_true: np.ndarray, y_score: np.ndarray) -> float:
	try:
		# Check if we have at least two classes
		unique_classes = np.unique(y_true)
		if len(unique_classes) < 2:
			return float('nan')
		
		# Suppress sklearn warnings about single class
		with warnings.catch_warnings():
			warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')
			aucv = roc_auc_score(y_true, y_score)
			return 2.0 * aucv - 1.0
	except Exception:
		return float('nan')


def _spearman_corr(y_true: np.ndarray, y_score: np.ndarray) -> float:
	try:
		r = spearmanr(y_true, y_score)
		return float(r.correlation)
	except Exception:
		return float('nan')


def _bootstrap_ci(func, y_true: np.ndarray, y_score: np.ndarray, n_boot: int = 500, alpha: float = 0.95) -> Tuple[float, float]:
	"""Compute percentile bootstrap CI (returns lower, upper)"""
	vals = []
	n = len(y_true)
	rng = np.random.RandomState(42)
	for _ in tqdm(range(n_boot), desc='bootstrap', leave=False):
		idx = rng.randint(0, n, size=n)
		try:
			v = func(y_true[idx], y_score[idx])
			vals.append(v)
		except Exception:
			vals.append(float('nan'))
	arr = np.array([v for v in vals if not math.isnan(v)])
	if arr.size == 0:
		return float('nan'), float('nan')
	lower = np.percentile(arr, (1.0 - alpha) / 2.0 * 100.0)
	upper = np.percentile(arr, (1.0 + alpha) / 2.0 * 100.0)
	return float(lower), float(upper)


class M81_DisparateImpactLevelTest(BaseModelTest):
	"""M8.1 Compare predicted mean level when protected attribute is changed"""

	def __init__(self):
		super().__init__('M8.1', 'Predicted level change when swapping protected attribute')

	def run(self, df: pd.DataFrame, config: dict, protected_columns: List[str] = None, n_swaps: int = 100, **kwargs) -> Dict[str, str]:
		"""
		protected_columns: optional list of columns to test; if None, heuristically detect common protected columns.
		n_swaps: number of random resamples when swapping predictions (default 100)
		"""
		cfg = validate_config(config, df)
		cols = cfg.columns

		# determine protected columns
		if protected_columns is None:
			candidates = ['sex', 'gender', 'race', 'age_group', 'protected', 'privileged', 'discr']
			protected_columns = [c for c in df.columns if c.lower() in candidates]

		if not protected_columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'No protected columns provided or detected'}
			return {"DASHBOARD": '<p>Skipped: no protected columns</p>'}

		sample_col = cols.sample_column
		sample_values = [None]
		if sample_col and sample_col in df.columns:
			sample_values = list(df[sample_col].astype(str).str.lower().unique())

		score_col = cols.score_column or cols.prediction_column
		if score_col is None or score_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'Score/prediction column missing'}
			return {"DASHBOARD": '<p>Skipped: score column missing</p>'}

		# CI95 width computed on whole dataset scores (full width)
		scores = df[score_col].astype(float).values
		n_all = len(scores)
		if n_all <= 1:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'Not enough observations to compute CI'}
			return {"DASHBOARD": '<p>Not enough data</p>'}
		std = float(scores.std(ddof=1))
		se = std / math.sqrt(n_all)
		ci95_width = 2.0 * 1.96 * se  # full width

		overall_worst = 'green'
		per_protected = {}

		for sample in tqdm(sample_values, desc='sample_splits', leave=False):
			if sample is None:
				df_sub = df
				sample_label = 'all'
			else:
				df_sub = df[df[sample_col].astype(str).str.lower() == sample]
				sample_label = sample

			if df_sub.empty:
				continue

			per_feature = {}
			for feat in tqdm(protected_columns, desc='protected_cols', leave=False):
				if feat not in df_sub.columns:
					continue
				levels = df_sub[feat].dropna().unique()
				if len(levels) < 2:
					per_feature[feat] = {'note': 'single level; skipped', 'signal': 'yellow'}
					overall_worst = 'yellow' if overall_worst != 'red' else 'red'
					continue

				max_rel_change = 0.0
				signs = []
				for lvl in levels:
					Dj = df_sub[df_sub[feat] == lvl]
					Dnot = df_sub[df_sub[feat] != lvl]
					if Dj.empty or Dnot.empty:
						continue
					orig_mean_j = float(Dj[score_col].mean())
					orig_mean_not = float(Dnot[score_col].mean())

					# Swap predictions by sampling predictions from opposite group (ASSUMPTION: model recalculation unavailable)
					swapped_means_j = []
					swapped_means_not = []
					rng = np.random.RandomState(42)
					for _ in range(n_swaps):
						sampled_from_not = Dnot[score_col].sample(n=len(Dj), replace=True, random_state=rng).values
						sampled_from_j = Dj[score_col].sample(n=len(Dnot), replace=True, random_state=rng).values
						swapped_means_j.append(float(np.mean(sampled_from_not)))
						swapped_means_not.append(float(np.mean(sampled_from_j)))

					new_mean_j = float(np.mean(swapped_means_j))
					new_mean_not = float(np.mean(swapped_means_not))

					delta_j = (new_mean_j - orig_mean_j) / (ci95_width if ci95_width != 0 else 1.0)
					delta_not = (new_mean_not - orig_mean_not) / (ci95_width if ci95_width != 0 else 1.0)
					max_rel_change = max(max_rel_change, abs(delta_j), abs(delta_not))
					signs.append(np.sign(delta_j) if not math.isnan(delta_j) else 0)
					signs.append(np.sign(delta_not) if not math.isnan(delta_not) else 0)

				# interpret per Table 6.23 (assumptions noted)
				# Assumption: use thresholds as relative changes >0.2 (20%)
				if max_rel_change > 0.2 and len(set(np.sign(signs))) > 1:
					sig = 'red'
				elif max_rel_change > 0.2:
					sig = 'yellow'
				else:
					sig = 'green'

				per_feature[feat] = {'max_rel_change': max_rel_change, 'signal': sig, 'sample': sample_label}
				if sig == 'red':
					overall_worst = 'red'
				elif sig == 'yellow' and overall_worst != 'red':
					overall_worst = 'yellow'

			per_protected[sample_label] = per_feature

		self.test_signal = overall_worst
		self.test_meta = {'per_protected': per_protected, 'ci95_width': ci95_width, 'assumption': 'swapping predictions by sampling opposite-group preds'}

		# Build HTML summary
		html = f"<h4>M8.1 Predicted level sensitivity to protected attribute</h4><p>Signal: <b style='color:{'green' if overall_worst=='green' else ('orange' if overall_worst=='yellow' else 'red')}'>{overall_worst.upper()}</b></p>"
		rows = []
		for s, feats in per_protected.items():
			for f, v in feats.items():
				rows.append({'sample': s, 'feature': f, 'max_rel_change': v.get('max_rel_change', float('nan')), 'signal': v.get('signal')})
		if rows:
			html += pd.DataFrame(rows).to_html(index=False, float_format='%.4f')
		return {"DASHBOARD": html}


class M82_RankingStabilityProtectedTest(BaseModelTest):
	"""M8.2 Compare ranking ability within protected groups via CI on Gini/Spearman"""

	def __init__(self):
		super().__init__('M8.2', 'Ranking stability within protected attributes')

	def run(self, df: pd.DataFrame, config: dict, protected_columns: List[str] = None, n_boot: int = 500, **kwargs) -> Dict[str, str]:
		cfg = validate_config(config, df)
		cols = cfg.columns

		# determine protected columns
		if protected_columns is None:
			candidates = ['sex', 'gender', 'race', 'age_group', 'protected', 'privileged', 'discr']
			protected_columns = [c for c in df.columns if c.lower() in candidates]

		if not protected_columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'No protected columns provided or detected'}
			return {"DASHBOARD": '<p>Skipped: no protected columns</p>'}

		sample_col = cols.sample_column
		sample_values = [None]
		if sample_col and sample_col in df.columns:
			sample_values = list(df[sample_col].astype(str).str.lower().unique())

		score_col = cols.score_column or cols.prediction_column
		if score_col is None or score_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'Score/prediction column missing'}
			return {"DASHBOARD": '<p>Skipped: score column missing</p>'}

		target = cols.target_column

		overall_worst = 'green'
		all_details = {}

		for sample in tqdm(sample_values, desc='sample_splits', leave=False):
			if sample is None:
				df_sub = df
				sample_label = 'all'
			else:
				df_sub = df[df[sample_col].astype(str).str.lower() == sample]
				sample_label = sample

			per_feature = {}
			for feat in tqdm(protected_columns, desc='protected_cols', leave=False):
				if feat not in df_sub.columns:
					continue
				levels = df_sub[feat].dropna().unique()
				if len(levels) < 2:
					per_feature[feat] = {'note': 'single level; skipped', 'signal': 'yellow'}
					overall_worst = 'yellow' if overall_worst != 'red' else 'red'
					continue

				details_levels = {}
				for lvl in levels:
					D = df_sub[df_sub[feat] == lvl]
					if D.empty:
						continue
					# choose stat function
					if cfg.task == 'classification':
						# need at least two classes in target
						if D[target].nunique() < 2:
							details_levels[lvl] = {'note': 'single target class in group; skipped', 'signal': 'yellow'}
							continue
						stat_fn = _gini_from_probs
					else:
						stat_fn = _spearman_corr

					y_true = D[target].values
					y_score = D[score_col].values
					# compute bootstrapped CIs
					ci99_l, ci99_u = _bootstrap_ci(stat_fn, y_true, y_score, n_boot=n_boot, alpha=0.99)
					ci95_l, ci95_u = _bootstrap_ci(stat_fn, y_true, y_score, n_boot=n_boot, alpha=0.95)
					width95 = ci95_u - ci95_l if not math.isnan(ci95_u) and not math.isnan(ci95_l) else float('nan')
					if not math.isnan(width95) and width95 > 1.0:
						details_levels[lvl] = {'note': 'insufficient observations (wide CI95)', 'signal': 'yellow', 'ci99': (ci99_l, ci99_u), 'ci95': (ci95_l, ci95_u)}
						overall_worst = 'yellow' if overall_worst != 'red' else 'red'
						continue
					details_levels[lvl] = {'ci99': (ci99_l, ci99_u), 'ci95': (ci95_l, ci95_u)}

				# compare pairwise between level and others combined
				feat_signal = 'green'
				for lvl in levels:
					if lvl not in details_levels or 'ci99' not in details_levels[lvl]:
						continue
					ci99_l, ci99_u = details_levels[lvl]['ci99']
					ci95_l, ci95_u = details_levels[lvl]['ci95']
					other = df_sub[df_sub[feat] != lvl]
					if other.empty:
						continue
					y_t = other[target].values
					y_s = other[score_col].values
					if cfg.task == 'classification' and other[target].nunique() < 2:
						continue
					if cfg.task == 'classification':
						stat_fn = _gini_from_probs
					else:
						stat_fn = _spearman_corr
					o_ci99_l, o_ci99_u = _bootstrap_ci(stat_fn, y_t, y_s, n_boot=n_boot, alpha=0.99)
					o_ci95_l, o_ci95_u = _bootstrap_ci(stat_fn, y_t, y_s, n_boot=n_boot, alpha=0.95)

					# thresholds
					if cfg.task == 'classification':
						thr99 = 0.20
						thr95 = 0.40
					else:
						thr99 = 0.40
						thr95 = 0.55

					# interpret per table 6.24 (assumptions):
					# - red if 99% CIs do not intersect and both left bounds >= thr99
					# - yellow if 95% CIs do not intersect or 99% CIs intersect but left bound >= thr99
					# - green otherwise
					intersects99 = not (ci99_u < o_ci99_l or o_ci99_u < ci99_l)
					intersects95 = not (ci95_u < o_ci95_l or o_ci95_u < ci95_l)

					if (ci99_u >= o_ci99_l and o_ci99_u >= ci99_l) and (ci99_l >= thr99 and o_ci99_l >= thr99):
						sig = 'red'
					elif (not intersects95) or (intersects99 and (ci99_l >= thr99 or o_ci99_l >= thr99)):
						sig = 'yellow'
					else:
						sig = 'green'

					if sig == 'red':
						feat_signal = 'red'
						break
					if sig == 'yellow' and feat_signal != 'red':
						feat_signal = 'yellow'

				per_feature[feat] = {'levels': details_levels, 'signal': feat_signal}
				if feat_signal == 'red':
					overall_worst = 'red'
				elif feat_signal == 'yellow' and overall_worst != 'red':
					overall_worst = 'yellow'

			all_details[sample_label] = per_feature

		self.test_signal = overall_worst
		self.test_meta = {'details': all_details, 'n_boot': n_boot, 'assumptions': 'bootstrap CIs; compare level vs rest; thresholds per table 6.24 (inferred)'}

		# build HTML
		html = f"<h4>M8.2 Ranking stability within protected attributes</h4><p>Signal: <b style='color:{'green' if overall_worst=='green' else ('orange' if overall_worst=='yellow' else 'red')}'>{overall_worst.upper()}</b></p>"
		rows = []
		for s, feats in all_details.items():
			for f, v in feats.items():
				rows.append({'sample': s, 'feature': f, 'signal': v.get('signal', 'unknown')})
		if rows:
			html += pd.DataFrame(rows).to_html(index=False)
		return {"DASHBOARD": html}

