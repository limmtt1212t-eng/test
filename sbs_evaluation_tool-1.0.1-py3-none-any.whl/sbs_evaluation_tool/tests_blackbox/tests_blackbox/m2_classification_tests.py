"""M2 classification-only tests: Gini, per-class Gini, Gini dynamics, and classification metrics.

All user text in English. Classes:
 - M21_GiniOverallTest (M2.1)
 - M22_PerClassGiniTest (M2.2)
 - M23_GiniDynamicsTest (M2.3)
 - M24_ClassificationQualityTest (M2.4)

The implementations rely on available score/probability columns in the dataframe. They will skip if
necessary score information is missing.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import math
from io import BytesIO
import base64
import matplotlib.pyplot as plt

from core.base_test import BaseModelTest
from core.config_validation import validate_config, ConfigValidationError
import sklearn

# sklearn utilities
try:
    from sklearn.metrics import roc_auc_score, f1_score, precision_score, recall_score
    SKLEARN = True
    # Suppress sklearn warnings about single class ROC AUC
    warnings.filterwarnings('ignore', 'Only one class is present in y_true', UserWarning, 'sklearn')
    warnings.filterwarnings('ignore', 'invalid value encountered', RuntimeWarning)
except Exception:
    SKLEARN = False

SKLEARN = True 
import logging
import warnings
from tqdm.auto import tqdm

# module logger
logger = logging.getLogger(__name__)


def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


def _gini_from_probs(y_true: pd.Series, y_score: pd.Series) -> float:
    try:
        # Check if we have at least two classes
        unique_classes = y_true.unique()
        if len(unique_classes) < 2:
            return float('nan')
        
        # Suppress sklearn warnings about single class
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')
            auc = roc_auc_score(y_true, y_score)
            return float(2.0 * auc - 1.0)
    except Exception:
        return float('nan')


def _bootstrap_gini(y_true: pd.Series, y_score: pd.Series, n_boot: int = 200, random_state: int = 42) -> List[float]:
    rng = np.random.RandomState(random_state)
    vals = []
    n = len(y_true)
    if n == 0:
        return vals
    
    # Check if we have at least two classes in the original data
    unique_classes = y_true.unique()
    if len(unique_classes) < 2:
        return vals
        
    for _ in tqdm(range(int(n_boot)), desc='Bootstrap Gini', leave=True):
        idx = rng.randint(0, n, n)
        try:
            y_boot = y_true.iloc[idx].reset_index(drop=True)
            score_boot = y_score.iloc[idx].reset_index(drop=True)
            
            # Check if bootstrap sample has at least two classes
            if len(y_boot.unique()) < 2:
                vals.append(float('nan'))
                continue
                
            vals.append(_gini_from_probs(y_boot, score_boot))
        except Exception:
            vals.append(float('nan'))
    return vals


def _find_score_col_for_class(df: pd.DataFrame, base_score_col: Optional[str], cls) -> Optional[pd.Series]:
    """Try to find a column containing predicted probability for a given class.
    Heuristics: exact base_score_col for binary; base_score_col_{cls}; prob_{cls}; p_{cls}
    """
    if base_score_col and base_score_col in df.columns and df[base_score_col].dtype.kind in 'fiu':
        # binary case
        return df[base_score_col]
    # try variants
    candidates = []
    if base_score_col:
        candidates.extend([f"{base_score_col}_{cls}", f"{base_score_col}{cls}", f"{base_score_col}-{cls}"])
    candidates.extend([f"prob_{cls}", f"p_{cls}", f"score_{cls}"])
    for c in candidates:
        if c in df.columns:
            return df[c]
    return None


class M21_GiniOverallTest(BaseModelTest):
    """M2.1 Overall and weighted Gini (classification only).

    - For multiclass: compute per-class Gini (binary one-vs-rest) and weighted Gini by class counts (or optional weights in config['gini_weights']).
    - For binary: compute single Gini using provided score column.

    Interpretation thresholds (percent):
      - <20% -> RED
      - 20%..40% -> ORANGE
      - >40% -> GREEN

    Special rule: if Gini in [18%,20%) compute bootstrap CI and if 20% lies within CI -> mark YELLOW.
    """
    def __init__(self, n_bootstrap: int = 200):
        super().__init__('M 2.1 (classification only)', 'Gini / Gini-weighted')
        self.n_bootstrap = int(n_bootstrap)

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M2.1 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if getattr(cfg, 'task', None) != 'classification':
            return {"report": "<h4>M2.1 skipped</h4><p>Test applies to classification tasks only.</p>"}
        if not SKLEARN:
            return {"report": "<h4>M2.1 skipped</h4><p>scikit-learn is required for AUC/Gini calculation.</p>"}

        target = cfg.columns.target_column
        score_col = cfg.columns.score_column

        if target not in df.columns:
            return {"report": f"<h4>M2.1 skipped</h4><p>Target column '{target}' missing.</p>"}

        # helper to compute report for a dataframe slice
        def compute_for_df(df_sub):
            classes = sorted(df_sub[target].dropna().unique())
            n_classes = len(classes)
            total_n = len(df_sub)
            class_counts = df_sub[target].value_counts().to_dict()

            per_class_scores = {}
            for cls in tqdm(classes, desc='Locate per-class score cols', leave=False):
                s = _find_score_col_for_class(df_sub, score_col, cls)
                if s is not None:
                    per_class_scores[cls] = s

            # binary
            if n_classes == 2 and score_col and score_col in df_sub.columns:
                y_true = (df_sub[target] == classes[1]).astype(int)
                y_score = df_sub[score_col]
                gini = _gini_from_probs(y_true, y_score)
                ci_lo = ci_hi = None
                if 0.18 <= gini < 0.20:
                    vals = _bootstrap_gini(y_true, y_score, n_boot=self.n_bootstrap)
                    if vals:
                        ci_lo, ci_hi = np.nanpercentile(vals, [2.5, 97.5])
                pct = gini * 100.0 if not math.isnan(gini) else float('nan')
                if math.isnan(pct):
                    return None
                if pct < 20.0:
                    signal = 'red'
                elif pct <= 40.0:
                    signal = 'orange'
                else:
                    signal = 'green'
                if 18.0 <= pct < 20.0 and ci_lo is not None and ci_lo <= 20.0 <= ci_hi:
                    signal = 'orange'
                meta = {'gini': pct, 'ci': (None if ci_lo is None else (float(ci_lo*100), float(ci_hi*100)))}
                html = f"<h4>M2.1 Gini (binary)</h4><p>Gini: <b>{pct:.2f}%</b> — <b style='color:{ 'green' if signal=='green' else ('orange' if signal=='orange' else 'red') }'>{signal.upper()}</b></p>"
                if ci_lo is not None:
                    html += f"<p>95% CI (bootstrap): [{ci_lo*100:.2f}%, {ci_hi*100:.2f}%]</p>"
                return {'html': html, 'meta': meta, 'signal': signal}

            # multiclass
            class_ginis = {}
            for cls in tqdm(classes, desc='Compute per-class Gini', leave=False):
                if cls not in per_class_scores:
                    class_ginis[cls] = float('nan')
                    continue
                y_true = (df_sub[target] == cls).astype(int)
                y_score = per_class_scores[cls]
                g = _gini_from_probs(y_true, y_score)
                class_ginis[cls] = g

            if all(math.isnan(v) for v in class_ginis.values()):
                return None

            weights = None
            if isinstance(config, dict) and config.get('gini_weights'):
                weights = config.get('gini_weights')
            weighted_sum = 0.0
            total_count = 0
            for cls in classes:
                cnt = int(class_counts.get(cls, 0))
                g = class_ginis.get(cls, float('nan'))
                if math.isnan(g):
                    continue
                w = (weights.get(str(cls), 1.0) if weights else 1.0)
                weighted_sum += g * cnt * w
                total_count += cnt * w
            gini_weighted = float(weighted_sum / total_count) if total_count > 0 else float('nan')
            gini_perc = {cls: (float(v) * 100.0 if not math.isnan(v) else float('nan')) for cls, v in class_ginis.items()}
            gini_weighted_perc = gini_weighted * 100.0 if not math.isnan(gini_weighted) else float('nan')
            pct = gini_weighted_perc
            if math.isnan(pct):
                return None
            if pct < 20.0:
                signal = 'red'
            elif pct <= 40.0:
                signal = 'orange'
            else:
                signal = 'green'
            meta = {'per_class_gini_pct': gini_perc, 'gini_weighted_pct': pct}
            df_res = pd.DataFrame([{'class': cls, 'gini_pct': gini_perc.get(cls, float('nan')), 'count': int(class_counts.get(cls, 0))} for cls in classes])
            html = f"<h4>M2.1 Gini-weighted (multiclass)</h4><p>Weighted Gini: <b>{pct:.2f}%</b> — <b style='color:{ 'green' if signal=='green' else ('orange' if signal=='orange' else 'red') }'>{signal.upper()}</b></p>"
            html += df_res.to_html(index=False, float_format='%.2f')
            return {'html': html, 'meta': meta, 'signal': signal}

        # if sample column exists, compute for train and test separately (case-insensitive)
        sample_col = getattr(cfg.columns, 'sample_column', None)
        if sample_col and sample_col in df.columns:
            samples = ['train', 'test']
            html_sections = []
            meta = {}
            overall_signal = 'green'
            for s in samples:
                df_s = df[df[sample_col].astype(str).str.lower() == s]
                if df_s.empty:
                    continue
                res = compute_for_df(df_s)
                if res is None:
                    html_sections.append(f"<h4>{s.capitalize()} - skipped (insufficient data)</h4>")
                    continue
                html_sections.append(f"<h3>{s.capitalize()}</h3>" + res['html'])
                meta[s] = res['meta']
                # worst-case overall signal
                sig = res['signal']
                if sig == 'red':
                    overall_signal = 'red'
                elif sig == 'orange' and overall_signal != 'red':
                    overall_signal = 'orange'
            if not html_sections:
                return {"report": "<h4>M2.1 skipped</h4><p>No train/test samples found with sufficient data.</p>"}
            self.test_signal = overall_signal
            self.test_meta = meta
            return {"DASHBOARD": "".join(html_sections)}

        # fallback: compute for entire df
        res = compute_for_df(df)
        if res is None:
            return {"report": "<h4>M2.1 skipped</h4><p>Insufficient data to compute Gini.</p>"}
        self.test_signal = res['signal']
        self.test_meta = res['meta']
        return {"DASHBOARD": res['html']}


class M22_PerClassGiniTest(BaseModelTest):
    """M2.2 Per-class Gini analysis (classification only)."""
    def __init__(self, n_bootstrap: int = 200):
        super().__init__('M 2.2 (classification only)', 'Per-class Gini')
        self.n_bootstrap = int(n_bootstrap)

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M2.2 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if getattr(cfg, 'task', None) != 'classification':
            return {"report": "<h4>M2.2 skipped</h4><p>Test applies to classification tasks only.</p>"}
        if not SKLEARN:
            return {"report": "<h4>M2.2 skipped</h4><p>scikit-learn is required for AUC/Gini calculation.</p>"}

        target = cfg.columns.target_column
        score_col = cfg.columns.score_column
        if target not in df.columns:
            return {"report": f"<h4>M2.2 skipped</h4><p>Target column '{target}' missing.</p>"}

        classes = sorted(df[target].dropna().unique())
        if len(classes) <= 1:
            return {"report": "<h4>M2.2 skipped</h4><p>Need multiple classes for this test.</p>"}

        # helper to compute per-class gini on a slice
        def compute_for_df(df_sub):
            per_class_scores = {}
            for cls in tqdm(classes, desc='Locate per-class score cols', leave=False):
                s = _find_score_col_for_class(df_sub, score_col, cls)
                if s is not None:
                    per_class_scores[cls] = s
            if not per_class_scores:
                return None
            class_stats = []
            red_classes = []
            total_n = len(df_sub)
            red_obs = 0
            for cls in tqdm(classes, desc='Per-class Gini computation', leave=False):
                if cls not in per_class_scores:
                    class_stats.append({'class': cls, 'gini_pct': float('nan'), 'count': int((df_sub[target]==cls).sum())})
                    continue
                y_true = (df_sub[target] == cls).astype(int)
                y_score = per_class_scores[cls]
                g = _gini_from_probs(y_true, y_score)
                pct = g * 100.0
                n_cls = int((df_sub[target] == cls).sum())
                is_red = pct < 15.0
                if is_red:
                    red_classes.append(cls)
                    red_obs += n_cls
                class_stats.append({'class': cls, 'gini_pct': pct, 'count': n_cls})

            df_stats = pd.DataFrame(class_stats)
            n_classes = len(df_stats)
            n_red = len([r for r in df_stats['gini_pct'] if not math.isnan(r) and r < 15.0])
            frac_red_classes = (n_red / max(1, n_classes))
            frac_red_obs = (red_obs / max(1, total_n))

            if frac_red_classes > 0.20 or frac_red_obs > 0.10:
                signal = 'red'
            else:
                if frac_red_classes <= 0.10 and frac_red_obs <= 0.05:
                    signal = 'green'
                else:
                    signal = 'orange'
            meta = {'per_class': df_stats.to_dict(orient='records'), 'frac_red_classes': frac_red_classes, 'frac_red_obs': frac_red_obs}
            html = f"<h4>M2.2 Per-class Gini</h4><p>Signal: <b style='color:{ 'green' if signal=='green' else ('orange' if signal=='orange' else 'red') }'>{signal.upper()}</b></p>"
            html += df_stats.to_html(index=False, float_format='%.2f')
            return {'html': html, 'meta': meta, 'signal': signal}

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if sample_col and sample_col in df.columns:
            samples = ['train', 'test']
            html_sections = []
            meta = {}
            overall_signal = 'green'
            for s in samples:
                df_s = df[df[sample_col].astype(str).str.lower() == s]
                if df_s.empty:
                    continue
                res = compute_for_df(df_s)
                if res is None:
                    html_sections.append(f"<h4>{s.capitalize()} - skipped (insufficient data)</h4>")
                    continue
                html_sections.append(f"<h3>{s.capitalize()}</h3>" + res['html'])
                meta[s] = res['meta']
                sig = res['signal']
                if sig == 'red':
                    overall_signal = 'red'
                elif sig == 'orange' and overall_signal != 'red':
                    overall_signal = 'orange'
            if not html_sections:
                return {"report": "<h4>M2.2 skipped</h4><p>No train/test samples found with sufficient data.</p>"}
            self.test_signal = overall_signal
            self.test_meta = meta
            return {"DASHBOARD": "".join(html_sections)}

        # fallback single-run
        res = compute_for_df(df)
        if res is None:
            return {"report": "<h4>M2.2 skipped</h4><p>Could not locate per-class score columns for Gini computation.</p>"}
        self.test_signal = res['signal']
        self.test_meta = res['meta']
        return {"DASHBOARD": res['html']}


class M23_GiniDynamicsTest(BaseModelTest):
    """M2.3 Gini dynamics over time (classification only)."""
    def __init__(self, freq: str = 'M', n_bootstrap: int = 200, min_events: int = 50):
        super().__init__('M 2.3 (classification only)', 'Gini Dynamics')
        self.freq = freq
        self.n_bootstrap = int(n_bootstrap)
        self.min_events = int(min_events)

    def run(self, df: pd.DataFrame = None, config: dict = None, sample: str = 'test') -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M2.3 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if getattr(cfg, 'task', None) != 'classification' or not SKLEARN:
            return {"report": "<h4>M2.3 skipped</h4><p>Classification test requires scikit-learn.</p>"}

        date_col = cfg.columns.date_column
        target = cfg.columns.target_column
        score_col = cfg.columns.score_column

        if date_col not in df.columns or target not in df.columns:
            return {"report": "<h4>M2.3 skipped</h4><p>Missing date or target column.</p>"}

        # subset by sample if provided
        if getattr(cfg.columns, 'sample_column', None) and cfg.columns.sample_column in df.columns:
            s = df[cfg.columns.sample_column].astype(str).str.lower()
            if sample:
                df_use = df[s == sample].copy()
            else:
                df_use = df.copy()
        else:
            df_use = df.copy()

        df_use[date_col] = pd.to_datetime(df_use[date_col], errors='coerce')
        df_use = df_use.dropna(subset=[date_col])
        if df_use.empty:
            return {"report": "<h4>M2.3 skipped</h4><p>No rows with valid dates.</p>"}

        # group by periods
        grouped = df_use.groupby(pd.Grouper(key=date_col, freq=self.freq))
        rows = []
        period_ginis = []
        period_counts = []
        period_colors = []
        for period, g in tqdm(grouped, desc='Scan time slices', leave=True):
            if period is pd.NaT:
                continue
            if len(g) < self.min_events:
                # ignore small slices
                continue
            # compute multiclass weighted gini via M21 logic: find per-class score cols
            classes = sorted(g[target].dropna().unique())
            per_class_scores = {}
            for cls in classes:
                s = _find_score_col_for_class(g, score_col, cls)
                if s is not None:
                    per_class_scores[cls] = s
            if not per_class_scores:
                continue
            # compute per-class ginis
            class_counts = g[target].value_counts().to_dict()
            weighted_sum = 0.0
            total_count = 0
            for cls in classes:
                if cls not in per_class_scores:
                    continue
                y_true = (g[target] == cls).astype(int)
                y_score = per_class_scores[cls]
                gi = _gini_from_probs(y_true, y_score)
                weighted_sum += gi * class_counts.get(cls, 0)
                total_count += class_counts.get(cls, 0)
            if total_count == 0:
                continue
            gini = weighted_sum / total_count
            # bootstrap CI
            # build one-vs-rest scores for bootstrap by creating arrays
            # for simplicity compute bootstrap on weighted gini by resampling rows
            vals = []
            rng = np.random.RandomState(42)
            n = len(g)
            for _ in tqdm(range(self.n_bootstrap), desc=f'Bootstrap per-slice ({str(period.date())})', leave=False):
                idx = rng.randint(0, n, n)
                gg = g.iloc[idx]
                class_counts_b = gg[target].value_counts().to_dict()
                weighted_sum_b = 0.0
                total_count_b = 0
                for cls in classes:
                    s_b = _find_score_col_for_class(gg, score_col, cls)
                    if s_b is None:
                        continue
                    y_true_b = (gg[target] == cls).astype(int)
                    gi_b = _gini_from_probs(y_true_b, s_b)
                    weighted_sum_b += gi_b * class_counts_b.get(cls, 0)
                    total_count_b += class_counts_b.get(cls, 0)
                if total_count_b > 0:
                    vals.append(weighted_sum_b / total_count_b)
            if vals:
                lo, hi = np.nanpercentile(vals, [2.5, 97.5])
            else:
                lo = hi = float('nan')

            period_ginis.append(float(gini))
            period_counts.append(int(len(g)))
            # color per slice: red if gini<0.15, yellow if gini<0.35, else green
            pct = float(gini) * 100.0
            if pct < 15.0:
                color = 'red'
            elif pct < 35.0:
                color = 'orange'
            else:
                color = 'green'
            period_colors.append(color)
            rows.append({'period': str(period.date()), 'gini_pct': pct, 'n': int(len(g)), 'ci_lo_pct': (lo*100.0 if not math.isnan(lo) else None), 'ci_hi_pct': (hi*100.0 if not math.isnan(hi) else None), 'color': color})

        if not rows:
            return {"report": "<h4>M2.3 skipped</h4><p>No valid time slices with sufficient events and score columns.</p>"}

        df_periods = pd.DataFrame(rows)
        # compute aggregate conditions
        n_slices = len(df_periods)
        n_red = (df_periods['color'] == 'red').sum()
        red_slice_frac = n_red / n_slices
        red_obs_share = df_periods.loc[df_periods['color'] == 'red', 'n'].sum() / df_periods['n'].sum()
        n_yellow = (df_periods['color'] == 'orange').sum()
        yellow_slice_frac = n_yellow / n_slices
        yellow_obs_share = df_periods.loc[df_periods['color'] == 'orange', 'n'].sum() / df_periods['n'].sum()

        # Apply rules from specification
        if red_slice_frac > 0.30 or red_obs_share > 0.30:
            signal = 'red'
        else:
            if yellow_slice_frac < 0.30 and yellow_obs_share < 0.30:
                signal = 'green'
            else:
                signal = 'orange'

        self.test_signal = signal
        self.test_meta = {'periods': df_periods.to_dict(orient='records'), 'signal_summary': {'red_slice_frac': red_slice_frac, 'red_obs_share': red_obs_share}}

        # Enhanced plot like in the image
        fig, ax1 = plt.subplots(figsize=(14, 8))
        
        # Data preparation
        periods = range(len(df_periods))
        gini_values = df_periods['gini_pct'].values
        observations = df_periods['n'].values
        ci_lower = df_periods['ci_lo_pct'].fillna(df_periods['gini_pct']).values
        ci_upper = df_periods['ci_hi_pct'].fillna(df_periods['gini_pct']).values
        
        # Create dual y-axis
        ax2 = ax1.twinx()
        
        # Background zones (Red and Yellow thresholds)
        ax1.axhspan(0, 15, alpha=0.15, color='red', label='Red zone threshold')
        ax1.axhspan(15, 35, alpha=0.15, color='orange', label='Yellow zone threshold') 
        ax1.axhspan(35, 100, alpha=0.1, color='lightgreen')
        
        # Horizontal threshold lines
        ax1.axhline(y=15, color='red', linestyle='--', linewidth=1.5, alpha=0.8)
        ax1.axhline(y=35, color='orange', linestyle='--', linewidth=1.5, alpha=0.8)
        
        # Plot observations as area chart (left axis)
        ax2.fill_between(periods, observations, alpha=0.3, color='lightblue', label='Observations number')
        ax2.plot(periods, observations, color='lightblue', linewidth=1, alpha=0.7)
        
        # Plot confidence intervals as area
        ax1.fill_between(periods, ci_lower, ci_upper, alpha=0.2, color='gold', label='Upper CI 95%')
        ax1.plot(periods, ci_upper, color='orange', linewidth=1, linestyle='-', alpha=0.8, label='Lower CI 95%')
        ax1.plot(periods, ci_lower, color='orange', linewidth=1, linestyle='-', alpha=0.8)
        
        # Plot main Gini line with points
        ax1.plot(periods, gini_values, color='navy', linewidth=3, marker='o', markersize=6, 
                markerfacecolor='navy', markeredgecolor='white', markeredgewidth=1, label='Gini')
        
        # Add Gini values as text labels on points
        for i, (period, gini_val) in enumerate(zip(periods, gini_values)):
            ax1.annotate(f'{gini_val:.2f}', (period, gini_val), 
                        textcoords="offset points", xytext=(0,10), ha='center', 
                        fontsize=9, fontweight='bold', color='navy')
        
        # Styling for left axis (Gini)
        ax1.set_xlabel('Time range slice', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Gini', fontsize=12, fontweight='bold', color='navy')
        ax1.tick_params(axis='y', labelcolor='navy')
        ax1.set_ylim(0, max(75, max(gini_values) * 1.1))
        
        # Styling for right axis (Observations)
        ax2.set_ylabel('Observations number', fontsize=12, fontweight='bold', color='lightblue')
        ax2.tick_params(axis='y', labelcolor='lightblue')
        ax2.set_ylim(0, max(observations) * 1.1)
        
        # X-axis formatting
        ax1.set_xticks(periods)
        ax1.set_xticklabels([p.replace('2016-', '').replace('-01', '') for p in df_periods['period']], 
                           rotation=45, ha='right')
        
        # Grid
        ax1.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
        
        # Title
        ax1.set_title('Gini in dynamics', fontsize=16, fontweight='bold', pad=20)
        
        # Legends
        # Create custom legend combining both axes
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        
        # Reorder legend items to match image
        legend_order = ['Observations number', 'Gini', 'Yellow zone threshold', 'Red zone threshold', 'Lower CI 95%', 'Upper CI 95%']
        legend_handles = []
        legend_labels = []
        
        all_lines = lines1 + lines2
        all_labels = labels1 + labels2
        
        for desired_label in legend_order:
            for line, label in zip(all_lines, all_labels):
                if label == desired_label:
                    legend_handles.append(line)
                    legend_labels.append(label)
                    break
        
        ax1.legend(legend_handles, legend_labels, loc='upper left', bbox_to_anchor=(0, 1), 
                  frameon=True, fancybox=True, shadow=True, fontsize=10)
        
        # Tight layout
        plt.tight_layout()
        plot_b64 = _to_base64(fig)

        html = f"<h4>M2.3 Gini Dynamics</h4><p>Signal: <b style='color:{ 'green' if signal=='green' else ('orange' if signal=='orange' else 'red') }'>{signal.upper()}</b></p>"
        html += f"<img src=\"data:image/png;base64,{plot_b64}\" />"
        html += df_periods.to_html(index=False, float_format='%.2f')
        return {"DASHBOARD": html}


class M24_ClassificationQualityTest(BaseModelTest):
    """M2.4 Classification quality: F1/Precision/Recall per class and aggregated.

    Thresholds (percent):
      - F1: <40% red, 40-60% orange, >60% green
      - Precision: <40% red, 40-60% orange, >60% green
      - Recall: <15% red, 15-30% orange, >30% green

    For multiclass, compute per-class metrics and micro/macro aggregates. The final signal is the worst among considered metrics.
    """
    def __init__(self):
        super().__init__('M 2.4 (classification only)', 'Classification quality (F1/Precision/Recall)')

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M2.4 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if getattr(cfg, 'task', None) != 'classification':
            return {"report": "<h4>M2.4 skipped</h4><p>Test applies to classification tasks only.</p>"}
        if not SKLEARN:
            return {"report": "<h4>M2.4 skipped</h4><p>scikit-learn is required for metric calculation.</p>"}

        target = cfg.columns.target_column
        pred_col = cfg.columns.prediction_column
        if target not in df.columns:
            return {"report": f"<h4>M2.4 skipped</h4><p>Target column '{target}' missing.</p>"}
        if pred_col not in df.columns:
            return {"report": f"<h4>M2.4 skipped</h4><p>Prediction column '{pred_col}' missing (required for per-class metrics).</p>"}

        classes = sorted(df[target].dropna().unique())

        def compute_for_df(df_sub):
            y_true = df_sub[target]
            y_pred = df_sub[pred_col]
            rows = []
            worst_signal = 'green'
            for cls in classes:
                y_true_bin = (y_true == cls).astype(int)
                y_pred_bin = (y_pred == cls).astype(int)
                try:
                    f1 = f1_score(y_true_bin, y_pred_bin, zero_division=0)
                    prec = precision_score(y_true_bin, y_pred_bin, zero_division=0)
                    rec = recall_score(y_true_bin, y_pred_bin, zero_division=0)
                except Exception:
                    f1 = prec = rec = float('nan')
                f1_p = f1 * 100.0 if not math.isnan(f1) else float('nan')
                prec_p = prec * 100.0 if not math.isnan(prec) else float('nan')
                rec_p = rec * 100.0 if not math.isnan(rec) else float('nan')

                def metric_signal(val, bounds):
                    if math.isnan(val):
                        return 'red'
                    lo, hi = bounds
                    if val < lo:
                        return 'red'
                    if val < hi:
                        return 'orange'
                    return 'green'

                f1_sig = metric_signal(f1_p, (40.0, 60.0))
                prec_sig = metric_signal(prec_p, (40.0, 60.0))
                rec_sig = metric_signal(rec_p, (15.0, 30.0))

                class_worst = 'green'
                if 'red' in (f1_sig, prec_sig, rec_sig):
                    class_worst = 'red'
                elif 'orange' in (f1_sig, prec_sig, rec_sig):
                    class_worst = 'orange'

                if class_worst == 'red':
                    worst_signal = 'red'
                elif class_worst == 'orange' and worst_signal != 'red':
                    worst_signal = 'orange'

                rows.append({'class': cls, 'f1_pct': f1_p, 'precision_pct': prec_p, 'recall_pct': rec_p, 'class_signal': class_worst})

            try:
                f1_macro = f1_score(y_true, y_pred, average='macro', zero_division=0) * 100.0
                f1_micro = f1_score(y_true, y_pred, average='micro', zero_division=0) * 100.0
            except Exception:
                f1_macro = f1_micro = float('nan')

            meta = {'per_class': rows, 'f1_macro': f1_macro, 'f1_micro': f1_micro}
            df_rows = pd.DataFrame(rows)
            html = f"<h4>M2.4 Classification quality</h4><p>Signal: <b style='color:{ 'green' if worst_signal=='green' else ('orange' if worst_signal=='orange' else 'red') }'>{worst_signal.upper()}</b></p>"
            html += f"<p>Macro F1: <b>{(f1_macro if not math.isnan(f1_macro) else 'n/a'):.2f}</b>; Micro F1: <b>{(f1_micro if not math.isnan(f1_micro) else 'n/a'):.2f}</b></p>"
            html += df_rows.to_html(index=False, float_format='%.2f')
            return {'html': html, 'meta': meta, 'signal': worst_signal}

        sample_col = getattr(cfg.columns, 'sample_column', None)
        if sample_col and sample_col in df.columns:
            samples = ['train', 'test']
            html_sections = []
            meta = {}
            overall_signal = 'green'
            for s in samples:
                df_s = df[df[sample_col].astype(str).str.lower() == s]
                if df_s.empty:
                    continue
                res = compute_for_df(df_s)
                if res is None:
                    html_sections.append(f"<h4>{s.capitalize()} - skipped (insufficient data)</h4>")
                    continue
                html_sections.append(f"<h3>{s.capitalize()}</h3>" + res['html'])
                meta[s] = res['meta']
                sig = res['signal']
                if sig == 'red':
                    overall_signal = 'red'
                elif sig == 'orange' and overall_signal != 'red':
                    overall_signal = 'orange'
            if not html_sections:
                return {"report": "<h4>M2.4 skipped</h4><p>No train/test samples found with sufficient data.</p>"}
            self.test_signal = overall_signal
            self.test_meta = meta
            return {"DASHBOARD": "".join(html_sections)}

        res = compute_for_df(df)
        self.test_signal = res['signal']
        self.test_meta = res['meta']
        return {"DASHBOARD": res['html']}
