import logging
import math
import warnings
from typing import Dict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
from sklearn.metrics import roc_auc_score, r2_score, mean_squared_error, mean_absolute_error, precision_recall_curve, auc

# Suppress sklearn warnings about single class ROC AUC
warnings.filterwarnings('ignore', 'Only one class is present in y_true', UserWarning, 'sklearn')
warnings.filterwarnings('ignore', 'invalid value encountered', RuntimeWarning)

from core.base_test import BaseModelTest
from core.styles import COLORS, STATUS_COLORS
from core.config_validation import validate_config

logger = logging.getLogger(__name__)


def _to_base64(fig):
	import io, base64
	buf = io.BytesIO()
	fig.savefig(buf, format='png', bbox_inches='tight')
	buf.seek(0)
	img = base64.b64encode(buf.read()).decode('utf-8')
	plt.close(fig)
	return img


class M61_StabilityKeyMetricTest(BaseModelTest):
	"""M6.1. Stability of key metric (classification only)"""

	def __init__(self):
		super().__init__('M6.1', 'Stability of key metric (classification)')

	def run(self, df: pd.DataFrame, config: dict, **kwargs) -> Dict[str, str]:
		cfg = validate_config(config, df)
		cols = cfg.columns
		# only for classification
		if cfg.task != 'classification':
			self.test_signal = 'green'
			self.test_meta = {'note': 'M6.1 applicable only for classification'}
			return {"DASHBOARD": '<p>Skipped: classification-only test</p>'}

		# expect sample_column with values like 'train','oos','oot' (case-insensitive)
		sample_col = cols.sample_column
		if sample_col is None or sample_col not in df.columns:
			# fallback: assume single dataset -> cannot compare
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'No sample column; cannot compute stability comparisons'}
			return {"DASHBOARD": '<p>Skipped: sample column missing</p>'}

		score_col = cols.score_column or cols.prediction_column
		if score_col is None or score_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'Score/prediction column missing'}
			return {"DASHBOARD": '<p>Skipped: score column missing</p>'}

		target = cols.target_column
		# Normalize sample labels: map any label equal to 'train' (case-insensitive) to 'TRAIN',
		# everything else becomes 'TEST' (this collapses OOS/OOT variants into a single TEST split)
		norm_series = df[sample_col].astype(str).str.lower().apply(lambda x: 'TRAIN' if x == 'train' else 'TEST')
		parts = {k: g for k, g in df.assign(_sample_norm=norm_series).groupby('_sample_norm')}

		train_df = parts.get('TRAIN')
		test_df = parts.get('TEST')

		# compute gini (2*AUC-1) per dataset; for multiclass compute weighted gini
		def _gini_from_probs(y_true, y_score):
			try:
				if y_score.ndim == 1:
					# Check if we have at least two classes
					unique_classes = np.unique(y_true)
					if len(unique_classes) < 2:
						return float('nan')
					
					# Suppress sklearn warnings about single class
					with warnings.catch_warnings():
						warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')
						aucv = roc_auc_score(y_true, y_score)
						return 2.0 * aucv - 1.0
				# multiclass: compute weighted gini per class
				from sklearn.preprocessing import label_binarize
				classes = np.unique(y_true)
				yb = label_binarize(y_true, classes=classes)
				gini_sum = 0.0
				weights = yb.sum(axis=0) / float(len(y_true))
				for i, c in enumerate(classes):
					try:
						# Suppress sklearn warnings for each class
						with warnings.catch_warnings():
							warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')
							aucv = roc_auc_score(yb[:, i], y_score[:, i])
							gini_sum += weights[i] * (2 * aucv - 1)
					except Exception:
						continue
				return gini_sum
			except Exception:
				return float('nan')

		results = {}
		for name, d in [('TRAIN', train_df), ('TEST', test_df)]:
			if d is None or d.empty:
				results[name] = float('nan')
				continue
			if '.' in score_col:
				# nested column not expected, simple access
				sc = score_col
			sc_vals = d[score_col]
			y = d[target]
			# try to handle multiclass probability columns (matrix-like stored as list/ndarray)
			try:
				if isinstance(sc_vals.iloc[0], (list, np.ndarray)):
					arr = np.stack(sc_vals.values)
					g = _gini_from_probs(y.values, arr)
				else:
					g = _gini_from_probs(y.values, sc_vals.values)
			except Exception:
				try:
					g = _gini_from_probs(y.values, sc_vals.values)
				except Exception:
					g = float('nan')
			results[name] = g

		# comparisons: with normalized splits we compare TRAIN vs TEST when both available
		pairs = []
		if train_df is not None and test_df is not None:
			pairs.append(('TRAIN', 'TEST'))

		# if no pairings, mark yellow
		if not pairs:
			self.test_signal = 'yellow'
			self.test_meta = {'results': results, 'note': 'Not enough sample splits for comparisons'}
			return {"DASHBOARD": '<p>Not enough splits to compare</p>'}

		worst_signal = 'green'
		details = []
		for a, b in pairs:
			ga = results.get(a, float('nan'))
			gb = results.get(b, float('nan'))
			if math.isnan(ga) or math.isnan(gb):
				sig = 'yellow'
			else:
				abs_drop = (ga - gb) * 100.0  # in percentage points
				rel_drop = (ga - gb) / (abs(ga) if abs(ga) > 1e-12 else 1.0)
				# interpret per table heuristics (primary validation thresholds)
				# Use a simplified decision ruleset mapping the table rows to signal
				if abs_drop > 15 and rel_drop > 0.25:
					sig = 'red'
				elif abs_drop > 5 and rel_drop > 0.15:
					sig = 'yellow'
				else:
					sig = 'green'
			details.append({'pair': f'{a} vs {b}', 'g_a': ga, 'g_b': gb, 'signal': sig})
			if sig == 'red':
				worst_signal = 'red'
			elif sig == 'yellow' and worst_signal != 'red':
				worst_signal = 'yellow'

		# adjust special rules from description
		# if OOT (or OOS if OOT absent) gini > 0.65 and overall red -> downgrade to yellow
		# primary_check: prefer TEST split (which now contains OOT/OOS variants)
		primary_check = results.get('TEST')
		if worst_signal == 'red' and primary_check is not None and not math.isnan(primary_check) and primary_check >= 0.65:
			worst_signal = 'yellow'

		self.test_signal = worst_signal
		self.test_meta = {'results': results, 'comparisons': details}

		# build simple dashboard
		html = f"<h4>M6.1 Stability of key metric</h4><p>Signal: <b style='color:{'green' if worst_signal=='green' else ('orange' if worst_signal=='yellow' else 'red')}'>{worst_signal.upper()}</b></p>"
		df_res = pd.DataFrame([{'split': k, 'gini': v} for k, v in results.items()])
		html += df_res.to_html(index=False, float_format='%.4f')
		return {"DASHBOARD": html}


class M62_StabilityRegressionTest(BaseModelTest):
	"""M6.2. Stability of regression quality (regression only)"""

	def __init__(self):
		super().__init__('M6.2', 'Stability of regression quality (regression)')

	def run(self, df: pd.DataFrame, config: dict, metric: str = 'rmse', **kwargs) -> Dict[str, str]:
		cfg = validate_config(config, df)
		cols = cfg.columns
		if cfg.task != 'regression':
			self.test_signal = 'green'
			self.test_meta = {'note': 'M6.2 applicable only for regression'}
			return {"DASHBOARD": '<p>Skipped: regression-only test</p>'}

		sample_col = cols.sample_column
		if sample_col is None or sample_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'No sample column; cannot compute stability comparisons'}
			return {"DASHBOARD": '<p>Skipped: sample column missing</p>'}

		target = cols.target_column
		# Normalize to TRAIN / TEST
		norm_series = df[sample_col].astype(str).str.lower().apply(lambda x: 'TRAIN' if x == 'train' else 'TEST')
		parts = {k: g for k, g in df.assign(_sample_norm=norm_series).groupby('_sample_norm')}
		train_df = parts.get('TRAIN')
		test_df = parts.get('TEST')

		def _metric_val(y_true, y_pred):
			try:
				if metric.lower() in ('rmse', 'mse'):
					mse = mean_squared_error(y_true, y_pred)
					return math.sqrt(mse) if metric.lower() == 'rmse' else mse
				if metric.lower() == 'mae':
					return mean_absolute_error(y_true, y_pred)
				if metric.lower() == 'r2':
					return r2_score(y_true, y_pred)
			except Exception:
				return float('nan')

		results = {}
		# For regression we expect predictions stored in score/prediction column
		score_col = cols.score_column or cols.prediction_column
		if score_col is None or score_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'Score/prediction column missing'}
			return {"DASHBOARD": '<p>Skipped: score column missing</p>'}

		for name, d in [('TRAIN', train_df), ('TEST', test_df)]:
			if d is None or d.empty:
				results[name] = float('nan')
				continue
			try:
				y_true = d[target].values
				y_pred = d[score_col].values
				results[name] = _metric_val(y_true, y_pred)
			except Exception:
				results[name] = float('nan')

		# comparisons similar to M6.1 but only check relative drops (table 6.18)
		pairs = []
		if train_df is not None and test_df is not None:
			pairs.append(('TRAIN', 'TEST'))

		if not pairs:
			self.test_signal = 'yellow'
			self.test_meta = {'results': results, 'note': 'Not enough sample splits for comparisons'}
			return {"DASHBOARD": '<p>Not enough splits to compare</p>'}

		worst = 'green'
		details = []
		for a, b in pairs:
			va = results.get(a, float('nan'))
			vb = results.get(b, float('nan'))
			if math.isnan(va) or math.isnan(vb):
				sig = 'yellow'
			else:
				# for regression metrics lower-is-better (rmse, mae); r2 higher-is-better
				if metric.lower() in ('r2',):
					rel_drop = (va - vb) / (abs(va) if abs(va) > 1e-12 else 1.0)
				else:
					# relative increase in error
					rel_drop = (vb - va) / (abs(va) if abs(va) > 1e-12 else 1.0)

				if rel_drop > 0.30:
					sig = 'red'
				elif rel_drop > 0.15:
					sig = 'yellow'
				else:
					sig = 'green'
			details.append({'pair': f'{a} vs {b}', 'v_a': va, 'v_b': vb, 'signal': sig})
			if sig == 'red':
				worst = 'red'
			elif sig == 'yellow' and worst != 'red':
				worst = 'yellow'

		self.test_signal = worst
		self.test_meta = {'results': results, 'comparisons': details}

		html = f"<h4>M6.2 Stability of regression quality ({metric.upper()})</h4><p>Signal: <b style='color:{'green' if worst=='green' else ('orange' if worst=='yellow' else 'red')}'>{worst.upper()}</b></p>"
		df_res = pd.DataFrame([{'split': k, 'value': v} for k, v in results.items()])
		html += df_res.to_html(index=False, float_format='%.4f')
		return {"DASHBOARD": html}


class M63_PRStabilityTest(BaseModelTest):
	"""M6.3. Stability of Precision-Recall AUC (binary classification)"""

	def __init__(self):
		super().__init__('M6.3', 'Stability of PR-AUC (binary classification)')

	def run(self, df: pd.DataFrame, config: dict, **kwargs) -> Dict[str, str]:
		cfg = validate_config(config, df)
		cols = cfg.columns
		if cfg.task != 'classification':
			self.test_signal = 'green'
			self.test_meta = {'note': 'M6.3 applicable only for classification'}
			return {"DASHBOARD": '<p>Skipped: classification-only test</p>'}

		sample_col = cols.sample_column
		if sample_col is None or sample_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'No sample column; cannot compute stability comparisons'}
			return {"DASHBOARD": '<p>Skipped: sample column missing</p>'}

		score_col = cols.score_column or cols.prediction_column
		if score_col is None or score_col not in df.columns:
			self.test_signal = 'yellow'
			self.test_meta = {'note': 'Score/prediction column missing'}
			return {"DASHBOARD": '<p>Skipped: score column missing</p>'}

		target = cols.target_column
		# Normalize sample labels to TRAIN/TEST
		norm_series = df[sample_col].astype(str).str.lower().apply(lambda x: 'TRAIN' if x == 'train' else 'TEST')
		parts = {k: g for k, g in df.assign(_sample_norm=norm_series).groupby('_sample_norm')}
		train_df = parts.get('TRAIN')
		test_df = parts.get('TEST')

		def _pr_auc(d):
			if d is None or d.empty:
				return float('nan')
			try:
				y_true = d[target].values
				y_score = d[score_col].values
				# in case probabilities per class are stored as arrays, pick positive class
				if isinstance(y_score[0], (list, np.ndarray)):
					if y_score[0].ndim == 1 and len(y_score[0]) >= 2:
						y_score = np.array([s[1] for s in y_score])
					else:
						y_score = np.array(y_score)
				precision, recall, _ = precision_recall_curve(y_true, y_score)
				return auc(recall, precision)
			except Exception:
				return float('nan')

		res = {'TRAIN': _pr_auc(train_df), 'TEST': _pr_auc(test_df)}

		# comparisons and interpretation per Table 6.19 — compare TRAIN vs TEST
		pairs = []
		if train_df is not None and test_df is not None:
			pairs.append(('TRAIN', 'TEST'))

		if not pairs:
			self.test_signal = 'yellow'
			self.test_meta = {'results': res, 'note': 'Not enough sample splits for comparisons'}
			return {"DASHBOARD": '<p>Not enough splits to compare</p>'}

		worst = 'green'
		details = []
		for a, b in pairs:
			va = res.get(a, float('nan'))
			vb = res.get(b, float('nan'))
			if math.isnan(va) or math.isnan(vb):
				sig = 'yellow'
			else:
				abs_drop = (va - vb)
				rel_drop = (va - vb) / (abs(va) if abs(va) > 1e-12 else 1.0)
				# thresholds from table 6.19
				if abs_drop > 0.10 and rel_drop > 0.20:
					sig = 'red'
				elif abs_drop > 0.05 and rel_drop > 0.15:
					sig = 'yellow'
				else:
					sig = 'green'
			details.append({'pair': f'{a} vs {b}', 'v_a': va, 'v_b': vb, 'signal': sig})
			if sig == 'red':
				worst = 'red'
			elif sig == 'yellow' and worst != 'red':
				worst = 'yellow'

		self.test_signal = worst
		self.test_meta = {'results': res, 'comparisons': details}

		# Enhanced PR curves plot matching the professional style
		fig, ax = plt.subplots(1, 1, figsize=(10, 6))
		
		# Set background color
		ax.set_facecolor('#f8f9fa')
		fig.patch.set_facecolor('white')
		
		# Color scheme for different datasets
		colors = {'TRAIN': '#1f77b4', 'TEST': '#d62728'}  # Blue for train, Red for test
		linewidths = {'TRAIN': 2.5, 'TEST': 2.5}
		
		# First pass: calculate F1 scores and collect curve data for auto-scaling
		dataset_f1_scores = []
		all_precision_values = []
		all_recall_values = []
		curve_data = []
		
		# Plot curves for each dataset
		for name, d in [('TRAIN', train_df), ('TEST', test_df)]:
			if d is None or d.empty:
				continue
			try:
				y_true = d[target].values
				y_score = d[score_col].values
				if isinstance(y_score[0], (list, np.ndarray)):
					if y_score[0].ndim == 1 and len(y_score[0]) >= 2:
						y_score = np.array([s[1] for s in y_score])
					else:
						y_score = np.array(y_score)
				
				precision, recall, thresholds = precision_recall_curve(y_true, y_score)
				pr_auc = res.get(name, float("nan"))
				
				# Store curve data for plotting
				curve_data.append((name, precision, recall, pr_auc))
				
				# Collect values for auto-scaling
				all_precision_values.extend(precision)
				all_recall_values.extend(recall)
				
				# Calculate F1-score at optimal threshold for this dataset
				f1_scores_curve = 2 * (precision * recall) / (precision + recall + 1e-8)
				max_f1 = np.nanmax(f1_scores_curve)
				if not np.isnan(max_f1):
					dataset_f1_scores.append(max_f1)
				
			except Exception as e:
				logger.warning(f"Failed to process PR curve for {name}: {e}")
				continue
		
		# Auto-scaling logic based on meaningful curve variations
		if all_precision_values and all_recall_values:
			# Find the range where curves actually change significantly
			meaningful_precision_values = []
			meaningful_recall_values = []
			
			for name, precision, recall, pr_auc in curve_data:
				# Calculate the variation (gradient) in precision values
				if len(precision) > 1:
					precision_diff = np.abs(np.diff(precision))
					recall_diff = np.abs(np.diff(recall))
					
					# Find segments where precision changes by more than 1% (0.01)
					significant_precision_changes = precision_diff > 0.01
					significant_recall_changes = recall_diff > 0.01
					
					# Combine conditions - look for areas with meaningful changes
					significant_changes = significant_precision_changes | significant_recall_changes
					
					if np.any(significant_changes):
						# Get indices of significant changes (add 1 to include the end points)
						change_indices = np.where(significant_changes)[0]
						start_idx = max(0, change_indices[0] - 1)
						end_idx = min(len(precision) - 1, change_indices[-1] + 2)
						
						meaningful_precision_values.extend(precision[start_idx:end_idx])
						meaningful_recall_values.extend(recall[start_idx:end_idx])
					else:
						# If no significant changes, use a smaller central portion
						n_points = len(precision)
						start_idx = max(0, n_points // 4)
						end_idx = min(n_points, 3 * n_points // 4)
						meaningful_precision_values.extend(precision[start_idx:end_idx])
						meaningful_recall_values.extend(recall[start_idx:end_idx])
			
			# If we found meaningful variations, use those for scaling
			if meaningful_precision_values and meaningful_recall_values:
				min_precision = np.min(meaningful_precision_values)
				max_precision = np.max(meaningful_precision_values)
				min_recall = np.min(meaningful_recall_values)
				max_recall = np.max(meaningful_recall_values)
				
				# Calculate range
				precision_range = max_precision - min_precision
				recall_range = max_recall - min_recall
				
				# Add moderate padding (5% of range, but at least 0.02)
				precision_padding = max(0.02, precision_range * 0.05)
				recall_padding = max(0.02, recall_range * 0.05)
				
				# Calculate bounds
				precision_min = max(0.0, min_precision - precision_padding)
				precision_max = min(1.0, max_precision + precision_padding)
				recall_min = max(0.0, min_recall - recall_padding)
				recall_max = min(1.0, max_recall + recall_padding)
				
				# Ensure minimum meaningful range (at least 0.1 span for detailed view)
				if precision_max - precision_min < 0.1:
					center_p = (precision_max + precision_min) / 2
					precision_min = max(0.0, center_p - 0.05)
					precision_max = min(1.0, center_p + 0.05)
				
				if recall_max - recall_min < 0.1:
					center_r = (recall_max + recall_min) / 2
					recall_min = max(0.0, center_r - 0.05)
					recall_max = min(1.0, center_r + 0.05)
			else:
				# Fallback: use all values but with tighter bounds
				min_precision = np.min(all_precision_values)
				max_precision = np.max(all_precision_values)
				min_recall = np.min(all_recall_values)
				max_recall = np.max(all_recall_values)
				
				precision_range = max_precision - min_precision
				recall_range = max_recall - min_recall
				
				# Very small padding for fallback
				precision_padding = max(0.01, precision_range * 0.02)
				recall_padding = max(0.01, recall_range * 0.02)
				
				precision_min = max(0.0, min_precision - precision_padding)
				precision_max = min(1.0, max_precision + precision_padding)
				recall_min = max(0.0, min_recall - recall_padding)
				recall_max = min(1.0, max_recall + recall_padding)
		else:
			# Fallback to full range if no data
			precision_min, precision_max = 0.0, 1.0
			recall_min, recall_max = 0.0, 1.0
		
		# Plot the curves with collected data
		for name, precision, recall, pr_auc in curve_data:
			# Map dataset names to proper labels
			if name == 'TRAIN':
				label = f'out-of-sample average precision: {pr_auc:.2f}'
			else:
				label = f'out-of-time average precision: {pr_auc:.2f}'
			
			# Plot the PR curve
			ax.plot(recall, precision, color=colors.get(name, COLORS['GRAY']), 
			       linewidth=linewidths.get(name, 2), label=label, alpha=0.9)
		
		# Determine F1-score isolines based on actual dataset performance
		if dataset_f1_scores:
			# Use the mean F1-score as center and create range around it
			center_f1 = np.mean(dataset_f1_scores)
			
			# Adjust range based on the scale of the plot
			plot_area = (precision_max - precision_min) * (recall_max - recall_min)
			if plot_area < 0.25:  # Small plot area, use tighter F1 range
				f1_range = 0.15
				f1_step = f1_range / 4  # 5 isolines
				n_isolines = 5
			else:  # Larger plot area, use wider F1 range
				f1_range = 0.3
				f1_step = f1_range / 6  # 7 isolines
				n_isolines = 7
			
			f1_isolines = []
			half_n = n_isolines // 2
			for i in range(-half_n, half_n + 1):
				f1_val = center_f1 + i * f1_step
				if 0.05 <= f1_val <= 0.98:  # Only valid F1 scores
					f1_isolines.append(f1_val)
		else:
			# Fallback to default range if no F1 could be calculated
			f1_isolines = [0.2, 0.4, 0.5, 0.6, 0.7, 0.8]
		
		# Add F1-score isolines (gray curved lines) within the visible area
		for f1 in f1_isolines:
			# Generate points within the visible recall range
			x = np.linspace(max(0.01, recall_min), recall_max, 100)
			y = f1 * x / (2 * x - f1)
			# Only plot valid parts within the visible area
			valid_mask = (y > 0) & (y <= 1) & (x > 0) & (2 * x - f1 > 0) & \
			            (x >= recall_min) & (x <= recall_max) & \
			            (y >= precision_min) & (y <= precision_max)
			
			if np.any(valid_mask):
				ax.plot(x[valid_mask], y[valid_mask], color=COLORS['GRAY'], 
				       linestyle='--', alpha=0.6, linewidth=1)
				
				# Add F1-score labels at appropriate positions
				valid_x = x[valid_mask]
				valid_y = y[valid_mask]
				if len(valid_x) > 10:
					# Choose position around 70% of the visible curve for label placement
					label_idx = int(len(valid_x) * 0.7)
					label_x = valid_x[label_idx]
					label_y = valid_y[label_idx]
					
					# Only place label if it's well within the visible area
					x_margin = (recall_max - recall_min) * 0.1
					y_margin = (precision_max - precision_min) * 0.1
					if (recall_min + x_margin) < label_x < (recall_max - x_margin) and \
					   (precision_min + y_margin) < label_y < (precision_max - y_margin):
						ax.annotate(f'F1={f1:.2f}', (label_x, label_y), 
								   xytext=(5, 5), textcoords='offset points',
								   fontsize=8, color=COLORS['GRAY'], alpha=0.8,
								   bbox=dict(boxstyle='round,pad=0.2', facecolor='white', 
								            alpha=0.7, edgecolor='none'))
		
		# Apply auto-scaling
		ax.set_xlim(recall_min, recall_max)
		ax.set_ylim(precision_min, precision_max)
		ax.set_xlabel('Recall', fontsize=12, fontweight='bold')
		ax.set_ylabel('Precision', fontsize=12, fontweight='bold')
		ax.set_title('Validation Precision-Recall curve', fontsize=14, fontweight='bold', pad=20)
		
		# Grid
		ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
		ax.set_axisbelow(True)
		
		# Legend
		ax.legend(loc='lower left', frameon=True, fancybox=True, shadow=True, 
				 fontsize=10, framealpha=0.9)
		
		# Add scaling info to the plot
		if all_precision_values and all_recall_values:
			# Determine the scaling method used
			scaling_method = "Dynamic scaling\n(focus on curve variations)" if 'meaningful_precision_values' in locals() and meaningful_precision_values else "Standard scaling"
			ax.text(0.02, 0.98, f'{scaling_method}\nRecall: [{recall_min:.3f}, {recall_max:.3f}]\nPrecision: [{precision_min:.3f}, {precision_max:.3f}]', 
		       transform=ax.transAxes, fontsize=8, verticalalignment='top',
		       bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.7))
		
		# Tight layout
		plt.tight_layout()
		img = _to_base64(fig)

		html = f"<h4>M6.3 PR AUC stability</h4><p>Signal: <b style='color:{'green' if worst=='green' else ('orange' if worst=='yellow' else 'red')}'>{worst.upper()}</b></p>"
		html += f"<img src=\"data:image/png;base64,{img}\" />"
		html += pd.DataFrame([{'split': k, 'pr_auc': v} for k, v in res.items()]).to_html(index=False, float_format='%.4f')
		return {"DASHBOARD": html}

