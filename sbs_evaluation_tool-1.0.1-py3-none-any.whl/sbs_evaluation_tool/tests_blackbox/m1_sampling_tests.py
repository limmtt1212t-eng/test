"""Compatibility wrapper for `tests_blackbox.m1_sampling_tests`."""

from tests_blackbox.m1_sampling_tests import *  # noqa: F401,F403
