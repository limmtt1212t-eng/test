"""Compatibility wrapper for `tests_blackbox.m2_classification_tests`."""

from tests_blackbox.m2_classification_tests import *  # noqa: F401,F403
