"""Compatibility wrapper for `tests_blackbox.m4_calibration_tests`."""

from tests_blackbox.m4_calibration_tests import *  # noqa: F401,F403
