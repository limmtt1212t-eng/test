"""Top-level package for SBS Evaluation Tool.

Public entrypoint for core classes and tests when installed as a library.

Quick start usage:
    from sbs_evaluation_tool import run_sbs_evaluation, validate_config
    
    config = {...}
    validated_config = validate_config(config, df)
    report_path = run_sbs_evaluation(df, validated_config, segment_name="MyModel")

Detailed usage:
    from sbs_evaluation_tool.core.base_test import BaseModelTest, TestGroupBuilder
    from sbs_evaluation_tool.tests.m2_gini_tests import M21_GiniTest
"""

from importlib import metadata as _metadata

try:
    __version__ = _metadata.version("sbs_evaluation_tool")
except Exception:  # pragma: no cover - during local dev without installed dist
    __version__ = "0.0.0"

# Convenience imports for most common use cases
from .core.base_test import BaseModelTest, TestGroupBuilder, ModelReportBuilder
from .core.config_validation import SBSConfig, ColumnsConfig, validate_config, ConfigValidationError
from .core.inline_display import show_test_inline

# Note: run_sbs_evaluation не импортируем здесь чтобы избежать циклических зависимостей
# Используйте: from sbs_evaluation_tool.core.runner import run_sbs_evaluation

__all__ = [
    "__version__",
    "BaseModelTest",
    "TestGroupBuilder", 
    "ModelReportBuilder",
    "SBSConfig",
    "ColumnsConfig",
    "validate_config",
    "ConfigValidationError",
    "show_test_inline",
]
