# tests_m5_stability.py
from ..core.base_test import BaseModelTest
import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.utils.multiclass import type_of_target
from io import BytesIO
import base64
from tqdm import tqdm
import matplotlib.pyplot as plt
from typing import List, Dict, Optional
from .psi_calculator import PSICalculatorExtended
from .psi_calculator import PSICalculator
from .m2_gini_tests import gini_normalized
from ..core.styles import COLORS
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import (
    ensure_config,
    split_frames,
    get_col_name,
    get_weight_col,
    get_features,
    get_vectors,
    is_binary_mode,
    is_generic_classification_mode,
)
from ._visual_utils import apply_standard_axis_style, figure_to_base64
from joblib import Parallel, delayed
import logging

logger = logging.getLogger(__name__)


def _classification_mode_na(test_name: str) -> Dict[str, str]:
    return {
        "combined": (
            f"<h4>{test_name}</h4>"
            "<p><b>Skipped:</b> generic `classification` mode is not yet mapped "
            "to a methodology-specific stability test. Use `binary` for binomial/logistic tasks.</p>"
        )
    }


# Moved _split_frames_from_cfg, _cfg_col, _weight_from_config to core.data_utils



class M51_ModelGiniStabilityTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 5.1", "Model Gini Stability")

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  score_train: pd.Series = None, target_train: pd.Series = None,
                  score_test: pd.Series = None, target_test: pd.Series = None,
                  sample: str = None, **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = None
        # Config-driven invocation
        if df is not None and config is not None and (score_train is None or target_train is None or score_test is None or target_test is None):
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = "blue"
                    return _classification_mode_na(self.test_name)
                df_tr, df_te, _ = split_frames(df, cfg)
                scol = get_col_name(cfg, 'prediction_column') or get_col_name(cfg, 'score_column')
                tcol = get_col_name(cfg, 'target_column')
                score_train, target_train = df_tr[scol], df_tr[tcol]
                score_test, target_test = df_te[scol], df_te[tcol]
            except Exception as e:
                return {"combined": f"<h4>Model Gini Stability</h4><p>Config error: {str(e)}</p>"}
        # Align and drop NaNs
        mask_tr = (~pd.Series(target_train).isna()) & (~pd.Series(score_train).isna())
        mask_te = (~pd.Series(target_test).isna()) & (~pd.Series(score_test).isna())
        y_tr = pd.Series(target_train)[mask_tr]
        s_tr = pd.Series(score_train)[mask_tr]
        y_te = pd.Series(target_test)[mask_te]
        s_te = pd.Series(score_test)[mask_te]

        is_binary_tr = is_binary_mode(cfg) if cfg is not None else type_of_target(y_tr) == 'binary'
        is_binary_te = is_binary_mode(cfg) if cfg is not None else type_of_target(y_te) == 'binary'

        if is_binary_tr and is_binary_te:
            auc_train = roc_auc_score(y_tr, s_tr)
            auc_test = roc_auc_score(y_te, s_te)
            gini_train = 2 * auc_train - 1
            gini_test = 2 * auc_test - 1
        else:
            # Regression or non-binary target: use normalized Gini (0..1)
            gini_train = gini_normalized(y_tr.values, s_tr.values)
            gini_test = gini_normalized(y_te.values, s_te.values)
        delta = abs(gini_train - gini_test)
        absolute_drop = max(0.0, float(gini_train - gini_test))
        relative_drop = absolute_drop / abs(gini_train) if abs(gini_train) > 1e-12 else 0.0

        # Methodology: signal only on quality decrease from Train to Test.
        if absolute_drop >= 0.10 and relative_drop >= 0.20:
            signal = "red"
        elif absolute_drop >= 0.05 and relative_drop >= 0.15:
            signal = "orange"
        else:
            signal = "green"

        self.test_signal = signal

        html = f"""
        <h4>Model Gini Stability</h4>
        <p><b>Gini (normalized) Train:</b> {gini_train:.4f}</p>
        <p><b>Gini (normalized) Test:</b> {gini_test:.4f}</p>
        <p><b>Delta:</b> {delta:.4f}</p>
        <p><b>Absolute drop:</b> {absolute_drop:.4f}</p>
        <p><b>Relative drop:</b> {relative_drop:.2%}</p>
        <p><i>Rules: RED if absolute drop &ge; 10 p.p. and relative drop &ge; 20%; YELLOW if absolute drop &ge; 5 p.p. and relative drop &ge; 15%; otherwise GREEN.</i></p>
        <p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span></p>
        """
        # Map orange->yellow, blue->info for logging text
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M52_FactorGiniStabilityTest(BaseModelTest):
    def __init__(self):
        super().__init__("M 5.2", "Factor Gini Stability")

    def compute_gini(self, feature: pd.Series, target: pd.Series) -> float:
        # Pairwise drop NaNs
        mask = (~pd.Series(feature).isna()) & (~pd.Series(target).isna())
        x = pd.Series(feature)[mask]
        y = pd.Series(target)[mask]
        # Decide metric based on target type
        if type_of_target(y) == 'binary':
            # Use ROC AUC-based Gini for classification
            try:
                auc = roc_auc_score(y, x)
                return 2 * auc - 1
            except Exception:
                return 0.0
        else:
            # Use normalized Gini for regression (0..1)
            try:
                return float(gini_normalized(y.values, x.values))
            except Exception:
                return 0.0

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  df_train: pd.DataFrame = None, df_test: pd.DataFrame = None,
                  target_column: str = None, features: List[str] = None,
                  **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven invocation
        if df is not None and config is not None and (df_train is None or df_test is None or target_column is None or features is None):
            try:
                cfg = ensure_config(config, df)
                if is_generic_classification_mode(cfg):
                    self.test_signal = "blue"
                    return _classification_mode_na(self.test_name)
                df_tr, df_te, _ = split_frames(df, cfg)
                feats = get_features(df, cfg, include_categorical=False)
                df_train, df_test = df_tr, df_te
                target_column = get_col_name(cfg, 'target_column')
                features = list(feats)
            except Exception as e:
                return {"combined": f"<h4>Factor Gini Stability</h4><p>Config error: {str(e)}</p>"}
        # PowerStat helper
        def powerstat_value(feature_vals: pd.Series, target_vals: pd.Series) -> float:
            y = pd.to_numeric(target_vals, errors='coerce').fillna(0.0).to_numpy(dtype=float)
            s = pd.to_numeric(feature_vals, errors='coerce').fillna(0.0).to_numpy(dtype=float)
            n = y.shape[0]
            if n == 0:
                return 0.0
            total = float(np.sum(y))
            if total <= 0:
                return 0.0
            x_axis = np.arange(1, n + 1, dtype=float) / n
            idx_y = np.argsort(-y)
            a_ideal = float(np.trapz(np.concatenate([[0.0], np.cumsum(y[idx_y]) / total]),
                                     np.concatenate([[0.0], x_axis])))
            idx_s = np.argsort(-s)
            a_model = float(np.trapz(np.concatenate([[0.0], np.cumsum(y[idx_s]) / total]),
                                     np.concatenate([[0.0], x_axis])))
            denom = a_ideal - 0.5
            if denom <= 0:
                return 0.0
            return float(max(0.0, min(1.0, (a_model - 0.5) / denom)))

        # Single parallel pass: Gini + PowerStat per feature
        def _process_feature(f):
            g_tr = self.compute_gini(df_train[f], df_train[target_column]) * 100
            g_te = self.compute_gini(df_test[f], df_test[target_column]) * 100
            ps_tr = powerstat_value(df_train[f], df_train[target_column])
            ps_te = powerstat_value(df_test[f], df_test[target_column])
            return f, g_tr, g_te, abs(g_tr - g_te), ps_tr, ps_te

        results = Parallel(n_jobs=-1, backend="threading")(
            delayed(_process_feature)(f)
            for f in tqdm(features, desc="M 5.2 - Processing Features")
        )
        records = [(r[0], r[1], r[2], r[3]) for r in results]
        ps_data = [(r[0], r[4], r[5]) for r in results]
        df_gini = pd.DataFrame(records, columns=["Feature", "Gini Train", "Gini Test", "Delta"])
        df_ps = pd.DataFrame(ps_data, columns=["Feature", "PS Train", "PS Test"]).sort_values("Feature")

        # Plot grouped bars for PowerStat (Train/Test) per factor using corporate colors
        try:
            fig_w = max(8.0, min(2.5 + 0.55 * len(df_ps), 28.0))
            fig, ax = plt.subplots(figsize=(fig_w, 5.6))
            x = np.arange(len(df_ps))
            width = 0.4
            ax.bar(x - width/2, df_ps["PS Train"], width=width, color=COLORS['BLUE'], alpha=0.85, label='Train')
            ax.bar(x + width/2, df_ps["PS Test"],  width=width, color=COLORS['EMERALD'], alpha=0.85, label='Test')
            short_labels = [(f[:22] + "...") if len(f) > 25 else f for f in df_ps["Feature"]]
            ax.set_xticks(x)
            ax.set_xticklabels(short_labels, rotation=45, ha='right', fontsize=8)
            ax.set_ylim(0, 1.0)
            apply_standard_axis_style(
                ax,
                title='PowerStat by Factor - Train vs Test',
                ylabel='PowerStat (0..1)',
                legend_loc=None,
                title_size=12,
            )
            ax.grid(True, axis='y', linestyle='--', alpha=0.3)
            ax.legend(loc='upper left', fontsize=8, frameon=False)
            fig.tight_layout(pad=1.3)
            ps_img_b64 = figure_to_base64(fig)
            plt.close(fig)
            ps_html = (
                f"<h5>PowerStat by Factor (Train/Test)</h5>"
                f"<img src=\"data:image/png;base64,{ps_img_b64}\" "
                f"style=\"display:block; width:100%; max-width:1100px; height:auto;\">"
            )
        except Exception:
            ps_html = "<p>Failed to render PowerStat chart.</p>"

        # Signal logic
        red = df_gini[df_gini["Delta"] > 10]
        orange = df_gini[(df_gini["Delta"] > 5) & (df_gini["Delta"] <= 10)]
        if len(red) > 0:
            signal = "red"
        elif len(orange) > len(df_gini) * 0.2:
            signal = "orange"
        else:
            signal = "green"

        self.test_signal = signal

        html = f"""
        <h4>Factor Gini Stability</h4>
        <p><b>Signal:</b> <span style='color:{signal}; font-weight:bold'>{signal.upper()}</span></p>
        {df_gini.to_html(index=False, float_format="%.2f")}
        <hr>
        <h4>PowerStat by Factors</h4>
        <p>Comparison of factor power on Train/Test (0..1).</p>
        {ps_html}
        """
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}


class M53_ScorePSITest(BaseModelTest):
    def __init__(self, psi_calc: PSICalculatorExtended):
        super().__init__("M 5.3", "Score PSI Stability")
        self.psi_calc = psi_calc

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  train_df: pd.DataFrame = None, oot_df: pd.DataFrame = None,
                  score_column: str = None, target_column: str = None,
                  **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven invocation
        if df is not None and config is not None and (train_df is None or oot_df is None or score_column is None or target_column is None):
            try:
                cfg = ensure_config(config, df)
                df_tr, df_te, _ = split_frames(df, cfg)
                train_df, oot_df = df_tr, df_te
                score_column = get_col_name(cfg, 'prediction_column') or get_col_name(cfg, 'score_column')
                target_column = get_col_name(cfg, 'target_column')
                w_train = get_weight_col(train_df, cfg)
                w_oot = get_weight_col(oot_df, cfg)
            except Exception as e:
                return {"score": f"<h4>Score PSI Stability</h4><p>Config error: {str(e)}</p>"}
        else:
            w_train = w_oot = None

        psi_result = self.psi_calc.calculate(
            expected=train_df[score_column],
            actual=oot_df[score_column],
            target_expected=train_df[target_column],
            target_actual=oot_df[target_column],
            is_categorical=False,
            weight_expected=w_train,
            weight_actual=w_oot,
        )
        # Custom thresholds for M5.3: Red if PSI >= 0.20, Yellow if 0.10 <= PSI < 0.20, else Green
        try:
            total_psi = float(psi_result['all']['psi'].sum())
        except Exception:
            total_psi = float('inf')  # if cannot compute, mark as red below
        if not np.isfinite(total_psi):
            signal = 'red'
        elif total_psi >= 0.20:
            signal = 'red'
        elif total_psi >= 0.10:
            signal = 'yellow'
        else:
            signal = 'green'
        self.test_signal = signal

        html = self.psi_calc.generate_html_block(psi_result, feature_name="score")
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"score": html, "DASHBOARD": html}


class M54_FactorPSITest(BaseModelTest):
    def __init__(self, psi_calc: PSICalculatorExtended):
        super().__init__("M 5.4", "Factors PSI Stability")
        self.psi_calc = psi_calc

    def run(self, df: pd.DataFrame = None, config: dict = None,
                  train_df: pd.DataFrame = None, oot_df: pd.DataFrame = None,
                  target_column: str = None, features: List[str] = None,
                  categorical_features: List[str] = None, **kwargs) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        # Config-driven invocation
        if df is not None and config is not None and (train_df is None or oot_df is None or target_column is None or features is None):
            try:
                cfg = ensure_config(config, df)
                df_tr, df_te, _ = split_frames(df, cfg)
                train_df, oot_df = df_tr, df_te
                target_column = get_col_name(cfg, 'target_column')
                features = list(getattr(cfg.columns, 'numeric_features', []) or [])
                categorical_features = list(getattr(cfg.columns, 'categorical_features', []) or [])
                w_train = get_weight_col(train_df, cfg)
                w_oot = get_weight_col(oot_df, cfg)
            except Exception as e:
                return {"combined": f"<h4>Factors PSI Stability</h4><p>Config error: {str(e)}</p>"}
        else:
            w_train = w_oot = None
        psi_results = {}
        all_psi_tables = {}
        cats = categorical_features or []

        for feature in tqdm(features, desc="M 5.4 - Processing Features"):
            result = self.psi_calc.calculate(
                expected=train_df[feature],
                actual=oot_df[feature],
                target_expected=train_df[target_column],
                target_actual=oot_df[target_column],
                is_categorical=feature in cats,
                weight_expected=w_train,
                weight_actual=w_oot,
            )
            psi_results[feature] = self.psi_calc.generate_html_block(result, feature)
            all_psi_tables[feature] = result

        # Group signal per new rules:
        # Red — if any "red" factor; Yellow — if >10% "yellow" factors; Green — otherwise.
        # Determine per-feature color using thresholds: green<0.1, yellow in [0.1,0.2), red>=0.2
        def feature_color(total_psi: float) -> str:
            if total_psi >= 0.2:
                return 'red'
            elif total_psi >= 0.1:
                return 'yellow'
            else:
                return 'green'

        colors = []
        for feat, res in all_psi_tables.items():
            try:
                total_psi = float(res['all']['psi'].sum())
            except Exception:
                total_psi = float('inf')
            colors.append(feature_color(total_psi))
        total = max(1, len(colors))
        red_any = any(c == 'red' for c in colors)
        yellow_share = sum(1 for c in colors if c == 'yellow') / total
        if red_any:
            self.test_signal = 'red'
        elif yellow_share > 0.10:
            self.test_signal = 'yellow'
        else:
            self.test_signal = 'green'

        dashboard_html = self.psi_calc.generate_dashboard_table(all_psi_tables)
        psi_results["DASHBOARD"] = dashboard_html
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return psi_results
