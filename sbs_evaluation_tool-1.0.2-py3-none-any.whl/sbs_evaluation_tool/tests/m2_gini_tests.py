# core import
from ..core.base_test import BaseModelTest
# default imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from io import BytesIO
import base64
# stat imports
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, roc_curve, auc
from scipy.stats import norm
from scipy import sparse
from scipy.special import expit 
# module imports
import itertools
from typing import List, Dict, Union, Any, Optional

from joblib import Parallel, delayed, parallel_backend
import numba as nb

# NEW
from ..core.config_validation import validate_config as _validate_config, ConfigValidationError
from ..core.data_utils import (
    ensure_config,
    split_frames,
    get_weight_col,
    get_score_col,
    get_features,
    is_binary_mode,
    is_generic_classification_mode,
    get_validation_label,
)
from ..core.styles import COLORS, STATUS_COLORS
from ._visual_utils import OBSERVATION_COUNT_LABEL, apply_standard_axis_style, figure_to_base64
import logging
from tqdm import tqdm
logger = logging.getLogger(__name__)


def _classification_mode_na(test_name: str) -> Dict[str, str]:
    return {
        "DASHBOARD": (
            f"<h4>{test_name}</h4>"
            "<p><b>Skipped:</b> generic `classification` mode is not yet mapped "
            "to a methodology-specific ranking test. Use `binary` for binomial/logistic tasks.</p>"
        )
    }

# Удалены дублирующиеся утилиты (_split_frames_from_cfg, _features_from_cfg, _score_from_cfg, _weight_from_config)
# Их функционал перенесен в core/data_utils.py

# --- Регрессионный вариант нормализованного Gini (0..1) ---
def gini_normalized(y_true: np.ndarray, y_pred: np.ndarray, sample_weight: Optional[np.ndarray] = None) -> float:
    """
    Вычисляет нормализованный коэффициент Gini (от 0 до 1) для регрессии.

    Args:
        y_true: Вектор истинных значений (1D).
        y_pred: Вектор предсказанных значений/скорингов (1D).

    Returns:
        Нормализованный Gini (float).
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if y_true.shape != y_pred.shape:
        raise ValueError("Shapes of y_true and y_pred must match.")

    w = None
    if sample_weight is not None:
        w = np.asarray(sample_weight, dtype=float)
        if w.shape != y_true.shape:
            w = w[: y_true.shape[0]]
        if np.sum(w) <= 0:
            w = None

    def gini(actual, pred, weight=None):
        order = np.argsort(pred)
        a_sorted = actual[order]
        if weight is not None:
            w_sorted = weight[order]
            total_w = w_sorted.sum()
            total_y = np.sum(a_sorted * w_sorted)
            if total_w <= 0 or total_y <= 0:
                return 0.0
            # Кумулятивная доля по весам и по взвешенным событиям
            cum_w = np.cumsum(w_sorted) / total_w
            cum_y = np.cumsum(a_sorted * w_sorted) / total_y
            # Площадь под кривой Лоренца (trapz по cum_w)
            area = np.trapz(cum_y, cum_w)
            # Нормированный gini = 2*area - 1
            return 2.0 * area - 1.0
        else:
            n = len(a_sorted)
            total = a_sorted.sum()
            if n == 0 or total == 0:
                return 0.0
            cum_actual = np.cumsum(a_sorted)
            gini_sum = cum_actual.sum() / total - (n + 1) / 2.0
            return gini_sum / n

    gini_den = gini(y_true, y_true, w)
    if gini_den == 0:
        return 0.0
    return gini(y_true, y_pred, w) / gini_den


def powerstat_value(target: Union[pd.Series, np.ndarray], score: Union[pd.Series, np.ndarray]) -> float:
    """Compute PowerStat using the same cumulative-gains formula as M 2.1."""
    y_np = pd.to_numeric(pd.Series(target), errors="raise").to_numpy(dtype=float, copy=False)
    s_np = pd.to_numeric(pd.Series(score), errors="raise").to_numpy(dtype=float, copy=False)
    mask = np.isfinite(y_np) & np.isfinite(s_np)
    y_np = y_np[mask]
    s_np = s_np[mask]

    n = y_np.shape[0]
    if n == 0:
        return 0.0
    total = float(np.sum(y_np))
    if total <= 0:
        return 0.0

    def cum_curve(y_vals: np.ndarray, order_idx: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        y_sorted = y_vals[order_idx]
        cum_y = np.cumsum(y_sorted)
        x = np.arange(1, len(y_sorted) + 1, dtype=float) / len(y_sorted)
        y_share = cum_y / total
        return np.concatenate([[0.0], x]), np.concatenate([[0.0], y_share])

    x_ideal, y_ideal = cum_curve(y_np, np.argsort(-y_np))
    x_model, y_model = cum_curve(y_np, np.argsort(-s_np))

    a_ideal = float(np.trapz(y_ideal, x_ideal))
    a_model = float(np.trapz(y_model, x_model))
    denom = a_ideal - 0.5
    if denom <= 0:
        return 0.0
    return float(max(0.0, min(1.0, (a_model - 0.5) / denom)))


class M21_GiniTest(BaseModelTest): 
    """
    Класс для теста M 2.1: Gini Test.

    Проверяет общую способность модели к ранжированию, вычисляя коэффициент Gini 
    для обучающей и тестовой выборки, строит ROC-кривые и визуализирует результаты.
    Выдаёт итоговый сигнал (зелёный, жёлтый или красный) на основе порогов качества.

    Наследует:
        BaseModelTest: Базовый класс для всех модельных тестов.

    Атрибуты:
        * test_signal (str): Итоговый цветовой сигнал ("green", "yellow", "red"),
          рассчитывается на основе значений Gini на train и test.

    Методы:
        * compute_gini(score, target): Вычисляет коэффициент Gini.
        * compute_gini_html(score, target, label): Строит ROC-кривую, возвращает HTML с Gini и графиком.
        * compute_signal(gini_train, gini_test): Определяет сигнал по значениям Gini.
        * run(score_train, target_train, score_test, target_test): Основной метод, запускающий тест.
    """ 
    def __init__(self):
        super().__init__("M 2.1", "Gini Test")

    def compute_gini(
        self,
        score: pd.Series,
        target: pd.Series,
        weight: Optional[pd.Series] = None,
    ) -> float:
        """
        Вычисляет коэффициент Gini на основе AUC (Gini = 2 * AUC - 1).

        Параметры:
            * score (pd.Series): Series с предсказанными значениями модели.
            * target (pd.Series): Series с фактическими бинарными метками (0/1).
            * weight (pd.Series, optional): Веса (экспозиция). Если не заданы, расчёт невзвешенный.

        Возвращает:
            * float: Значение коэффициента Gini.
        """
        w = None
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").fillna(0.0)
            if (w > 0).sum() == 0:
                w = None
        auc = roc_auc_score(target, score, sample_weight=w)
        return 2 * auc - 1

    def compute_gini_html(
        self,
        score: pd.Series,
        target: pd.Series,
        label: str,
        weight: Optional[pd.Series] = None,
    ) -> str:
        """
        Строит ROC-кривую и вычисляет Gini/AUC, возвращает HTML-блок с графиком.

        Параметры:
            * score (pd.Series): Series с предсказанными значениями модели.
            * target (pd.Series): Series с фактическими бинарными метками (0/1).
            * label (str): Метка для подписи графика (например, "Train" или "Test").
            * weight (pd.Series, optional): Веса (экспозиция). Если заданы, ROC/AUC считаются взвешенно.

        Возвращает:
            * str: HTML-строка с коэффициентом Gini и изображением ROC-кривой.

        Исключения:
            * ValueError: Если столбец не является числовым и перевод в числовой тип невозможен.
            * ValueError: Если столбец содержит пропущенные значения.
        """
        # Проверяем, что данные можно перевести в числовой формат
        for col_name, col_series in zip(['score', 'target'], [score, target]):
            if not pd.api.types.is_numeric_dtype(col_series):
                try:
                    col_series = pd.to_numeric(col_series, errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {col_name} не является числовым. Перевод в числовой тип невозможен.")
            if col_series.isnull().any():
                raise ValueError(f"Столбец {col_name} содержит пропущенные значения.")

        w = None
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").fillna(0.0)
            if (w > 0).sum() == 0:
                w = None

        auc = roc_auc_score(target, score, sample_weight=w)
        gini = 2 * auc - 1

        fpr, tpr, _ = roc_curve(target, score, sample_weight=w)
        fig, ax = plt.subplots()
        ax.plot(fpr, tpr, label=f"{label} ROC (AUC = {auc:.4f})")
        ax.plot([0, 1], [0, 1], '--', color=COLORS['GRAY'])
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.set_title(f"ROC Curve - {label}")
        ax.legend()
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        encoded = base64.b64encode(buf.getvalue()).decode()

        return gini, f"""
        <h4>{label} Gini</h4>
        <p><b>Gini:</b> {gini:.4f}</p>
        <img src="data:image/png;base64,{encoded}">
        """

    def compute_powerstat_html(self, score: pd.Series, target: pd.Series, label: str) -> tuple[float, str]:
        """
        Строит кумулятивные кривые (идеальная, модельная и случайная) и вычисляет PowerStat.

        PowerStat = (A_model - A_random) / (A_ideal - A_random),
        где A_random = 0.5 — площадь под y=x.
        Работает и для классификации (0/1), и для регрессии (неотрицательная целевая).
        Возвращает кортеж (powerstat, html).
        """
        # Приведение к численным и проверка пропусков
        y = pd.to_numeric(target, errors='raise')
        s = pd.to_numeric(score, errors='raise')
        if y.isnull().any() or s.isnull().any():
            raise ValueError("Столбцы score/target содержат пропуски.")

        # Превращаем в numpy для скорости
        y_np = y.to_numpy(dtype=float, copy=False)
        s_np = s.to_numpy(dtype=float, copy=False)
        n = y_np.shape[0]
        if n == 0:
            return 0.0, "<p>Нет данных для расчёта PowerStat.</p>"
        total = float(np.sum(y_np))
        if total <= 0:
            # Если целевая сумма нулевая — все кривые совпадут с 0; PowerStat неинформативен
            return 0.0, "<p>Сумма целевой переменной равна 0 — PowerStat = 0.</p>"

        # Подготовим вспомогательную функцию
        def cum_curve(y_vals: np.ndarray, order_idx: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
            y_sorted = y_vals[order_idx]
            cum_y = np.cumsum(y_sorted)
            x = np.arange(1, len(y_sorted) + 1, dtype=float) / len(y_sorted)
            y_share = cum_y / total
            # Добавим начало (0,0)
            x = np.concatenate([[0.0], x])
            y_share = np.concatenate([[0.0], y_share])
            return x, y_share

        # Идеальная кривая: сортировка по убыванию факта
        idx_ideal = np.argsort(-y_np)
        x_ideal, y_ideal = cum_curve(y_np, idx_ideal)

        # Модельная кривая: сортировка по убыванию прогноза
        idx_model = np.argsort(-s_np)
        x_model, y_model = cum_curve(y_np, idx_model)

        # Случайная кривая: y=x, площадь 0.5
        x_rand = np.array([0.0, 1.0])
        y_rand = np.array([0.0, 1.0])

        # Площади под кривыми
        a_ideal = float(np.trapz(y_ideal, x_ideal))
        a_model = float(np.trapz(y_model, x_model))
        a_random = 0.5
        denom = (a_ideal - a_random)
        if denom <= 0:
            powerstat = 0.0
        else:
            powerstat = max(0.0, min(1.0, (a_model - a_random) / denom))

        # Визуализация в корпоративных цветах
        fig, ax = plt.subplots(figsize=(7.2, 5.0))
        ax.fill_between(x_model, y_model, color=COLORS['EMERALD'], alpha=0.14)
        ax.plot(x_model, y_model, color=COLORS['EMERALD'], linewidth=2.4, label='Model')
        ax.plot(x_rand, y_rand, '--', color=COLORS['GRAY'], linewidth=1.4, label='Random baseline')

        # Доп. оформление
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        apply_standard_axis_style(
            ax,
            title=f"PowerStat Curve - {label}",
            xlabel='Cumulative Share of Observations',
            ylabel='Cumulative Share of Target Sum',
            legend_loc='lower right',
        )
        fig.tight_layout(pad=1.1)
        encoded = figure_to_base64(fig)
        plt.close(fig)

        html = f"""
        <h5>PowerStat - {label}</h5>
        <p><b>PowerStat:</b> {powerstat:.4f}</p>
        <img src="data:image/png;base64,{encoded}" style="display:block; width:100%; max-width:860px; height:auto;">
        """
        return powerstat, html

    def compute_reg_gini_html(
        self,
        score: pd.Series,
        target: pd.Series,
        label: str,
        weight: Optional[pd.Series] = None,
    ) -> str:
        """
        Регрессионный вариант: считает нормализованный Gini и строит простую кривую Лоренца.

        Возвращает кортеж (gini, html).
        """
        # проверки типов/NaN
        for col_name, col_series in zip(['score', 'target'], [score, target]):
            if not pd.api.types.is_numeric_dtype(col_series):
                try:
                    col_series = pd.to_numeric(col_series, errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {col_name} не является числовым. Перевод в числовой тип невозможен.")
            if col_series.isnull().any():
                raise ValueError(f"Столбец {col_name} содержит пропущенные значения.")

        # Нормализованный Gini (при наличии весов считаем взвешенно)
        w = None
        if weight is not None:
            w = pd.to_numeric(weight, errors="coerce").fillna(0.0).to_numpy()
            if (w > 0).sum() == 0:
                w = None
        gini = float(gini_normalized(np.asarray(target), np.asarray(score), sample_weight=w))

        # Построим кривую Лоренца для наглядности
        order = np.argsort(score)
        y_sorted = np.asarray(target)[order]
        n = len(y_sorted)
        total = y_sorted.sum()
        if weight is not None:
            w_sorted = w[order] if w is not None else None
            total_w = w_sorted.sum() if w_sorted is not None else 0.0
            pop_share = np.cumsum(w_sorted) / total_w if total_w > 0 else np.zeros_like(y_sorted, dtype=float)
            if total == 0 or total_w == 0:
                lorenz = np.zeros_like(pop_share)
            else:
                lorenz = np.cumsum(y_sorted * w_sorted) / np.sum(y_sorted * w_sorted)
        else:
            pop_share = np.arange(1, n + 1) / n
            if total == 0:
                lorenz = np.zeros_like(pop_share)
            else:
                lorenz = np.cumsum(y_sorted) / total

        fig, ax = plt.subplots()
        ax.plot(pop_share, lorenz, label="Lorenz curve", color=COLORS['EMERALD'])
        ax.plot([0, 1], [0, 1], '--', color=COLORS['GRAY'], label="Equality")
        ax.set_xlabel("Population share")
        ax.set_ylabel("Cumulative target share")
        ax.set_title(f"Lorenz Curve - {label}")
        ax.legend()
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        encoded = base64.b64encode(buf.getvalue()).decode()

        return gini, f"""
        <h4>{label} Normalized Gini (Regression)</h4>
        <p><b>Gini:</b> {gini:.4f}</p>
        <img src="data:image/png;base64,{encoded}">
        """

    def compute_signal(self, gini_test: float) -> str:
        """
        Итоговый сигнал зависит только от качества на тесте:
          - "red"    если Gini_test < 0.20
          - "yellow" если 0.20 ≤ Gini_test < 0.35
          - "green"  если Gini_test ≥ 0.35

        Параметры:
            * gini_test (float): Значение Gini на тестовой выборке (0..1).

        Возвращает:
            * str: "red" | "yellow" | "green".
        """
        if gini_test < 0.20:
            return "red"
        elif gini_test < 0.35:
            return "yellow"
        return "green"

    def _plot_combined_gini(self, g_train: float, g_test: float) -> str:
        """
        Рисует один график со значениями Gini для Train и Test и референс-линией Gini=0.20 (красный пунктир).

        Возвращает base64 PNG.
        """
        # Цвет теста по правилам светофора
        if g_test < 0.20:
            test_color = 'red'
        elif g_test < 0.35:
            test_color = 'orange'  # используем оранжевый как жёлтый
        else:
            test_color = 'green'

        fig, ax = plt.subplots(figsize=(6.4, 4.4))
        labels = ["Train", "Test"]
        values = [g_train, g_test]
        colors = [COLORS['BLUE'], COLORS['EMERALD']]

        bars = ax.bar(labels, values, color=colors, alpha=0.85)

        # Подписи значений над столбцами
        for rect, val in zip(bars, values):
            ax.annotate(f"{val:.3f}",
                        xy=(rect.get_x() + rect.get_width() / 2, rect.get_height()),
                        xytext=(0, 6),
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=9, fontweight='bold')

        # Референс-линия Gini=0.20 (красный пунктир)
        ax.axhline(y=0.20, color=STATUS_COLORS['red'], linestyle='--', linewidth=1.5, label='Red threshold = 0.20')
        ax.axhline(y=0.35, color=STATUS_COLORS['orange'], linestyle='--', linewidth=1.5, label='Yellow threshold = 0.35')

        # Оформление
        ax.set_ylim(0, max(0.45, max(values) * 1.22))
        apply_standard_axis_style(
            ax,
            title='Overall Gini: Train vs Test',
            ylabel='Gini (0..1)',
            legend_loc='upper left',
        )
        fig.tight_layout(pad=1.1)
        encoded = figure_to_base64(fig)
        plt.close(fig)
        return encoded

    def _plot_roc_both(
        self,
        y_train: pd.Series,
        s_train: pd.Series,
        y_test: pd.Series,
        s_test: pd.Series,
        w_train: Optional[pd.Series] = None,
        w_test: Optional[pd.Series] = None,
    ) -> tuple[str, float, float]:
        """
        Строит один график c ROC-кривыми для Train и Test (только для classification).
        Возвращает base64 PNG.
        """
        w_tr = None
        if w_train is not None:
            w_tr = pd.to_numeric(w_train, errors="coerce").fillna(0.0)
            if (w_tr > 0).sum() == 0:
                w_tr = None
        w_te = None
        if w_test is not None:
            w_te = pd.to_numeric(w_test, errors="coerce").fillna(0.0)
            if (w_te > 0).sum() == 0:
                w_te = None

        fpr_tr, tpr_tr, _ = roc_curve(y_train, s_train, sample_weight=w_tr)
        auc_tr = roc_auc_score(y_train, s_train, sample_weight=w_tr)
        fpr_te, tpr_te, _ = roc_curve(y_test, s_test, sample_weight=w_te)
        auc_te = roc_auc_score(y_test, s_test, sample_weight=w_te)

        fig, ax = plt.subplots(figsize=(6.5, 5))
        # Закрашиваем площадь под кривыми для наглядности ROC-AUC
        ax.fill_between(fpr_tr, tpr_tr, alpha=0.15, color=COLORS['BLUE'])
        ax.fill_between(fpr_te, tpr_te, alpha=0.15, color=COLORS['EMERALD'])
        ax.plot(fpr_tr, tpr_tr, label=f"Train ROC (AUC={auc_tr:.3f})", color=COLORS['BLUE'])
        ax.plot(fpr_te, tpr_te, label=f"Test ROC (AUC={auc_te:.3f})", color=COLORS['EMERALD'])
        ax.plot([0, 1], [0, 1], '--', color=COLORS['GRAY'], linewidth=1)
        ax.set_xlabel("False Positive Rate")
        ax.set_ylabel("True Positive Rate")
        ax.set_title("ROC-AUC - Train vs Test")
        ax.legend(loc="lower right")
        ax.grid(True, linestyle='--', alpha=0.3)
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png", dpi=150)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode(), float(auc_tr), float(auc_te)

    def _plot_auc_bars(self, auc_tr: float, auc_te: float) -> str:
        """Простой столбиковый график ROC-AUC для Train/Test."""
        fig, ax = plt.subplots(figsize=(4.5, 3.8))
        labels = ["Train", "Test"]
        vals = [auc_tr, auc_te]
        colors = [COLORS['BLUE'], COLORS['EMERALD']]
        bars = ax.bar(labels, vals, color=colors, alpha=0.85)
        for r, v in zip(bars, vals):
            ax.annotate(f"{v:.3f}", (r.get_x() + r.get_width()/2, r.get_height()),
                        xytext=(0, 6), textcoords="offset points",
                        ha='center', va='bottom', fontsize=9, fontweight='bold')
        ax.set_ylim(0, max(1.0, max(vals) * 1.05))
        ax.set_ylabel("ROC-AUC (0..1)")
        ax.set_title("ROC-AUC values")
        ax.grid(True, axis='y', linestyle='--', alpha=0.3)
        plt.tight_layout()
        encoded = figure_to_base64(fig)
        plt.close(fig)
        return encoded

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        df_train, df_test, _ = split_frames(df, cfg)
        target_col = cfg.columns.target_column
        score_col  = get_score_col(cfg)  # см. helper выше

         # веса (экспозиция), если заданы в конфиге
        w_train = get_weight_col(df_train, cfg)
        w_test = get_weight_col(df_test, cfg)

        # Проверки типов/NaN такие же, как в html-функциях
        for col_name, col_series in [("score", df_train[score_col]), ("target", df_train[target_col]),
                                     ("score", df_test[score_col]), ("target", df_test[target_col])]:
            if not pd.api.types.is_numeric_dtype(col_series):
                try:
                    pd.to_numeric(col_series, errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {col_name} не является числовым. Перевод в числовой тип невозможен.")
            if col_series.isnull().any():
                raise ValueError(f"Столбец {col_name} содержит пропущенные значения.")

        # Считаем Gini
        if is_binary_mode(cfg):
            gini_train = self.compute_gini(df_train[score_col], df_train[target_col], w_train)
            gini_test  = self.compute_gini(df_test[score_col],  df_test[target_col],  w_test)
        else:
            w_tr_np = w_train.to_numpy() if w_train is not None else None
            w_te_np = w_test.to_numpy() if w_test is not None else None
            gini_train = gini_normalized(
                np.asarray(df_train[target_col]),
                np.asarray(df_train[score_col]),
                sample_weight=w_tr_np,
            )
            gini_test  = gini_normalized(
                np.asarray(df_test[target_col]),
                np.asarray(df_test[score_col]),
                sample_weight=w_te_np,
            )

        # Сигнал по тесту
        self.test_signal = self.compute_signal(gini_test)

        # Единый график
        img = self._plot_combined_gini(gini_train, gini_test)

        # HTML-дашборд
        legend_note = (
            f"Цвет TEST: <span style='color:{STATUS_COLORS['red']}'>красный</span> если Gini<0.20; "
            f"<span style='color:{STATUS_COLORS['orange']}'>жёлтый</span> если 0.20≤Gini<0.35; "
            f"<span style='color:{STATUS_COLORS['green']}'>зелёный</span> если Gini≥0.35."
        )
        # Для классификации добавим общий ROC-график
        legend_note = (
            f"Test signal thresholds: <span style='color:{STATUS_COLORS['red']}'>red</span> if Gini &lt; 0.20; "
            f"<span style='color:{STATUS_COLORS['orange']}'>yellow</span> if 0.20 ≤ Gini &lt; 0.35; "
            f"<span style='color:{STATUS_COLORS['green']}'>green</span> if Gini ≥ 0.35."
        )
        legend_note = (
            f"Test signal thresholds: <span style='color:{STATUS_COLORS['red']}'>red</span> if Gini &lt; 0.20; "
            f"<span style='color:{STATUS_COLORS['orange']}'>yellow</span> if 0.20 &le; Gini &lt; 0.35; "
            f"<span style='color:{STATUS_COLORS['green']}'>green</span> if Gini &ge; 0.35."
        )
        roc_img = ""
        if is_binary_mode(cfg):
            roc_b64, auc_tr, auc_te = self._plot_roc_both(
                df_train[target_col],
                df_train[score_col],
                df_test[target_col],
                df_test[score_col],
                w_train,
                w_test,
            )
            auc_bars = self._plot_auc_bars(auc_tr, auc_te)
            roc_img = (
                f"<h5>ROC-AUC - Train vs Test</h5>"
                f"<img src=\"data:image/png;base64,{roc_b64}\" style=\"display:block; width:100%; max-width:860px; height:auto;\">"
                f"<br><img src=\"data:image/png;base64,{auc_bars}\" style=\"display:block; width:100%; max-width:560px; height:auto;\">"
            )

        # PowerStat (общая эффективность) — для Train и Test
        ps_tr, ps_tr_html = self.compute_powerstat_html(df_train[score_col], df_train[target_col], 'Train')
        ps_te, ps_te_html = self.compute_powerstat_html(df_test[score_col],  df_test[target_col],  'Test')

        html = f"""
        <h4>Overall Gini</h4>
        <p><b>Train Gini:</b> {gini_train:.4f} &nbsp; | &nbsp; <b>Test Gini:</b> {gini_test:.4f}</p>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>
        <p>{legend_note}</p>
        <img src="data:image/png;base64,{img}" style="display:block; width:100%; max-width:720px; height:auto;">
        <br>{roc_img}
        <hr>
        <h4>M2.1: Overall Model Performance</h4>
        <p>PowerStat is the normalized area under the cumulative gains curve relative to the random baseline.</p>
        {ps_tr_html}
        {ps_te_html}
        """
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": html}


@nb.njit(parallel=False, fastmath=True)
def gininumba(y_true: np.array, y_pred: np.array) -> float:
    """
    Рассчитывает коэффициент gini через кривую Лоренца.
    """
    # Сортируем предсказания по убыванию вероятностей и получаем индексы сортировки
    order = np.argsort(-y_pred)    
    # Применяем сортировку к истинным значениям на основе индексов             
    y_sorted = y_true[order]

    total = y_sorted.sum()
    n = y_sorted.size

    if total == 0: 
        return 0 
    
    # Вычисляем накопленные суммы истинных значений (например, убытков) и экспозиции
    cum_y = np.cumsum(y_sorted)
    cum_pop = np.arange(1, n + 1)
    # Вычисляем gini через кривую Лоренца для предсказанных значений
    gini = (2.0 * np.trapz(cum_y / total, cum_pop / n) - 1.0)

    return gini

def gini_one_feature(y_tr: np.array, y_te: np.array, x_tr: np.array, x_te: np.array, name:str):
        """
        Вычисляет индекс Джини для указанной переменной на тренировочном и тестовом наборах данных.
        """
        # Считаем gini на трейн и переводим в %
        g_tr = gininumba(y_tr, x_tr) * 100.0
        # Считаем gini на тесте и переводим в %
        g_te = gininumba(y_te, x_te) * 100.0
        return name, g_tr, g_te, abs(g_tr - g_te)

def gini_for_features_fast(df_tr: pd.DataFrame, df_te: pd.DataFrame, target: str, features: list, n_jobs=-1) -> list:
    """
    Вычисляет индекс Джини для списка факторов на тренировочном и тестовом наборах данных.

    Параметры
    ----------
    * df_tr : pd.DataFrame
          - Тренировочный набор данных.
    * df_te : pd.DataFrame
          - Тестовый набор данных.
    * target : str
          - Имя целевой переменной.
    * features : list
          - Список имен функций, для которых нужно вычислить индекс Джини.
    * n_jobs : int, optional
          - Количество заданий для параллельной обработки. По умолчанию: -1 (используются все доступные ядра).

    Возвращает
    -------
    * list: Список, содержащий результаты вычисления индекса Джини для каждой переменной.
   """
    # Получаем таргет для трайн и тест
    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)

    with parallel_backend("threading"):
        # Запускаем обработку признаков 
        out = Parallel(n_jobs=n_jobs)(
            delayed(gini_one_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(dtype=np.float32), # Нам хватит даже для весов, тк точность до 7 знаков
                df_te[f].to_numpy(dtype=np.float32),
                f
            ) for f in features
        )
    return out

def gini_one_categorical_feature(
    y_tr: np.array, 
    y_te: np.array, 
    x_tr: np.array, 
    x_te: np.array, 
    name: str
) -> tuple:
    """
    Вычисляет индекс Джини для категориального признака используя mean target encoding.
    
    Параметры:
        * y_tr: целевая переменная на train
        * y_te: целевая переменная на test
        * x_tr: значения категориального признака на train
        * x_te: значения категориального признака на test
        * name: название признака
    
    Возвращает:
        * tuple: (название признака, gini train %, gini test %, разница %)
    """
    # Создаем датафрейм для удобства группировки
    df_tr = pd.DataFrame({'cat': x_tr, 'target': y_tr})
    df_te = pd.DataFrame({'cat': x_te, 'target': y_te})
    
    # Вычисляем mean target encoding на train
    # Для каждой категории считаем среднее значение таргета
    encoding_map = df_tr.groupby('cat')['target'].mean().to_dict()
    
    # Применяем encoding к обеим выборкам
    # Для неизвестных категорий в test используем общий средний
    global_mean = df_tr['target'].mean()
    
    x_tr_encoded = df_tr['cat'].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)
    x_te_encoded = df_te['cat'].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)
    
    # Считаем gini на основе закодированных значений
    g_tr = gininumba(y_tr, x_tr_encoded) * 100.0
    g_te = gininumba(y_te, x_te_encoded) * 100.0
    
    return name, g_tr, g_te, abs(g_tr - g_te)

def gini_for_categorical_features(
    df_tr: pd.DataFrame, 
    df_te: pd.DataFrame, 
    target: str, 
    features: list, 
    n_jobs=-1
) -> list:
    """
    Вычисляет индекс Джини для списка категориальных признаков.
    Использует mean target encoding для преобразования категорий в числа.
    
    Параметры:
        * df_tr: тренировочный набор данных
        * df_te: тестовый набор данных
        * target: имя целевой переменной
        * features: список имен категориальных признаков
        * n_jobs: количество потоков для параллельной обработки
    
    Возвращает:
        * list: список результатов для каждого признака
    """
    if not features:
        return []
    
    # Получаем таргет для train и test
    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)
    
    with parallel_backend("threading"):
        # Запускаем обработку признаков
        out = Parallel(n_jobs=n_jobs)(
            delayed(gini_one_categorical_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(),  # Категориальные признаки оставляем как есть
                df_te[f].to_numpy(),
                f
            ) for f in features
        )
    return out

# Переопределим M22_GiniFactorsTest с улучшениями после сброса
def powerstat_one_feature(y_tr: np.array, y_te: np.array, x_tr: np.array, x_te: np.array, name: str):
    ps_tr = powerstat_value(y_tr, x_tr) * 100.0
    ps_te = powerstat_value(y_te, x_te) * 100.0
    return name, ps_tr, ps_te, abs(ps_tr - ps_te)


def powerstat_for_features_fast(df_tr: pd.DataFrame, df_te: pd.DataFrame, target: str, features: list, n_jobs=-1) -> list:
    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)

    with parallel_backend("threading"):
        out = Parallel(n_jobs=n_jobs)(
            delayed(powerstat_one_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(dtype=np.float32),
                df_te[f].to_numpy(dtype=np.float32),
                f,
            ) for f in features
        )
    return out


def powerstat_one_categorical_feature(
    y_tr: np.array,
    y_te: np.array,
    x_tr: np.array,
    x_te: np.array,
    name: str,
) -> tuple:
    df_tr = pd.DataFrame({"cat": x_tr, "target": y_tr})
    df_te = pd.DataFrame({"cat": x_te, "target": y_te})

    encoding_map = df_tr.groupby("cat")["target"].mean().to_dict()
    global_mean = df_tr["target"].mean()

    x_tr_encoded = df_tr["cat"].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)
    x_te_encoded = df_te["cat"].map(encoding_map).fillna(global_mean).to_numpy(dtype=np.float32)

    ps_tr = powerstat_value(y_tr, x_tr_encoded) * 100.0
    ps_te = powerstat_value(y_te, x_te_encoded) * 100.0
    return name, ps_tr, ps_te, abs(ps_tr - ps_te)


def powerstat_for_categorical_features(
    df_tr: pd.DataFrame,
    df_te: pd.DataFrame,
    target: str,
    features: list,
    n_jobs=-1,
) -> list:
    if not features:
        return []

    y_tr = df_tr[target].to_numpy(dtype=np.float32)
    y_te = df_te[target].to_numpy(dtype=np.float32)

    with parallel_backend("threading"):
        out = Parallel(n_jobs=n_jobs)(
            delayed(powerstat_one_categorical_feature)(
                y_tr, y_te,
                df_tr[f].to_numpy(),
                df_te[f].to_numpy(),
                f,
            ) for f in features
        )
    return out


class M22_GiniFactorsTest(BaseModelTest):
    """
    Класс для теста M 2.2: Gini by Factors.

    Проверяет информативность признаков на обучающей и тестовой выборках с помощью коэффициента Джини.
    Строит графики, расставляет флаги (зеленый/жёлтый/красный) по уровням значимости признаков 
    и определяет общий сигнал качества. Используется для оценки стабильности и значимости отдельных факторов.

    Общая логика:
        1. Для каждого признака считаются значения Gini по train и test (на основе кривой Лоренца).
        2. Вычисляется разница между Gini на train и test.
        3. Каждому признаку присваивается флаг: 
            - "green" — Gini > 5%,
            - "yellow" — 0% < Gini ≤ 5%,
            - "red" — Gini ≤ 0%.
        4. Выводится сигнал:
            - "red" — если есть хотя бы один красный флаг,
            - "yellow" — если более 20% признаков жёлтые,
            - "green" — в остальных случаях.
        5. Генерируется HTML-отчет с графиками и таблицами.

    Атрибуты:
        * test_signal (str): Итоговый сигнал для всего теста ("green", "yellow", "red").
        * individual_features_gini (pd.DataFrame): Таблица со значениями Gini и флагами по каждому признаку.

    Методы:
        * assign_flag(gini): Возвращает флаг на основе значения Gini.
        * compute_signal(flags): Определяет итоговый сигнал по списку флагов.
        * plot_gini_bar(df, column, title): Строит горизонтальную гистограмму Gini для признаков.
        * run(df_train, df_test, target_column, features, n_jobs): Запускает тест и возвращает HTML-отчет.
    """
    def __init__(self):
        super().__init__("M 2.2", "PowerStat by Factors")
        self.individual_features_gini = pd.DataFrame()
        self.individual_features_powerstat = pd.DataFrame()

    def assign_flag(self, gini):
        """
        Присваивает цветовой флаг на основе значения Gini:
            - "red": Gini ≤ 0
            - "yellow": Gini ≤ 5
            - "green": Gini > 5

        Параметры:
            * gini (float): Значение Gini (%).

        Возвращает:
            * str: Цвет флага.
        """
        if gini <= 0:
            return "red"
        elif gini <= 5:
            return "yellow"
        else:
            return "green"

    def compute_signal(self, flags: List[str]) -> str:
        """
        Рассчитывает итоговый сигнал по списку флагов:
            - "red": если есть хотя бы один красный.
            - "yellow": если жёлтых более 20%.
            - "green": в остальных случаях.

        Параметры:
            * flags (List[str]): Список цветовых флагов по признакам.

        Возвращает:
            * str: Цвет итогового сигнала ("red", "yellow", "green").
        """
        if "red" in flags:
            return "red"
        yellow_count = flags.count("yellow")
        total = len(flags)
        if yellow_count / total > 0.2:
            return "yellow"
        return "green"

    def plot_gini_bar(self, gini_df: pd.DataFrame, column: str, title: str) -> str:
        """
        Строит горизонтальную гистограмму значений Gini по признакам и кодирует её в base64.

        Параметры:
            * gini_df (pd.DataFrame): Таблица с Gini и флагами.
            * column (str): Название колонки для построения ("Gini_Train" или "Gini_Test").
            * title (str): Заголовок графика.

        Возвращает:
            * str: Base64-кодированное изображение графика.
        """
        # 0.25 inch на признак → 400 фич = 100 inch ≈ 254 см; ограничим
        height = min(0.2 * len(gini_df), 60)
        fig, ax = plt.subplots(figsize=(10, height))

        bars = ax.barh(gini_df["Feature"], gini_df[column], color=COLORS['GRAY'])
        for i, flag in enumerate(gini_df[f"{column}_flag"]):
            bars[i].set_color(flag)

        ax.set_xlabel("PowerStat %")
        ax.set_title(title)
        ax.grid(True, axis="x", linestyle='--', linewidth=0.5)
        
        # Уменьшаем шрифт, чтобы длинные имена влезли
        ax.tick_params(labelsize=8)
        
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png", dpi=150)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, df: pd.DataFrame, config: dict, n_jobs=3) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        df_train, df_test, _ = split_frames(df, cfg)
        target_column = cfg.columns.target_column
        
        # Получаем и численные, и категориальные признаки
        num_features = cfg.columns.numeric_features or []
        cat_features = cfg.columns.categorical_features or []

        all_features = num_features + cat_features
        if not all_features:
            raise ConfigValidationError(["Для M 2.2 требуется непустой список columns.numeric_features или columns.categorical_features"])

        # Проверяем наличие колонок
        missing_cols = [col for col in all_features + [target_column] 
                       if col not in df_train.columns or col not in df_test.columns]
        if missing_cols:
            raise ValueError(f"Следующие колонки отсутствуют в данных: {missing_cols}")
        
        # Валидация численных признаков и таргета
        for col_name in tqdm(num_features + [target_column], desc="M 2.2 - Validate numeric columns"):
            if not pd.api.types.is_numeric_dtype(df_train[col_name]):
                try:
                    df_train[col_name] = pd.to_numeric(df_train[col_name], errors='raise')
                except ValueError:
                    raise ValueError(f"Column {col_name} is not numeric.")
            if not pd.api.types.is_numeric_dtype(df_test[col_name]):
                try:
                    df_test[col_name] = pd.to_numeric(df_test[col_name], errors='raise')
                except ValueError:
                    raise ValueError(f"Column {col_name} is not numeric.")
            if df_train[col_name].isnull().any():
                raise ValueError(f"Column {col_name} contains missing values.")
            if df_test[col_name].isnull().any():
                raise ValueError(f"Column {col_name} contains missing values.")

        # Валидация категориальных признаков (просто проверяем на NaN)
        for col_name in tqdm(cat_features, desc="M 2.2 - Validate categorical columns"):
            if df_train[col_name].isnull().any():
                raise ValueError(f"Categorical column {col_name} contains missing values in train.")
            if df_test[col_name].isnull().any():
                raise ValueError(f"Categorical column {col_name} contains missing values in test.")

        # Расчет Gini для численных признаков
        records_numeric = []
        if num_features:
            records_numeric = powerstat_for_features_fast(
                df_tr=df_train, 
                df_te=df_test,
                target=target_column, 
                features=num_features,
                n_jobs=n_jobs
            )
        
        # Расчет Gini для категориальных признаков
        records_categorical = []
        if cat_features:
            records_categorical = powerstat_for_categorical_features(
                df_tr=df_train,
                df_te=df_test,
                target=target_column,
                features=cat_features,
                n_jobs=n_jobs
            )
        
        # Объединяем результаты
        all_records = records_numeric + records_categorical
        
        self.individual_features_gini = pd.DataFrame(
            all_records, 
            columns=["Feature", "PowerStat_Train", "PowerStat_Test", "Delta"]
        ).sort_values(by='PowerStat_Train')
        self.individual_features_powerstat = self.individual_features_gini
        
        # Добавляем колонку с типом признака для информативности
        feature_types = {}
        for f in num_features:
            feature_types[f] = 'numeric'
        for f in cat_features:
            feature_types[f] = 'categorical'
        self.individual_features_gini['Type'] = self.individual_features_gini['Feature'].map(feature_types)
        
        self.individual_features_gini["PowerStat_Train_flag"] = self.individual_features_gini["PowerStat_Train"].apply(self.assign_flag)
        self.individual_features_gini["PowerStat_Test_flag"] = self.individual_features_gini["PowerStat_Test"].apply(self.assign_flag)

        img_train = self.plot_gini_bar(self.individual_features_gini.sort_values(by='PowerStat_Train'), "PowerStat_Train", "PowerStat by Factor (Train)")
        img_test = self.plot_gini_bar(self.individual_features_gini.sort_values(by='PowerStat_Test'), "PowerStat_Test", "PowerStat by Factor (Test)")

        def count_flags(flag_series):
            return {
                "green": (flag_series == "green").sum(),
                "yellow": (flag_series == "yellow").sum(),
                "red": (flag_series == "red").sum()
            }

        train_flags = count_flags(self.individual_features_gini["PowerStat_Train_flag"])
        test_flags = count_flags(self.individual_features_gini["PowerStat_Test_flag"])

        signal_train = self.compute_signal(self.individual_features_gini["PowerStat_Train_flag"].tolist())
        signal_test = self.compute_signal(self.individual_features_gini["PowerStat_Test_flag"].tolist())

        self.test_signal = signal_test

        signal_html = f"""
        <p><b>Signal (Train):</b> <span style='color:{signal_train}; font-weight:bold'>{signal_train.upper()}</span></p>
        <p><b>Signal (Test):</b> <span style='color:{signal_test}; font-weight:bold'>{signal_test.upper()}</span></p>
        <p><b>Overall Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span> <i>(based on Test only)</i></p>
        <p><i>Численных признаков: {len(num_features)}, Категориальных признаков: {len(cat_features)}</i></p>
        """

        summary_table = f"""
        <table border="1" cellpadding="5" cellspacing="0">
            <tr><th>Dataset</th><th style='color:green'>Green</th><th style='color:orange'>Yellow</th><th style='color:red'>Red</th></tr>
            <tr><td>Train</td><td style='color:green'><b>{train_flags["green"]}</b></td><td style='color:orange'><b>{train_flags["yellow"]}</b></td><td style='color:red'><b>{train_flags["red"]}</b></td></tr>
            <tr><td>Test</td><td style='color:green'><b>{test_flags["green"]}</b></td><td style='color:orange'><b>{test_flags["yellow"]}</b></td><td style='color:red'><b>{test_flags["red"]}</b></td></tr>
        </table>
        """

        full_html = f"""
        <h4>PowerStat by Factors</h4>
        {signal_html}
        {summary_table}
        <br>
        <h5>PowerStat on Train</h5>
        <img src="data:image/png;base64,{img_train}">
        <h5>PowerStat on Test</h5>
        <img src="data:image/png;base64,{img_test}">
        <br>
        <h5>PowerStat Table</h5>
        {self.individual_features_gini.sort_values(by='PowerStat_Train')[['Feature', 'Type', 'PowerStat_Train', 'PowerStat_Test', 'Delta', 'PowerStat_Train_flag', 'PowerStat_Test_flag']].to_html(index=False, float_format="%.2f")}
        """
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": full_html}

# Реализация тестов M 2.4 Gini Dynamics и M 2.5 Gini Uplift
def determine_optimal_freq(dates: pd.Series, max_bins: int = 40) -> str:
    """
    Функция принимает на вход Series с датами и максимальное количество бинов.
    Определяет оптимальную частоту для группировки дат.

    Параметры:
        * dates (pd.Series): Series с датами.
        * max_bins (int): Максимальное количество бинов.

    Возвращает:
        * str: Оптимальная частота для группировки дат.
    """
    dates = pd.to_datetime(dates)
    total_days = (dates.max() - dates.min()).days
    if total_days <= 180:
        return "W"  # weekly
    elif total_days <= 365:
        return "M"  # monthly
    elif total_days <= 3 * 365:
        return "Q"  # quarterly
    else:
        return "A"  # annually

class M23_GiniDynamicsTest(BaseModelTest):
    """
    Класс для теста M 2.4: Gini Dynamics.

    Анализирует динамику коэффициента Gini по времени на обучающей и тестовой выборках.
    Цель — выявить деградацию модели или нестабильность качества прогноза во времени.

    Общая логика:
        1. Данные агрегируются по датам (по умолчанию — помесячно).
        2. Для каждого временного бакета рассчитывается:
            - Gini (%),
            - Количество наблюдений и событий,
            - Среднее значение целевой переменной,
            - Доверительные интервалы (95% и 99%).
        3. Строится график: динамика Gini + количество наблюдений.
        4. Выводится сигнал:
            - "red": если ≥50% временных бакетов имеют Gini < 35%,
            - "yellow": если ≥30% бакетов имеют Gini < 35%,
            - "green": в остальных случаях.

    Атрибуты:
        * test_signal (str): Итоговый цветовой сигнал ("green", "yellow", "red").

    Методы:
        * compute_confidence_interval(gini, n, alpha): Рассчитывает доверительный интервал Gini.
        * compute_table(df, date_column, score_column, target_column): Строит таблицу метрик по времени.
        * determine_signal(gini_values): Вычисляет итоговый сигнал по значению Gini.
        * plot_dynamics(df, title): Строит график динамики Gini и количества наблюдений.
        * run(df_train, df_test, date_column, score_column, target_column): Запускает тест и возвращает HTML-отчёт.
    """
    def __init__(self):
        super().__init__("M 2.3", "Gini Dynamics (quarterly)")

    def compute_confidence_interval(self, gini, n, alpha=0.05):
        """
        Вычисляет доверительный интервал для коэффициента Gini при заданном уровне значимости.

        Параметры:
            * gini (float): Значение коэффициента Gini.
            * n (int): Количество наблюдений.
            * alpha (float): Уровень значимости (по умолчанию 0.05 — 95% интервал).

        Возвращает:
            * Tuple[float, float]: Нижняя и верхняя границы доверительного интервала.
        """
        se = np.sqrt((gini * (1 - gini)) / n) if n > 0 else 0
        z = norm.ppf(1 - alpha / 2)
        return gini - z * se, gini + z * se

    def compute_table(self, df: pd.DataFrame, date_column: str, score_column: str, target_column: str) -> pd.DataFrame:
        """
        Группирует данные по времени и рассчитывает Gini, доверительные интервалы и прочие статистики.

        Параметры:
            * df (pd.DataFrame): Датафрейм с исходными данными.
            * date_column (str): Имя колонки с датами.
            * score_column (str): Имя колонки с прогнозами модели.
            * target_column (str): Имя колонки с фактическими метками.

        Возвращает:
            * pd.DataFrame: Таблица с динамикой Gini и сопутствующей статистикой.
        """
        df = df.copy()
        df[date_column] = pd.to_datetime(df[date_column])
        df.set_index(date_column, inplace=True)
        freq = "Q"  # квартальная агрегация
        grouped = df.groupby(pd.Grouper(freq=freq))

        stats = []
        for date, group in grouped:
            if len(group) == 0:
                continue
            n = len(group)
            y_true = group[target_column]
            y_score = group[score_column]
            if len(np.unique(y_true)) < 2:
                gini = 0
            else:
                auc = roc_auc_score(y_true, y_score)
                gini = 2 * auc - 1
            gini_95_low, gini_95_high = self.compute_confidence_interval(gini, n, alpha=0.05)
            gini_99_low, gini_99_high = self.compute_confidence_interval(gini, n, alpha=0.01)
            stats.append((date.to_period(freq).start_time.strftime("%d-%m-%Y"), n, y_true.sum(), y_true.mean(), gini * 100,
                          gini_95_low * 100, gini_95_high * 100,
                          gini_99_low * 100, gini_99_high * 100))

        return pd.DataFrame(stats, columns=[
            "Date", "Observations", "Events", "Mean Target", "Gini %",
            "CI 95% Low", "CI 95% High", "CI 99% Low", "CI 99% High"
        ])

    def compute_table_regression(self, df: pd.DataFrame, date_column: str, score_column: str, target_column: str) -> pd.DataFrame:
        """
        Регрессионный вариант таблицы динамики: использует нормализованный Gini вместо ROC-AUC.
        """
        df = df.copy()
        df[date_column] = pd.to_datetime(df[date_column])
        df.set_index(date_column, inplace=True)
        freq = "Q"
        grouped = df.groupby(pd.Grouper(freq=freq))

        stats = []
        for date, group in grouped:
            if len(group) == 0:
                continue
            n = len(group)
            y_true = group[target_column].to_numpy()
            y_score = group[score_column].to_numpy()
            try:
                g = float(gini_normalized(y_true, y_score))
            except Exception:
                g = 0.0
            gini_95_low, gini_95_high = self.compute_confidence_interval(g, n, alpha=0.05)
            gini_99_low, gini_99_high = self.compute_confidence_interval(g, n, alpha=0.01)
            stats.append((date.to_period(freq).start_time.strftime("%d-%m-%Y"), n, np.sum(y_true), np.mean(y_true), g * 100,
                          gini_95_low * 100, gini_95_high * 100,
                          gini_99_low * 100, gini_99_high * 100))

        return pd.DataFrame(stats, columns=[
            "Date", "Observations", "Events", "Mean Target", "Gini %",
            "CI 95% Low", "CI 95% High", "CI 99% Low", "CI 99% High"
        ])

    def _flag_for_gini(self, gini_pct: float) -> str:
        # Локальный флаг по кварталу
        if gini_pct < 15:
            return "red"
        elif gini_pct < 35:
            return "yellow"
        else:
            return "green"

    def plot_dynamics(self, df: pd.DataFrame, title: str, flags: List[str]) -> str:
        """
        Рисует динамику нормализованного/процентного Gini с 95% и 99% ДИ и количеством наблюдений.

        Возвращает base64 PNG.
        """
        # Подготовка данных: приводим дату и сортируем
        x = pd.to_datetime(df["Date"], dayfirst=True, errors='coerce')
        work = df.copy()
        work["_x"] = x
        work = work.sort_values("_x").reset_index(drop=True)

        # Приводим к масштабу 0..1 (исходно у нас проценты 0..100)
        g = work["Gini %"].astype(float) / 100.0
        ci95_low = work["CI 95% Low"].astype(float) / 100.0
        ci95_high = work["CI 95% High"].astype(float) / 100.0
        ci99_low = work["CI 99% Low"].astype(float) / 100.0
        ci99_high = work["CI 99% High"].astype(float) / 100.0

        # Чтобы заливки были непрерывными, интерполируем возможные пропуски
        for col in [g, ci95_low, ci95_high, ci99_low, ci99_high]:
            # col — это Series view; создадим интерполированные версии в work
            pass
        work["g"] = g.interpolate(method="linear", limit_area="inside").ffill().bfill()
        work["ci95_low"] = ci95_low.interpolate(method="linear", limit_area="inside").ffill().bfill()
        work["ci95_high"] = ci95_high.interpolate(method="linear", limit_area="inside").ffill().bfill()
        work["ci99_low"] = ci99_low.interpolate(method="linear", limit_area="inside").ffill().bfill()
        work["ci99_high"] = ci99_high.interpolate(method="linear", limit_area="inside").ffill().bfill()

        fig, ax1 = plt.subplots(figsize=(14, 6))
        ax2 = ax1.twinx()

        # Цвета
        color_gini = COLORS['BLUE']
        color_ci_95 = COLORS['YELLOW']
        color_ci_99 = COLORS['RED']
        color_bars = COLORS['EMERALD']

        # Столбики количества наблюдений
        ax2.bar(work["_x"], work["Observations"], alpha=0.6, color=color_bars, label=OBSERVATION_COUNT_LABEL)

        # Заливки доверительных интервалов (сначала широкий 99%, затем 95%)
        ax1.fill_between(work["_x"], work["ci99_low"], work["ci99_high"], alpha=0.3, color=color_ci_99, label='99% CI')
        ax1.fill_between(work["_x"], work["ci95_low"], work["ci95_high"], alpha=0.5, color=color_ci_95, label='95% CI')

        # Основная линия Gini (0..1)
        ax1.plot(work["_x"], work["g"], color=COLORS['GRAY'], linewidth=2, marker='o', markersize=4, label='Normalized Gini')

        # Подписи значений (ограничим до 50 точек, чтобы не захламлять)
        if len(work) <= 50:
            for _, row in work.iterrows():
                ax1.annotate(f"{row['g']:.3f}", (row["_x"], row['g']), textcoords="offset points", xytext=(0, 8), ha='center', fontsize=8, fontweight='bold')

        # Пороговые линии 0.15 и 0.35
        ax1.axhline(y=0.15, color=STATUS_COLORS['red'], linestyle='--', alpha=0.7, label='15% Threshold')
        ax1.axhline(y=0.35, color=STATUS_COLORS['orange'], linestyle='--', alpha=0.7, label='35% Threshold')

        # Красные звёздочки на точках с красным флагом
        # Сопоставим флаги с work по порядку (df передаётся уже отсортированным)
        red_x = []
        red_y = []
        for i, row in work.iterrows():
            if i < len(flags) and flags[i] == 'red':
                red_x.append(row["_x"]) 
                red_y.append(row["g"]) 
        if red_x:
            ax1.scatter(red_x, red_y, marker='*', color=STATUS_COLORS['red'], s=120, zorder=5, label='Red flag')

        # Подписи и стили
        ax1.set_xlabel('Period', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Normalized Gini', fontsize=12, fontweight='bold', color=color_gini)
        ax2.set_ylabel('Observations', fontsize=12, fontweight='bold', color=color_bars)
        ax1.tick_params(axis='y', labelcolor=color_gini)
        ax2.tick_params(axis='y', labelcolor=color_bars)

        # Формат оси X: месяцы по умолчанию
        ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=1))
        plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha='right')

        ax1.set_title(title, fontsize=14, fontweight='bold', pad=16)

        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', frameon=False)

        ax1.grid(True, alpha=0.3)
        plt.tight_layout()

        buf = BytesIO()
        plt.savefig(buf, format="png")
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, df: pd.DataFrame, config: dict) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        df_train, df_test, _ = split_frames(df, cfg)
        date_column = cfg.columns.date_column
        target_column = cfg.columns.target_column
        score_column  = get_score_col(cfg)

        # Прежние проверки типов/NaN
        for column in [score_column, target_column]:
            if not pd.api.types.is_numeric_dtype(df_train[column]) or not pd.api.types.is_numeric_dtype(df_test[column]):
                try:
                    df_train[column] = pd.to_numeric(df_train[column], errors='raise')
                    df_test[column] = pd.to_numeric(df_test[column], errors='raise')
                except ValueError:
                    raise ValueError(f"Столбец {column} не является числовым. Перевод в числовой тип невозможен.")
            if df_train[column].isnull().any() or df_test[column].isnull().any():
                raise ValueError(f"Столбец {column} содержит пропущенные значения.")

        if is_binary_mode(cfg):
            table_train = self.compute_table(df_train, date_column, score_column, target_column)
            table_test  = self.compute_table(df_test,  date_column, score_column, target_column)
        else:
            table_train = self.compute_table_regression(df_train, date_column, score_column, target_column)
            table_test  = self.compute_table_regression(df_test,  date_column, score_column, target_column)

        # Флаги по кварталам
        flags_train = [self._flag_for_gini(float(v)) for v in table_train["Gini %"].tolist()]
        flags_test  = [self._flag_for_gini(float(v)) for v in table_test["Gini %"].tolist()]

        # Доли срезов и доли наблюдений по цветам
        def fractions(flags: List[str], obs: List[float]):
            total = max(1, len(flags))
            red_frac = sum(1 for f in flags if f == 'red') / total
            yellow_frac = sum(1 for f in flags if f == 'yellow') / total
            obs_sum = max(1.0, float(sum(obs)))
            red_obs = float(sum(o for f, o in zip(flags, obs) if f == 'red')) / obs_sum
            yellow_obs = float(sum(o for f, o in zip(flags, obs) if f == 'yellow')) / obs_sum
            return red_frac, yellow_frac, red_obs, yellow_obs

        r_tr, y_tr, r_tr_obs, y_tr_obs = fractions(flags_train, table_train["Observations"].astype(float).tolist())
        r_te, y_te, r_te_obs, y_te_obs = fractions(flags_test,  table_test["Observations"].astype(float).tolist())

        # Итоговый светофор
        # RED если в train или test: >30% красных срезов ИЛИ >30% наблюдений в красных
        if (r_tr > 0.3 or r_tr_obs > 0.3) or (r_te > 0.3 or r_te_obs > 0.3):
            overall = 'red'
        else:
            # GREEN если (в обоих) доли жёлтых < 30% и доли наблюдений в жёлтых < 30%
            if (y_tr < 0.3 and y_tr_obs < 0.3) and (y_te < 0.3 and y_te_obs < 0.3):
                overall = 'green'
            else:
                overall = 'yellow'

        self.test_signal = overall

        plot_train = self.plot_dynamics(table_train, "Gini Dynamics (Quarterly) - Train", flags_train)
        plot_test  = self.plot_dynamics(table_test,  "Gini Dynamics (Quarterly) - Test", flags_test)

        signal_html = f"""
        <p><b>Train:</b> RED-slices={r_tr:.0%}, RED-obs={r_tr_obs:.0%}; YELLOW-slices={y_tr:.0%}, YELLOW-obs={y_tr_obs:.0%}</p>
        <p><b>Test:</b>  RED-slices={r_te:.0%}, RED-obs={r_te_obs:.0%}; YELLOW-slices={y_te:.0%}, YELLOW-obs={y_te_obs:.0%}</p>
        <p><b>Overall Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>{self.test_signal.upper()}</span></p>
        <p>Rules: RED if >30% red slices OR >30% obs in red; GREEN if in both Train and Test yellow <30% and yellow-obs <30%; else YELLOW.</p>
        """

        html = f"""
    <h4>Gini Dynamics (Quarterly)</h4>
        {signal_html}
        <h5>Train</h5>
        <img src="data:image/png;base64,{plot_train}">
        {table_train.to_html(index=False, float_format="%.2f")}
        <br>
        <h5>Test</h5>
        <img src="data:image/png;base64,{plot_test}">
        {table_test.to_html(index=False, float_format="%.2f")}
        """
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"DASHBOARD": html}

class M24_GiniUpliftTest(BaseModelTest):
    """
    Класс для теста M 2.5: Gini Uplift.

    Оценивает инкрементальный прирост Gini при пошаговом добавлении признаков в логистическую регрессию.
    Используется для определения важности факторов в контексте всей модели.

    Общая логика:
        1. Вычисляется индивидуальный Gini каждого признака (или используется из M22).
        2. Строится логистическая модель с признаками, добавляемыми по одному в заданном порядке.
        3. На каждом шаге оценивается прирост Gini на train относительно предыдущего шага.
        4. Признаку присваивается флаг:
            - "green" — если прирост > 0.1%,
            - "yellow" — если прирост > 0,
            - "red" — если прирост ≤ 0.
        5. Выводится общий сигнал:
            - "red" — если есть хотя бы один "red" или ≥ 40% признаков "yellow",
            - "yellow" — если ≥ 20% признаков "yellow",
            - "green" — в остальных случаях.
        6. Формируется диаграмма и таблица результатов.

    Атрибуты:
        * test_signal (str): Итоговый сигнал ("green", "yellow", "red").

    Методы:
        * compute_uplift_flag(uplift_val): Присваивает флаг признаку по значению прироста Gini.
        * _plot_uplift_bar(df): Строит график прироста Gini (столбики + линии).
        * run(df_train, df_test, target_column, feature_order, n_jobs, m22_test_object): Запускает тест, возвращает HTML-отчёт.
    """
    def __init__(self):
        super().__init__("M 2.4", "PowerStat Uplift")

    def compute_uplift_flag(self, uplift_val:float) -> str:
        """
        Присваивает цветовой флаг в зависимости от величины прироста Gini:
            - "green": прирост > 0.1%
            - "yellow": 0% < прирост ≤ 0.1%
            - "red": прирост ≤ 0%

        Параметры:
            * uplift_val (float): Прирост Gini.

        Возвращает:
            * str: Цвет флага.
        """
        if uplift_val > 0.001:
            return "green"
        elif uplift_val > 0:
            return "yellow"
        else:
            return 'red'

    @staticmethod
    def _prepare_uplift_plot_frame(df: pd.DataFrame) -> pd.DataFrame:
        plot_df = df.copy()
        if "Single PowerStat" in plot_df.columns:
            plot_df["Single PowerStat Display"] = plot_df["Single PowerStat"].abs()
        if "Single Gini" in plot_df.columns:
            plot_df["Single Gini Display"] = plot_df["Single Gini"].abs()
        return plot_df
         
    def _plot_uplift_bar(self, df: pd.DataFrame) -> str:
        """
        Строит график в стиле PowerStat:
            • Столбики: накопленный Gini Test по модели нарастающим итогом;
              светло-зелёная база = предыдущий уровень, тёмно-зелёная "шапка" = инкрементальный прирост.
            • Линия: Gini одиночного признака (серые точки со ссылкой).

        Параметры:
            * df (pd.DataFrame): Таблица с рассчитанными приростами Gini.

        Возвращает:
            * str: Base64-строка с изображением графика.
        """
        plot_df = self._prepare_uplift_plot_frame(df)
        n = len(plot_df)
        fig_w = max(8.0, min(2.5 + 0.6 * n, 28.0))
        fig, ax = plt.subplots(figsize=(fig_w, 5.8))

        x = np.arange(n)
        model_test_col = "Model Test PowerStat" if "Model Test PowerStat" in plot_df.columns else "Model Test Gini"
        uplift_col = "PowerStat Uplift" if "PowerStat Uplift" in plot_df.columns else "Gini Uplift"
        single_display_col = (
            "Single PowerStat Display"
            if "Single PowerStat Display" in plot_df.columns
            else "Single Gini Display"
        )
        # Накопленные значения Gini Test по шагах (в df уже в %)
        cum_test = plot_df[model_test_col].to_numpy()
        prev_test = np.concatenate([[0.0], cum_test[:-1]])
        uplift = plot_df[uplift_col].to_numpy()

        # База (предыдущий уровень)
        ax.bar(x, prev_test, color=COLORS['EMERALD'], alpha=0.26, width=0.8)
        # Шапка (инкремент)
        ax.bar(x, uplift, bottom=prev_test, color=COLORS['GREEN'], width=0.8, label="Increment")

        # Линия одиночного Gini (точки серые)
        ax.plot(
            x,
            plot_df[single_display_col],
            color=COLORS['BLUE'],
            marker="o",
            markersize=5.5,
            linewidth=1.8,
            label="Single PowerStat",
        )

        # Оси/подписи
        short_labels = [(f[:22] + "…") if len(f) > 25 else f for f in df["Feature"]]
        short_labels = [(f[:22] + "...") if len(f) > 25 else f for f in plot_df["Feature"]]
        ax.set_xticks(x)
        ax.set_xticklabels(short_labels, rotation=45, ha="right", fontsize=8)
        apply_standard_axis_style(
            ax,
            title="Incremental PowerStat Gain by Sequential Feature Addition",
            ylabel="PowerStat, %",
            legend_loc="upper left",
            title_size=12,
        )
        fig.tight_layout(pad=1.2)

        # ----- экспорт --------------------------------------------------------
        buf = BytesIO()
        plt.savefig(buf, format="png", dpi=150)
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode()

    def run(self, df: pd.DataFrame, config: dict, n_jobs=-1, m22_test_object: "M22_GiniFactorsTest" = None) -> Dict[str, str]:
        logger.info(f"Test {self.test_code} {self.test_name}: starting")
        cfg = ensure_config(config, df)
        if is_generic_classification_mode(cfg):
            self.test_signal = "blue"
            return _classification_mode_na(self.test_name)
        df_train, df_test, _ = split_frames(df, cfg)
        target_column = cfg.columns.target_column
        
        # Получаем и численные, и категориальные признаки
        num_features = cfg.columns.numeric_features or []
        cat_features = cfg.columns.categorical_features or []
        
        all_features = num_features + cat_features
        if not all_features:
            raise ConfigValidationError(["Для M 2.5 требуется непустой список columns.numeric_features или columns.categorical_features"])

        # Проверки типов/NaN для численных признаков
        for column in num_features + [target_column]:
            if not pd.api.types.is_numeric_dtype(df_train[column]) or not pd.api.types.is_numeric_dtype(df_test[column]):
                try:
                    df_train[column] = pd.to_numeric(df_train[column], errors='raise')
                    df_test[column] = pd.to_numeric(df_test[column], errors='raise')
                except ValueError:
                    raise ValueError(f"Column {column} must be numeric.")
        if df_train[target_column].isnull().any() or df_test[target_column].isnull().any():
            raise ValueError("Target contains missing values.")
        
        # Проверки для категориальных признаков
        for column in cat_features:
            if df_train[column].isnull().any() or df_test[column].isnull().any():
                raise ValueError(f"Categorical column {column} contains missing values.")

        # Получаем individual gini из M22 или считаем заново
        if m22_test_object and not m22_test_object.individual_features_gini.empty:
            self.individual_features_gini = m22_test_object.individual_features_gini
        else:
            # Считаем заново
            records_numeric = []
            if num_features:
                records_numeric = powerstat_for_features_fast(
                    df_tr=df_train, 
                    df_te=df_test,
                    target=target_column, 
                    features=num_features,
                    n_jobs=n_jobs
                )
            
            records_categorical = []
            if cat_features:
                records_categorical = powerstat_for_categorical_features(
                    df_tr=df_train,
                    df_te=df_test,
                    target=target_column,
                    features=cat_features,
                    n_jobs=n_jobs
                )
            
            all_records = records_numeric + records_categorical
            self.individual_features_gini = pd.DataFrame(
                all_records, 
                columns=["Feature", "PowerStat_Train", "PowerStat_Test", "Delta"]
            )

        # Упорядочим признаки по убыванию индивидуального Gini (Train)
        order_df = self.individual_features_gini.sort_values(by="PowerStat_Train", ascending=False)
        ordered_features = [f for f in order_df["Feature"].tolist() if f in all_features]

        # Создаем маппинг: какой признак численный, какой категориальный
        feature_type_map = {}
        for f in num_features:
            feature_type_map[f] = 'numeric'
        for f in cat_features:
            feature_type_map[f] = 'categorical'

        # Подготавливаем данные: будем строить матрицу пошагово
        y_tr = df_train[target_column].to_numpy(np.float32)
        y_ts = df_test[target_column].to_numpy(np.float32)

        # Создаем энкодинг для категориальных признаков (mean target encoding)
        categorical_encodings = {}
        for cat_feat in cat_features:
            encoding_map = df_train.groupby(cat_feat)[target_column].mean().to_dict()
            global_mean = df_train[target_column].mean()
            categorical_encodings[cat_feat] = (encoding_map, global_mean)

        # Функция для получения закодированного признака
        def get_encoded_feature(feat_name, df_tr_local, df_te_local):
            if feature_type_map[feat_name] == 'numeric':
                return (
                    df_tr_local[feat_name].to_numpy(np.float32),
                    df_te_local[feat_name].to_numpy(np.float32)
                )
            else:
                # Категориальный: применяем mean encoding
                encoding_map, global_mean = categorical_encodings[feat_name]
                tr_encoded = df_tr_local[feat_name].map(encoding_map).fillna(global_mean).to_numpy(np.float32)
                te_encoded = df_te_local[feat_name].map(encoding_map).fillna(global_mean).to_numpy(np.float32)
                return tr_encoded, te_encoded

        # Собираем полную матрицу для обучения модели
        X_tr_list = []
        X_ts_list = []
        for feat in ordered_features:
            tr_feat, ts_feat = get_encoded_feature(feat, df_train, df_test)
            X_tr_list.append(tr_feat)
            X_ts_list.append(ts_feat)
        
        X_tr_full = np.column_stack(X_tr_list).astype(np.float32)
        X_ts_full = np.column_stack(X_ts_list).astype(np.float32)

        records = []

        if is_binary_mode(cfg):
            # Логистическая регрессия с инкрементальным добавлением признаков
            model = LogisticRegression(solver='saga', max_iter=1000)
            model.fit(X_tr_full, y_tr)
            beta0 = np.float32(model.intercept_[0])
            betas = model.coef_[0].astype(np.float32)
            logits_tr = np.full(len(X_tr_full), beta0, dtype=np.float32)
            logits_ts = np.full(len(X_ts_full), beta0, dtype=np.float32)

            for i, feat in tqdm(list(enumerate(ordered_features)), desc="M 2.4 - Logistic steps", total=len(ordered_features)):
                logits_tr += X_tr_full[:, i] * betas[i]
                logits_ts += X_ts_full[:, i] * betas[i]
                pred_tr = expit(logits_tr)
                pred_ts = expit(logits_ts)
                ps_tr = powerstat_value(y_tr, pred_tr)
                ps_ts = powerstat_value(y_ts, pred_ts)
                uplift = ps_tr - records[i - 1][3] / 100 if i > 0 else ps_tr
                uplift_flag = self.compute_uplift_flag(uplift)
                ps_single = self.individual_features_gini[self.individual_features_gini["Feature"] == feat]["PowerStat_Train"].iloc[0] / 100
                feat_type = feature_type_map[feat]
                records.append((feat, feat_type, ps_ts * 100, ps_tr * 100, abs(ps_single) * 100, uplift * 100, uplift_flag))
        else:
            # Регрессия: пошаговое обучение LinearRegression
            scaler = StandardScaler(with_mean=True, with_std=True)
            X_tr_scaled = scaler.fit_transform(X_tr_full)
            X_ts_scaled = scaler.transform(X_ts_full)
            
            for i, feat in tqdm(list(enumerate(ordered_features)), desc="M 2.4 - Linear steps", total=len(ordered_features)):
                lr = LinearRegression(n_jobs=n_jobs) if hasattr(LinearRegression(), 'n_jobs') else LinearRegression()
                Xtr = X_tr_scaled[:, : i + 1]
                Xts = X_ts_scaled[:, : i + 1]
                lr.fit(Xtr, y_tr)
                pred_tr = lr.predict(Xtr)
                pred_ts = lr.predict(Xts)
                ps_tr = powerstat_value(y_tr, pred_tr)
                ps_ts = powerstat_value(y_ts, pred_ts)
                uplift = ps_tr - records[i - 1][3] / 100 if i > 0 else ps_tr
                uplift_flag = self.compute_uplift_flag(uplift)
                ps_single = self.individual_features_gini[self.individual_features_gini["Feature"] == feat]["PowerStat_Train"].iloc[0] / 100 if not self.individual_features_gini.empty else 0.0
                feat_type = feature_type_map[feat]
                records.append((feat, feat_type, ps_ts * 100, ps_tr * 100, abs(ps_single) * 100, uplift * 100, uplift_flag))

        df_result = pd.DataFrame(
            records, 
            columns=["Feature", "Type", "Model Test PowerStat", "Model Train PowerStat", "Single PowerStat", "PowerStat Uplift", "Uplift Signal"]
        )

        # График прироста
        encoded_plot = self._plot_uplift_bar(df_result)
        
        self.test_signal = "blue"

        html = f"""
        <h4>PowerStat Uplift</h4>
        <p><b>Signal:</b> <span style='color:{self.test_signal}; font-weight:bold'>INFO</span></p>
        <p><i>Numeric features: {len(num_features)}, categorical features: {len(cat_features)}</i></p>
        <p><i>This test is informational and shows the sequential incremental PowerStat contribution of each factor.</i></p>
        <p><i>Categorical features are encoded via mean target encoding.</i></p>
        <img src="data:image/png;base64,{encoded_plot}" style="display:block; width:100%; max-width:1100px; height:auto;">
        <h5>Details</h5>
        {df_result.to_html(index=False, float_format="%.2f")}
        """
        _log_text = {'red':'red','yellow':'yellow','green':'green','orange':'yellow','blue':'info','gray':'info'}.get(self.test_signal, str(self.test_signal))
        logger.info(f"Test {self.test_code} {self.test_name}: finished (signal={self.test_signal})")
        return {"combined": html}
