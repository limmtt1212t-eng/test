"""Compatibility wrapper for `tests_blackbox.m6_stability_tests`."""

from .tests_blackbox.m6_stability_tests import *  # noqa: F401,F403
