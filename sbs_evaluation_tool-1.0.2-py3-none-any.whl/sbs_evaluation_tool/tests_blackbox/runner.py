"""BlackBox PD methodology runner.

The runner follows `archive/Часть_100_PD_модели_BlackBox.md` and intentionally
keeps SHAP/permutation tests disabled in lightweight mode.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd

from ..core.base_test import ModelReportBuilder, TestGroupBuilder
from ..core.config_validation import validate_config
from .methodology_tests import (
    BBM11_SampleConsistencyTest,
    BBM12_SampleRepresentativenessTest,
    BBM13_DataFreshnessTest,
    BBM14_ControlChecksPlaceholder,
    BBM15_MissingExtremeValuesPlaceholder,
    BBM21_RankingEfficiencyTest,
    BBM22_GiniConfidenceIntervalTest,
    BBM23_GiniDynamicsTest,
    BBM31_PermutationImportanceSkipped,
    BBM32_ShapImportanceSkipped,
    BBM41_TargetRateCalibrationTest,
    BBM42_CalibrationCurveShapeTest,
    BBM51_RankingStabilityTest,
    BBM52_ScoreDistributionStabilityTest,
)


def _sanitize(name: str) -> str:
    return "".join(ch if (str(ch).isalnum() or ch in ("-", "_", ".")) else "_" for ch in str(name))


def run_sbs_blackbox_evaluation(
    data: pd.DataFrame,
    config: dict,
    segment_name: str = "blackbox_pd",
    output_dir: str = "reports",
    include_heavy: bool = False,
) -> str:
    """Run the lightweight BlackBox PD validation suite and write an HTML report.

    Parameters
    ----------
    data:
        Validation dataframe.
    config:
        SBS config. Expected task/model mode is binary/classification.
    segment_name:
        Prefix for the report filename.
    output_dir:
        Report output directory.
    include_heavy:
        Reserved for future SHAP/permutation implementation. Currently heavy
        tests remain explicit INFO/skipped placeholders.
    """

    cfg = validate_config(config, data)

    group_m1 = TestGroupBuilder("M1", "M1. Data Quality")
    group_m1.add_test(BBM11_SampleConsistencyTest())
    group_m1.add_test(BBM12_SampleRepresentativenessTest())
    group_m1.add_test(BBM13_DataFreshnessTest())
    group_m1.add_test(BBM14_ControlChecksPlaceholder())
    group_m1.add_test(BBM15_MissingExtremeValuesPlaceholder())
    params_m1 = {
        "M 1.1": {"df": data, "config": config},
        "M 1.2": {"df": data, "config": config},
        "M 1.3": {"df": data, "config": config},
        "M 1.4": {"df": data, "config": config},
        "M 1.5": {"df": data, "config": config},
    }

    group_m2 = TestGroupBuilder("M2", "M2. Algorithm Quality")
    group_m2.add_test(BBM21_RankingEfficiencyTest())
    group_m2.add_test(BBM22_GiniConfidenceIntervalTest())
    group_m2.add_test(BBM23_GiniDynamicsTest())
    params_m2 = {
        "M 2.1": {"df": data, "config": config},
        "M 2.2": {"df": data, "config": config},
        "M 2.3": {"df": data, "config": config},
    }

    group_m3 = TestGroupBuilder("M3", "M3. Model Specification")
    group_m3.add_test(BBM31_PermutationImportanceSkipped())
    group_m3.add_test(BBM32_ShapImportanceSkipped())
    params_m3 = {
        "M 3.1": {"df": data, "config": config},
        "M 3.2": {"df": data, "config": config},
    }
    if include_heavy:
        print("BlackBox heavy tests are not implemented yet; M3 remains INFO/skipped.")

    group_m4 = TestGroupBuilder("M4", "M4. Calibration")
    group_m4.add_test(BBM41_TargetRateCalibrationTest())
    group_m4.add_test(BBM42_CalibrationCurveShapeTest())
    params_m4 = {
        "M 4.1": {"df": data, "config": config},
        "M 4.2": {"df": data, "config": config},
    }

    group_m5 = TestGroupBuilder("M5", "M5. Stability")
    group_m5.add_test(BBM51_RankingStabilityTest())
    group_m5.add_test(BBM52_ScoreDistributionStabilityTest())
    params_m5 = {
        "M 5.1": {"df": data, "config": config},
        "M 5.2": {"df": data, "config": config},
    }

    report = ModelReportBuilder()
    for group, params in [
        (group_m1, params_m1),
        (group_m2, params_m2),
        (group_m3, params_m3),
        (group_m4, params_m4),
        (group_m5, params_m5),
    ]:
        print(f"... Running group {group.group_name}")
        group.run_all_tests(params)
        report.add_group(group)

    html = report.generate_html()
    out_path_dir = Path(output_dir)
    if not out_path_dir.is_absolute():
        out_path_dir = Path.cwd() / out_path_dir
    out_path_dir.mkdir(parents=True, exist_ok=True)

    score_name = cfg.columns.score_column or cfg.columns.prediction_column or "score"
    today = datetime.now().strftime("%d_%m_%Y")
    out_path = out_path_dir / f"{_sanitize(segment_name)}_blackbox_{_sanitize(score_name)}_{today}.html"
    out_path.write_text(html, encoding="utf-8")
    print(f"BlackBox report saved: {out_path}")
    return str(out_path)
