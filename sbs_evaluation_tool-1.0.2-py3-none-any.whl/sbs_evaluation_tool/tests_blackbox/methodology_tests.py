"""Methodology-aligned BlackBox PD test classes.

This module maps the archived BlackBox PD methodology to the current library
without enabling heavy tests such as permutation importance or SHAP by default.
"""
from __future__ import annotations

import math
from typing import Dict, Optional

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from ..core.base_test import BaseModelTest
from ..core.config_validation import ConfigValidationError, validate_config
from ..core.data_utils import split_frames
from .m1_sampling_tests import (
    M11_SampleConsistencyTest,
    M12_DataFreshnessTest,
    M13_SplitRandomnessTest,
)
from .m2_classification_tests import M21_GiniOverallTest, M23_GiniDynamicsTest
from .m4_calibration_tests import M41_PredictedVsActualLevelTest
from .m9_visual_tests import M94_CalibrationCurveTest
from .m6_stability_tests import M61_StabilityKeyMetricTest
from .psi_calculator import PSICalculatorExtended


def _score_col(cfg) -> Optional[str]:
    return cfg.columns.score_column or cfg.columns.prediction_column


def _binary_gini(y_true: pd.Series, y_score: pd.Series) -> float:
    y = pd.Series(y_true).reset_index(drop=True)
    s = pd.to_numeric(pd.Series(y_score), errors="coerce").reset_index(drop=True)
    mask = y.notna() & s.notna()
    y = y[mask]
    s = s[mask]
    if y.nunique(dropna=True) < 2:
        return float("nan")
    return float(2.0 * roc_auc_score(y, s) - 1.0)


class BBM11_SampleConsistencyTest(M11_SampleConsistencyTest):
    """M1.1. Train/test split quality."""

    def __init__(self):
        super().__init__()
        self.test_code = "M 1.1"
        self.test_name = "Sample Split Quality"


class BBM12_SampleRepresentativenessTest(M13_SplitRandomnessTest):
    """M1.2. Sample representativeness by model factors.

    Uses the existing split-predictability check as a practical proxy: if model
    factors can predict train vs validation membership, the validation sample is
    not representative enough.
    """

    def __init__(self, k_folds: int = 4):
        super().__init__(k_folds=k_folds)
        self.test_code = "M 1.2"
        self.test_name = "Sample Representativeness by Factors"


class BBM13_DataFreshnessTest(M12_DataFreshnessTest):
    """M1.3. Data freshness."""

    def __init__(self):
        super().__init__()
        self.test_code = "M 1.3"
        self.test_name = "Data Freshness"


class BBM14_ControlChecksPlaceholder(BaseModelTest):
    """M1.4. Control checklist coverage.

    The methodology requires a business/control checklist. The current library
    has no stable schema for that checklist, so the test is explicit INFO rather
    than a silent omission.
    """

    def __init__(self):
        super().__init__("M 1.4", "Control Checklist Coverage")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        self.test_signal = "blue"
        return {
            "DASHBOARD": (
                "<h4>M1.4 Control Checklist Coverage</h4>"
                "<p><b>INFO:</b> control-check schema is not configured yet. "
                "Add an explicit checklist contract before turning this into a "
                "traffic-light test.</p>"
            )
        }


class BBM15_MissingExtremeValuesPlaceholder(BaseModelTest):
    """M1.5. Missing and extreme values, informational."""

    def __init__(self):
        super().__init__("M 1.5", "Missing and Extreme Values")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            self.test_signal = "blue"
            return {"DASHBOARD": f"<h4>M1.5 skipped</h4><p>{'; '.join(e.errors)}</p>"}

        features = list(cfg.columns.numeric_features or []) + list(cfg.columns.categorical_features or [])
        features = [f for f in dict.fromkeys(features) if f in df.columns]
        rows = []
        for feature in features:
            s = df[feature]
            missing_share = float(s.isna().mean())
            extreme_share = float("nan")
            if pd.api.types.is_numeric_dtype(s):
                x = pd.to_numeric(s, errors="coerce").dropna()
                if x.size >= 4:
                    q1, q3 = np.percentile(x, [25, 75])
                    iqr = q3 - q1
                    if iqr > 0:
                        lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
                        extreme_share = float(((x < lo) | (x > hi)).mean())
            rows.append(
                {
                    "feature": feature,
                    "missing_share": missing_share,
                    "extreme_share": extreme_share,
                }
            )

        self.test_signal = "blue"
        table = pd.DataFrame(rows).to_html(index=False, float_format="%.4f") if rows else "<p>No features configured.</p>"
        return {
            "DASHBOARD": (
                "<h4>M1.5 Missing and Extreme Values</h4>"
                "<p><b>INFO:</b> informational test; traffic light is not assigned.</p>"
                f"{table}"
            )
        }


class BBM21_RankingEfficiencyTest(M21_GiniOverallTest):
    """M2.1. Overall ranking efficiency."""

    def __init__(self, n_bootstrap: int = 300):
        super().__init__(n_bootstrap=n_bootstrap)
        self.test_code = "M 2.1"
        self.test_name = "Overall Ranking Efficiency"


class BBM22_GiniConfidenceIntervalTest(BaseModelTest):
    """M2.2. Confidence interval for key Gini metric."""

    def __init__(self, n_bootstrap: int = 300, random_state: int = 42):
        super().__init__("M 2.2", "Gini Confidence Interval")
        self.n_bootstrap = int(n_bootstrap)
        self.random_state = int(random_state)

    def _bootstrap_ci(self, y: pd.Series, score: pd.Series) -> tuple[float, float, float]:
        gini = _binary_gini(y, score)
        if math.isnan(gini):
            return float("nan"), float("nan"), float("nan")
        rng = np.random.RandomState(self.random_state)
        vals = []
        y = pd.Series(y).reset_index(drop=True)
        score = pd.Series(score).reset_index(drop=True)
        n = len(y)
        for _ in range(self.n_bootstrap):
            idx = rng.randint(0, n, n)
            vals.append(_binary_gini(y.iloc[idx], score.iloc[idx]))
        arr = np.array([v for v in vals if np.isfinite(v)])
        if arr.size == 0:
            return gini, float("nan"), float("nan")
        return gini, float(np.percentile(arr, 2.5)), float(np.percentile(arr, 97.5))

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<h4>M2.2 skipped</h4><p>{'; '.join(e.errors)}</p>"}

        if cfg.task != "classification":
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M2.2 skipped</h4><p>PD BlackBox Gini CI is classification-only.</p>"}

        score_col = _score_col(cfg)
        target_col = cfg.columns.target_column
        if not score_col or score_col not in df.columns or target_col not in df.columns:
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M2.2 skipped</h4><p>Score or target column is missing.</p>"}

        sections = []
        rows = []
        try:
            frames = split_frames(df, cfg)
            sample_items = [("train", frames[0]), ("test", frames[1])]
        except Exception:
            sample_items = [("all", df)]

        worst = "green"
        for label, part in sample_items:
            if part is None or part.empty:
                continue
            gini, lo, hi = self._bootstrap_ci(part[target_col], part[score_col])
            gini_pct = gini * 100.0 if np.isfinite(gini) else float("nan")
            lo_pct = lo * 100.0 if np.isfinite(lo) else float("nan")
            hi_pct = hi * 100.0 if np.isfinite(hi) else float("nan")
            if not np.isfinite(gini_pct):
                signal = "orange"
            elif gini_pct < 20.0 and (not np.isfinite(hi_pct) or hi_pct < 20.0):
                signal = "red"
            elif gini_pct < 40.0:
                signal = "orange"
            else:
                signal = "green"
            if signal == "red":
                worst = "red"
            elif signal == "orange" and worst != "red":
                worst = "orange"
            rows.append(
                {
                    "sample": label,
                    "gini_pct": gini_pct,
                    "ci_95_low_pct": lo_pct,
                    "ci_95_high_pct": hi_pct,
                    "n": len(part),
                    "signal": signal,
                }
            )

        self.test_signal = worst
        table = pd.DataFrame(rows).to_html(index=False, float_format="%.3f") if rows else "<p>No valid samples.</p>"
        sections.append(
            f"<h4>M2.2 Gini Confidence Interval</h4>"
            f"<p>Bootstrap iterations: <b>{self.n_bootstrap}</b></p>"
            f"{table}"
        )
        return {"DASHBOARD": "".join(sections)}


class BBM23_GiniDynamicsTest(M23_GiniDynamicsTest):
    """M2.3. Gini dynamics."""

    def __init__(self, freq: str = "M", n_bootstrap: int = 200, min_events: int = 50):
        super().__init__(freq=freq, n_bootstrap=n_bootstrap, min_events=min_events)
        self.test_code = "M 2.3"
        self.test_name = "Gini Dynamics"


class BBM31_PermutationImportanceSkipped(BaseModelTest):
    """M3.1. Heavy permutation test placeholder."""

    def __init__(self):
        super().__init__("M 3.1", "Permutation Feature Significance")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        self.test_signal = "blue"
        return {
            "DASHBOARD": (
                "<h4>M3.1 Permutation Feature Significance</h4>"
                "<p><b>Skipped:</b> heavy permutation test is intentionally not "
                "enabled in the lightweight BlackBox runner.</p>"
            )
        }


class BBM32_ShapImportanceSkipped(BaseModelTest):
    """M3.2. Heavy SHAP comparison placeholder."""

    def __init__(self):
        super().__init__("M 3.2", "SHAP Importance Train/Test Comparison")

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        self.test_signal = "blue"
        return {
            "DASHBOARD": (
                "<h4>M3.2 SHAP Importance Train/Test Comparison</h4>"
                "<p><b>Skipped:</b> SHAP is a heavy test and is not enabled in "
                "the lightweight BlackBox runner.</p>"
            )
        }


class BBM41_TargetRateCalibrationTest(M41_PredictedVsActualLevelTest):
    """M4.1. Predicted vs actual target rate."""

    def __init__(self):
        super().__init__()
        self.test_code = "M 4.1"
        self.test_name = "Predicted vs Actual Target Rate"


class BBM42_CalibrationCurveShapeTest(M94_CalibrationCurveTest):
    """M4.2. Calibration curve shape."""

    def __init__(self):
        BaseModelTest.__init__(self, "M 4.2", "Calibration Curve Shape")


class BBM51_RankingStabilityTest(M61_StabilityKeyMetricTest):
    """M5.1. Train/validation ranking stability."""

    def __init__(self):
        BaseModelTest.__init__(self, "M 5.1", "Ranking Efficiency Stability")


class BBM52_ScoreDistributionStabilityTest(BaseModelTest):
    """M5.2. Score distribution stability via PSI."""

    def __init__(self, psi_calc: Optional[PSICalculatorExtended] = None):
        super().__init__("M 5.2", "Score Distribution Stability")
        self.psi_calc = psi_calc or PSICalculatorExtended()

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
            train_df, test_df, _ = split_frames(df, cfg)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<h4>M5.2 skipped</h4><p>{'; '.join(e.errors)}</p>"}
        except Exception as e:
            return {"DASHBOARD": f"<h4>M5.2 skipped</h4><p>{str(e)}</p>"}

        score_col = _score_col(cfg)
        target_col = cfg.columns.target_column
        if not score_col:
            self.test_signal = "blue"
            return {"DASHBOARD": "<h4>M5.2 skipped</h4><p>Score column is missing.</p>"}

        result = self.psi_calc.calculate(
            expected=train_df[score_col],
            actual=test_df[score_col],
            target_expected=train_df[target_col],
            target_actual=test_df[target_col],
            is_categorical=False,
        )
        try:
            total_psi = float(result["all"]["psi"].sum())
        except Exception:
            total_psi = float("inf")

        if not np.isfinite(total_psi) or total_psi >= 0.20:
            self.test_signal = "red"
        elif total_psi >= 0.10:
            self.test_signal = "yellow"
        else:
            self.test_signal = "green"

        html = (
            "<h4>M5.2 Score Distribution Stability</h4>"
            f"<p>Total score PSI: <b>{total_psi:.4f}</b></p>"
            + self.psi_calc.generate_html_block(result, feature_name=score_col)
        )
        return {"DASHBOARD": html}
