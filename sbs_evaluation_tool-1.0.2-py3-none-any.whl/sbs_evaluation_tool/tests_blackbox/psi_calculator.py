"""Compatibility wrapper for `tests_blackbox.psi_calculator`."""

from .tests_blackbox.psi_calculator import *  # noqa: F401,F403
