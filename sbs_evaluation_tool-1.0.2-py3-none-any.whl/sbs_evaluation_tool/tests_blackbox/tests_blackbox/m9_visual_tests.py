import io
import base64
import math
import logging
from typing import Dict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

from ...core.base_test import BaseModelTest
from ...core.styles import COLORS
from ...core.config_validation import validate_config, ConfigValidationError

logger = logging.getLogger(__name__)


def _to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    img = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    return img


def _normalize_splits(df: pd.DataFrame, sample_col: str):
    # map 'train' -> 'TRAIN', everything else -> 'TEST'
    series = df[sample_col].astype(str).str.lower().apply(lambda x: 'TRAIN' if x == 'train' else 'TEST')
    return {k: g for k, g in df.assign(_sample_norm=series).groupby('_sample_norm')}


class M91_PredictionDensityByClassTest(BaseModelTest):
    """M9.1. Density of predicted scores per target class (visual)"""

    def __init__(self):
        super().__init__('M9.1', 'Prediction density by target class')

    def run(self, df: pd.DataFrame = None, config: dict = None, class_label: object = None, **kwargs) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<p>M9.1 skipped вЂ” config invalid: {'; '.join(e.errors)}</p>"}

        cols = cfg.columns
        if cols.target_column is None or cols.target_column not in df.columns:
            return {"DASHBOARD": '<p>M9.1 skipped вЂ” target column missing</p>'}

        score_col = cols.score_column or cols.prediction_column
        if score_col is None or score_col not in df.columns:
            return {"DASHBOARD": '<p>M9.1 skipped вЂ” score/prediction column missing</p>'}

        target = cols.target_column

        # prepare score arrays per class
        classes = sorted(pd.unique(df[target]))
        if class_label is not None and class_label in classes:
            classes = [class_label]

        fig, ax = plt.subplots(1, 1, figsize=(8, 4))
        plotted = 0
        for cls in classes:
            mask = df[target] == cls
            s = df.loc[mask, score_col]
            if s.empty:
                continue
            # if entries are array-like (per-class probs), try to select corresponding index
            first = s.iloc[0]
            if isinstance(first, (list, np.ndarray)):
                # pick index of class in sorted classes; if mismatch, fall back to mean
                try:
                    idx = list(sorted(pd.unique(df[target]))).index(cls)
                    arr = np.array([np.asarray(v)[idx] for v in s.values])
                    ax.hist(arr, bins=40, density=True, alpha=0.4, label=f'class {cls}')
                except Exception:
                    arr = np.array([np.mean(np.asarray(v)) for v in s.values])
                    ax.hist(arr, bins=40, density=True, alpha=0.4, label=f'class {cls}')
            else:
                ax.hist(s.values, bins=40, density=True, alpha=0.4, label=f'class {cls}')
            plotted += 1

        if plotted == 0:
            return {"DASHBOARD": '<p>M9.1 skipped вЂ” no class with scores available</p>'}

        ax.set_title('Prediction density by target class')
        ax.set_xlabel('Predicted score')
        ax.set_ylabel('Density')
        ax.legend()
        img = _to_base64(fig)

        html = f"<h4>M9.1 Prediction density by class</h4><img src=\"data:image/png;base64,{img}\"/>"
        return {"DASHBOARD": html}


class M92_R2ComparisonTest(BaseModelTest):
    """M9.2. R^2 comparison between TRAIN and TEST (regression)"""

    def __init__(self):
        super().__init__('M9.2', 'R2 comparison (regression)')

    def run(self, df: pd.DataFrame = None, config: dict = None, **kwargs) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<p>M9.2 skipped вЂ” config invalid: {'; '.join(e.errors)}</p>"}

        if cfg.task != 'regression':
            self.test_signal = 'green'
            self.test_meta = {'note': 'M9.2 applicable only for regression'}
            return {"DASHBOARD": '<p>Skipped: regression-only test</p>'}

        cols = cfg.columns
        sample_col = cols.sample_column
        if sample_col is None or sample_col not in df.columns:
            return {"DASHBOARD": '<p>M9.2 skipped вЂ” sample column missing</p>'}

        parts = _normalize_splits(df, sample_col)
        train = parts.get('TRAIN')
        test = parts.get('TEST')

        score_col = cols.score_column or cols.prediction_column
        target = cols.target_column
        if score_col is None or score_col not in df.columns or target is None or target not in df.columns:
            return {"DASHBOARD": '<p>M9.2 skipped вЂ” required columns missing</p>'}

        if train is None or test is None:
            return {"DASHBOARD": '<p>M9.2 skipped вЂ” TRAIN or TEST split missing</p>'}

        y_tr = train[target].values
        y_tr_pred = train[score_col].values
        y_te = test[target].values
        y_te_pred = test[score_col].values

        try:
            r2_tr = r2_score(y_tr, y_tr_pred)
        except Exception:
            r2_tr = float('nan')
        try:
            r2_te = r2_score(y_te, y_te_pred)
        except Exception:
            r2_te = float('nan')

        diff = r2_tr - r2_te if not (math.isnan(r2_tr) or math.isnan(r2_te)) else float('nan')
        html = f"<h4>M9.2 R^2 comparison</h4><p>TRAIN R^2: {r2_tr:.4f} вЂ” TEST R^2: {r2_te:.4f} вЂ” diff: {diff:.4f}</p>"
        df_res = pd.DataFrame([{'split': 'TRAIN', 'r2': r2_tr}, {'split': 'TEST', 'r2': r2_te}])
        html += df_res.to_html(index=False, float_format='%.4f')
        return {"DASHBOARD": html}


class M93_ActualVsPredictedTest(BaseModelTest):
    """M9.3. Actual vs Predicted visualization and residuals (regression)"""

    def __init__(self):
        super().__init__('M9.3', 'Actual vs Predicted (regression)')

    def run(self, df: pd.DataFrame = None, config: dict = None, order_by: str = None, **kwargs) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<p>M9.3 skipped вЂ” config invalid: {'; '.join(e.errors)}</p>"}

        if cfg.task != 'regression':
            self.test_signal = 'green'
            self.test_meta = {'note': 'M9.3 applicable only for regression'}
            return {"DASHBOARD": '<p>Skipped: regression-only test</p>'}

        cols = cfg.columns
        score_col = cols.score_column or cols.prediction_column
        target = cols.target_column
        if score_col is None or score_col not in df.columns or target is None or target not in df.columns:
            return {"DASHBOARD": '<p>M9.3 skipped вЂ” required columns missing</p>'}

        # ordering
        if order_by is not None and order_by in df.columns:
            ordered = df.sort_values(order_by)
        else:
            ordered = df.sort_values(target)

        y = ordered[target].values
        y_pred = ordered[score_col].values
        resid = y - y_pred

        fig, axes = plt.subplots(2, 1, figsize=(10, 6), gridspec_kw={'height_ratios': [3, 1]})
        axes[0].plot(y, label='Actual', alpha=0.8)
        axes[0].plot(y_pred, label='Predicted', alpha=0.8)
        axes[0].set_ylabel('Value')
        axes[0].legend()
        axes[0].set_title('Actual vs Predicted (ordered)')

        axes[1].plot(resid, label='Residuals')
        axes[1].axhline(0, color=COLORS['GRAY'], linewidth=0.5)
        axes[1].set_ylabel('Residual')
        axes[1].set_xlabel('Ordered observations')

        plt.tight_layout()
        img = _to_base64(fig)

        # summary metrics
        try:
            mse = mean_squared_error(y, y_pred)
            mae = mean_absolute_error(y, y_pred)
            r2 = r2_score(y, y_pred)
        except Exception:
            mse = mae = r2 = float('nan')

        html = f"<h4>M9.3 Actual vs Predicted</h4><img src=\"data:image/png;base64,{img}\"/>"
        html += f"<p>Metrics on ordered sample: MSE={mse:.4f}, MAE={mae:.4f}, R2={r2:.4f}</p>"
        return {"DASHBOARD": html}


class M94_CalibrationCurveTest(BaseModelTest):
    """M9.4. Calibration curve and bucket analysis (classification)"""

    def __init__(self):
        super().__init__('M9.4', 'Calibration curve test (classification)')

    def run(self, df: pd.DataFrame = None, config: dict = None, n_buckets: int = 10, **kwargs) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"DASHBOARD": f"<p>M9.4 skipped вЂ” config invalid: {'; '.join(e.errors)}</p>"}

        if cfg.task != 'classification':
            self.test_signal = 'green'
            self.test_meta = {'note': 'M9.4 applicable only for classification'}
            return {"DASHBOARD": '<p>Skipped: classification-only test</p>'}

        cols = cfg.columns
        score_col = cols.score_column or cols.prediction_column
        target = cols.target_column
        if score_col is None or score_col not in df.columns or target is None or target not in df.columns:
            return {"DASHBOARD": '<p>M9.4 skipped вЂ” required columns missing</p>'}

        # get predicted probability for positive class; if per-class arrays provided, try to use class index 1
        scores = df[score_col].values
        # if array-like probabilities, reduce to scalar pred probability by taking mean or second column
        if len(scores) > 0 and isinstance(scores[0], (list, np.ndarray)):
            try:
                arr = np.vstack([np.asarray(x) for x in scores])
                if arr.shape[1] >= 2:
                    probs = arr[:, 1]
                else:
                    probs = arr[:, 0]
            except Exception:
                probs = np.array([np.mean(np.asarray(x)) for x in scores])
        else:
            probs = np.asarray(scores, dtype=float)

        obs = df[target].astype(float).values

        # bucket by quantiles
        try:
            bins = np.quantile(probs, np.linspace(0, 1, n_buckets + 1))
            # ensure unique edges
            bins = np.unique(bins)
            inds = np.digitize(probs, bins, right=True) - 1
        except Exception:
            return {"DASHBOARD": '<p>M9.4 skipped вЂ” cannot compute buckets</p>'}

        records = []
        out95 = 0
        out99 = 0
        for b in range(len(bins) - 1):
            mask = (inds == b)
            n = int(mask.sum())
            if n == 0:
                continue
            pred_mean = probs[mask].mean()
            obs_mean = obs[mask].mean()
            se = math.sqrt(pred_mean * (1 - pred_mean) / n) if n > 0 else 0.0
            ci95_lo = pred_mean - 1.96 * se
            ci95_hi = pred_mean + 1.96 * se
            ci99_lo = pred_mean - 2.575 * se
            ci99_hi = pred_mean + 2.575 * se
            out95 += 1 if (obs_mean < ci95_lo or obs_mean > ci95_hi) else 0
            out99 += 1 if (obs_mean < ci99_lo or obs_mean > ci99_hi) else 0
            records.append({'bucket': b + 1, 'n': n, 'pred_mean': pred_mean, 'obs_mean': obs_mean,
                            'ci95_lo': ci95_lo, 'ci95_hi': ci95_hi, 'ci99_lo': ci99_lo, 'ci99_hi': ci99_hi})

        df_b = pd.DataFrame(records)

        # plot calibration curve
        fig, ax = plt.subplots(2, 1, figsize=(8, 6), gridspec_kw={'height_ratios': [3, 1]})
        if not df_b.empty:
            ax[0].plot(df_b['pred_mean'], df_b['obs_mean'], marker='o')
            ax[0].plot([0, 1], [0, 1], linestyle='--', color=COLORS['GRAY'])
            ax[0].set_ylabel('Observed proportion')
            ax[0].set_title('Calibration curve')
            ax[1].bar(df_b['bucket'], df_b['n'])
            ax[1].set_xlabel('Bucket')
            ax[1].set_ylabel('Count')
        img = _to_base64(fig)

        html = f"<h4>M9.4 Calibration curve</h4><p>Outliers: 95% buckets={out95}, 99% buckets={out99}</p>"
        html += f"<img src=\"data:image/png;base64,{img}\"/>"
        html += df_b.to_html(index=False, float_format='%.4f')
        self.test_meta = {'out95': out95, 'out99': out99}
        return {"DASHBOARD": html}
