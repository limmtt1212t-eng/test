"""Blackbox tests: M1 group (sampling and data quality checks)

Implements:
- M1.1 Sample Consistency Test (intersections and key uniqueness)
- M1.2 Data Freshness Test
- M1.3 Split Randomness Test (predictability of train/oos split)

All output text and documentation are in English.
"""
from __future__ import annotations
from typing import Dict, List, Tuple
import math
import logging
import warnings
import numpy as np
import pandas as pd
from io import BytesIO
import base64
import matplotlib.pyplot as plt
from tqdm import tqdm

from ...core.base_test import BaseModelTest
from ...core.config_validation import validate_config, ConfigValidationError

# Setup logging
logger = logging.getLogger(__name__)

# sklearn imports are optional; tests will fail gracefully if missing
try:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import roc_auc_score
    SKLEARN_AVAILABLE = True
    # Suppress sklearn warnings about single class ROC AUC
    warnings.filterwarnings('ignore', 'Only one class is present in y_true', UserWarning, 'sklearn')
except Exception:
    SKLEARN_AVAILABLE = False


def _to_base64(fig) -> str:
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode('utf-8')


class M11_SampleConsistencyTest(BaseModelTest):
    """M1.1 Sample consistency checks: pairwise intersections and key uniqueness.

    Checks performed:
      - Pairwise intersections between samples (by id column) computed per target class.
      - Duplicate key rate per sample computed per target class.

    Interpretation (worst across checks & classes):
      - >10% problematic observations => RED
      - 5%..10% => ORANGE
      - otherwise => GREEN

    Returns an HTML dashboard with tables and sets `self.test_signal`.
    """
    def __init__(self):
        super().__init__('M 1.1', 'Sample Consistency')

    def _get_sample_subsets(self, df: pd.DataFrame, sample_col: str) -> Dict[str, pd.DataFrame]:
        s = df[sample_col].astype(str).str.lower()
        subsets = {}
        for val in s.unique():
            subsets[val] = df[s == val].copy()
        return subsets

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M1.1 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}
        except Exception as e:
            return {"report": f"<h4>M1.1 error</h4><p>{str(e)}</p>"}

        sample_col = cfg.columns.sample_column
        id_col = cfg.columns.id_column
        target_col = cfg.columns.target_column

        logger.info(f"Starting M1.1 Sample Consistency Test with {len(df)} rows")

        if sample_col not in df.columns:
            return {"report": f"<h4>M1.1 skipped</h4><p>Sample column '{sample_col}' is not present in data.</p>"}
        if id_col not in df.columns:
            return {"report": f"<h4>M1.1 skipped</h4><p>ID column '{id_col}' is not present in data.</p>"}
        if target_col not in df.columns:
            return {"report": f"<h4>M1.1 skipped</h4><p>Target column '{target_col}' is not present in data.</p>"}

        subsets = self._get_sample_subsets(df, sample_col)
        sample_names = list(subsets.keys())
        logger.info(f"Found {len(sample_names)} samples: {sample_names}")

        # Prepare results containers
        pairwise_rows = []  # for intersections
        duplicate_rows = []  # for duplicates per sample

        # For each pair of samples compute intersection share per target class
        total_pairs = len(sample_names) * (len(sample_names) - 1) // 2
        logger.info(f"Computing pairwise intersections for {total_pairs} sample pairs")
        
        pair_progress = tqdm(total=total_pairs, desc="Computing sample pairs", leave=False)
        for i in range(len(sample_names)):
            for j in range(i + 1, len(sample_names)):
                a_name = sample_names[i]
                b_name = sample_names[j]
                a = subsets[a_name]
                b = subsets[b_name]

                logger.debug(f"Processing pair: {a_name} ({len(a)} rows) vs {b_name} ({len(b)} rows)")

                # inner join on id to get overlapping observations
                overlap = pd.merge(a[[id_col, target_col]], b[[id_col, target_col]], on=id_col, suffixes=('_a', '_b'))
                # keep only rows where target class equals in both (we compare by class)
                if overlap.empty:
                    # still report 0% per known classes
                    classes = sorted(df[target_col].dropna().unique())
                    for cls in classes:
                        pairwise_rows.append({'sample_a': a_name, 'sample_b': b_name, 'class': cls, 'overlap_count': 0, 'overlap_pct': 0.0})
                    pair_progress.update(1)
                    continue

                # compute per-class percentages relative to class counts in the union? Spec: "percentage of intersections in % for each class of the target from the total number of observations in the considered class"
                # We'll compute overlap_count / total_in_class_in_union_sampleA+sampleB? The spec is ambiguous; reasonable interpretation: for each class compute overlap_count / total_in_that_class_across_both_samples.
                classes = sorted(df[target_col].dropna().unique())
                for cls in tqdm(classes, desc=f"Processing classes for {a_name}-{b_name}", leave=False):
                    # count of observations of this class in both samples combined
                    tot = int(((a[target_col] == cls).sum()) + ((b[target_col] == cls).sum()))
                    # overlap where either side has class equal to cls on at least one side
                    ov = overlap[(overlap[f'{target_col}_a'] == cls) & (overlap[f'{target_col}_b'] == cls)]
                    ov_count = int(len(ov))
                    pct = (ov_count / tot * 100.0) if tot > 0 else 0.0
                    pairwise_rows.append({'sample_a': a_name, 'sample_b': b_name, 'class': cls, 'overlap_count': ov_count, 'overlap_pct': round(pct, 3)})
                
                pair_progress.update(1)
        pair_progress.close()

        # Duplicate key rates per sample & class
        logger.info("Computing duplicate key rates per sample and class")
        duplicate_progress = tqdm(subsets.items(), desc="Computing duplicates", leave=False)
        for name, sub in duplicate_progress:
            duplicate_progress.set_description(f"Computing duplicates for {name}")
            if id_col not in sub.columns:
                continue
            dup_series = sub.duplicated(subset=[id_col], keep=False)
            classes = sorted(df[target_col].dropna().unique())
            for cls in classes:
                sub_cls = sub[sub[target_col] == cls]
                if sub_cls.empty:
                    duplicate_rows.append({'sample': name, 'class': cls, 'n': 0, 'duplicates': 0, 'dup_pct': 0.0})
                    continue
                n = len(sub_cls)
                dups = int(sub_cls.duplicated(subset=[id_col], keep=False).sum())
                dup_pct = (dups / n * 100.0) if n > 0 else 0.0
                duplicate_rows.append({'sample': name, 'class': cls, 'n': n, 'duplicates': dups, 'dup_pct': round(dup_pct, 3)})
        duplicate_progress.close()

        pairwise_df = pd.DataFrame(pairwise_rows)
        dup_df = pd.DataFrame(duplicate_rows)

        # Determine worst-case percent across both checks and classes
        worst_pct = 0.0
        if not pairwise_df.empty:
            worst_pct = max(worst_pct, pairwise_df['overlap_pct'].max())
        if not dup_df.empty:
            worst_pct = max(worst_pct, dup_df['dup_pct'].max())

        logger.info(f"M1.1 completed. Worst problematic percentage: {worst_pct:.2f}%")

        if worst_pct > 10.0:
            signal = 'red'
        elif worst_pct >= 5.0:
            signal = 'orange'
        else:
            signal = 'green'

        self.test_signal = signal
        self.test_meta = {'worst_pct': worst_pct}

        html = f"<h4>M1.1 Sample Consistency</h4><p>Worst problematic share across checks and classes: <b>{worst_pct:.2f}%</b></p>"
        html += "<h5>Pairwise overlaps (percent of class)</h5>"
        html += pairwise_df.to_html(index=False, float_format='%.3f')
        html += "<h5>Duplicate key rates per sample & class</h5>"
        html += dup_df.to_html(index=False, float_format='%.3f')

        return {"DASHBOARD": html}


class M12_DataFreshnessTest(BaseModelTest):
    """M1.2 Data freshness: checks recency of data used for modelling.

    Heuristic used here:
      - development_date: we take the max date observed in the sample that is labeled as 'train' (or overall max if train not present)
      - data_latest_date: the maximum date in the data (date_column)
      - lag_months = number of months between development_date and data_latest_date

    Interpretation:
      - lag > 12 months -> RED
      - 6 <= lag <= 12 -> ORANGE
      - lag < 6 -> GREEN

    Note: this is a heuristic; users can adapt to use explicit development_date if available.
    """
    def __init__(self):
        super().__init__('M 1.2', 'Data Freshness')

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M1.2 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        date_col = cfg.columns.date_column
        sample_col = cfg.columns.sample_column

        logger.info(f"Starting M1.2 Data Freshness Test with {len(df)} rows")

        if date_col not in df.columns:
            return {"report": f"<h4>M1.2 skipped</h4><p>Date column '{date_col}' missing.</p>"}

        # try to parse dates
        try:
            logger.info(f"Parsing dates in column '{date_col}'")
            df = df.copy()
            df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
        except Exception as e:
            logger.error(f"Failed to parse dates: {e}")
            return {"report": f"<h4>M1.2 error</h4><p>Failed to parse dates in column '{date_col}'.</p>"}

        # development date: prefer max date in train sample
        dev_date = None
        if sample_col in df.columns:
            logger.info("Computing development date from train sample")
            svals = df[sample_col].astype(str).str.lower()
            if 'train' in svals.unique():
                dev_date = df[svals == 'train'][date_col].max()
        if dev_date is None:
            logger.info("No train sample found, using overall max date as development date")
            dev_date = df[date_col].max()

        data_latest = df[date_col].max()
        if pd.isna(dev_date) or pd.isna(data_latest):
            return {"report": "<h4>M1.2 skipped</h4><p>Insufficient date information to compute freshness.</p>"}

        # compute months difference
        diff_days = (data_latest - dev_date).days
        lag_months = diff_days / 30.0

        logger.info(f"Data freshness: dev_date={dev_date.date()}, latest_date={data_latest.date()}, lag={lag_months:.2f} months")

        if lag_months > 12.0:
            signal = 'red'
        elif lag_months >= 6.0:
            signal = 'orange'
        else:
            signal = 'green'

        self.test_signal = signal
        self.test_meta = {'dev_date': str(dev_date.date()), 'data_latest': str(data_latest.date()), 'lag_months': round(lag_months, 2)}

        html = f"<h4>M1.2 Data Freshness</h4>"
        html += f"<p>Development date (heuristic): <b>{dev_date.date()}</b></p>"
        html += f"<p>Latest data date: <b>{data_latest.date()}</b></p>"
        html += f"<p>Lag: <b>{lag_months:.2f}</b> months вЂ” <b style='color:{ 'green' if signal=='green' else ('orange' if signal=='orange' else 'red') }'>{signal.upper()}</b></p>"

        return {"DASHBOARD": html}


class M13_SplitRandomnessTest(BaseModelTest):
    """M1.3 Split randomness: check predictability of original train/oos split.

    The test trains a simple classifier to predict sample membership (0=train, 1=oos) using a short list
    of features (numeric + categorical configured in config). Using k-fold CV (default k=4) we compute AUC
    per fold and convert to Gini = 2*AUC - 1. The mean absolute Gini (as fraction) is interpreted per Table 6.4:
      - |Gini| > 0.10 -> RED
      - 0.05 < |Gini| <= 0.10 -> ORANGE
      - |Gini| <= 0.05 -> GREEN

    If sklearn is not available the test will return a skipped report.
    """
    def __init__(self, k_folds: int = 4):
        super().__init__('M 1.3', 'Split Randomness')
        self.k = int(k_folds)

    def run(self, df: pd.DataFrame = None, config: dict = None) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M1.3 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        if not SKLEARN_AVAILABLE:
            return {"report": "<h4>M1.3 skipped</h4><p>scikit-learn is not available in the environment.</p>"}

        sample_col = cfg.columns.sample_column
        if sample_col not in df.columns:
            return {"report": f"<h4>M1.3 skipped</h4><p>Sample column '{sample_col}' missing in data.</p>"}

        logger.info(f"Starting M1.3 Split Randomness Test with {len(df)} rows, {self.k} folds")

        # Build combined dataset of train + oos (out-of-sample). We treat all samples not labeled 'train' as oos.
        svals = df[sample_col].astype(str).str.lower()
        if 'train' not in svals.unique():
            return {"report": "<h4>M1.3 skipped</h4><p>No 'train' sample found in sample column.</p>"}

        # create binary label: 0 if train else 1
        mask_train = (svals == 'train')
        combined = df[mask_train | (~mask_train)].copy()
        combined = combined.reset_index(drop=True)
        combined['_is_oos'] = (~mask_train[combined.index]).astype(int)

        logger.info(f"Train samples: {mask_train.sum()}, OOS samples: {(~mask_train).sum()}")

        # select features list
        feats = list(getattr(cfg.columns, 'numeric_features', []) or []) + list(getattr(cfg.columns, 'categorical_features', []) or [])
        feats = [f for f in feats if f in combined.columns]
        if not feats:
            return {"report": "<h4>M1.3 skipped</h4><p>No features configured to test randomness (numeric/categorical empty or missing).</p>"}

        logger.info(f"Using {len(feats)} features for randomness test: {feats[:5]}{'...' if len(feats) > 5 else ''}")

        X = combined[feats].copy()
        y = combined['_is_oos'].astype(int)

        # basic preprocessing: fillna with zero for numerics and label-encode categoricals
        logger.info("Preprocessing features...")
        preprocessing_progress = tqdm(X.columns, desc="Preprocessing features", leave=False)
        for c in preprocessing_progress:
            preprocessing_progress.set_description(f"Processing {c}")
            if pd.api.types.is_numeric_dtype(X[c]):
                X[c] = pd.to_numeric(X[c], errors='coerce').fillna(0)
            else:
                X[c] = X[c].astype(str).fillna('')
                # simple label encoding
                X[c] = X[c].astype('category').cat.codes
        preprocessing_progress.close()

        skf = StratifiedKFold(n_splits=self.k, shuffle=True, random_state=42)
        gini_values = []
        fold = 0
        
        logger.info(f"Starting {self.k}-fold cross-validation")
        fold_progress = tqdm(skf.split(X, y), total=self.k, desc="Cross-validation", leave=False)
        for tr_idx, te_idx in fold_progress:
            fold += 1
            fold_progress.set_description(f"Training fold {fold}/{self.k}")
            X_tr, X_te = X.iloc[tr_idx], X.iloc[te_idx]
            y_tr, y_te = y.iloc[tr_idx], y.iloc[te_idx]
            try:
                logger.debug(f"Fold {fold}: train_size={len(X_tr)}, test_size={len(X_te)}")
                m = RandomForestClassifier(n_estimators=100, random_state=fold, n_jobs=-1)
                m.fit(X_tr, y_tr)
                if hasattr(m, 'predict_proba'):
                    probs = m.predict_proba(X_te)[:, 1]
                else:
                    probs = m.predict(X_te)
                
                # Check if we have at least two classes in test set
                unique_classes = np.unique(y_te)
                if len(unique_classes) < 2:
                    gini_values.append(float('nan'))
                    logger.debug(f"Fold {fold} skipped: only one class in test set")
                    continue
                
                # Suppress sklearn warnings about single class
                with warnings.catch_warnings():
                    warnings.filterwarnings('ignore', category=UserWarning, module='sklearn')
                    auc = roc_auc_score(y_te, probs)
                    gini = 2.0 * auc - 1.0
                    gini_values.append(gini)
                    logger.debug(f"Fold {fold} completed: AUC={auc:.4f}, Gini={gini:.4f}")
            except Exception as e:
                logger.warning(f"Fold {fold} failed: {e}")
                # if any fold fails, store nan
                gini_values.append(float('nan'))
        fold_progress.close()

        gini_arr = np.array([g for g in gini_values if not math.isnan(g)])
        if gini_arr.size == 0:
            return {"report": "<h4>M1.3 skipped</h4><p>Could not compute Gini; all folds failed or insufficient data.</p>"}

        mean_abs_gini = float(np.mean(np.abs(gini_arr)))
        logger.info(f"M1.3 completed. Mean absolute Gini: {mean_abs_gini:.4f}")

        # Interpretation thresholds (as fractions): 0.10 -> RED, 0.05..0.10 -> ORANGE, <=0.05 -> GREEN
        if mean_abs_gini > 0.10:
            signal = 'red'
        elif mean_abs_gini > 0.05:
            signal = 'orange'
        else:
            signal = 'green'

        self.test_signal = signal
        self.test_meta = {'gini_per_fold': [float(g) for g in gini_values], 'mean_abs_gini': mean_abs_gini}

        # Build simple plot of per-fold Gini
        fig = plt.figure(figsize=(6, 3))
        plt.plot(range(1, len(gini_values) + 1), gini_values, marker='o')
        plt.xlabel('Fold')
        plt.ylabel('Gini')
        plt.title('Gini per fold (split predictability)')
        plt.axhline(0.05, color='orange', linestyle='--', label='0.05')
        plt.axhline(0.10, color='red', linestyle='--', label='0.10')
        plt.legend()
        plot_b64 = _to_base64(fig)

        html = f"<h4>M1.3 Split Randomness</h4>"
        html += f"<p>Mean absolute Gini (avg of folds): <b>{mean_abs_gini:.4f}</b> вЂ” <b style='color:{ 'green' if signal=='green' else ('orange' if signal=='orange' else 'red') }'>{signal.upper()}</b></p>"
        html += f"<img src=\"data:image/png;base64,{plot_b64}\" />"
        html += "<h5>Per-fold values</h5>" + pd.DataFrame({'fold': list(range(1, len(gini_values) + 1)), 'gini': gini_values}).to_html(index=False, float_format='%.4f')

        return {"DASHBOARD": html}
    
class M14_StabilityHeatmapTest(BaseModelTest):
    """M1.4 Stability Heatmap: visualize feature distribution over time periods.

    Plots a heatmap showing how a feature's distribution changes across time.
    Useful for detecting shifts in data patterns over time.
    """
    def plot_feature_time_heatmap(
        self,
        df: pd.DataFrame,
        feature_col: str,
        time_col: str,
        feature_type: str = "auto",
        bins: int = 10,
        binning: str = "quantile",
        time_freq: str = "M",
        include_missing: bool = True,
        figsize=(11, 7),
        title: str | None = None):
        """
        РЎС‚СЂРѕРёС‚ С‚РµРїР»РѕРєР°СЂС‚Сѓ СЂР°СЃРїСЂРµРґРµР»РµРЅРёСЏ РїСЂРёР·РЅР°РєР° РїРѕ РІСЂРµРјРµРЅРЅС‹Рј РїРµСЂРёРѕРґР°Рј.
        Р¦РІРµС‚ = РґРѕР»СЏ РЅР°Р±Р»СЋРґРµРЅРёР№ РґР°РЅРЅРѕРіРѕ РїРµСЂРёРѕРґР° РІ СЃРѕРѕС‚РІРµС‚СЃС‚РІСѓСЋС‰РµР№ РєР°С‚РµРіРѕСЂРёРё.
        """
        from pandas.api.types import is_categorical_dtype, is_numeric_dtype
        
        if time_col not in df.columns or feature_col not in df.columns:
            raise KeyError("РќРµ РЅР°Р№РґРµРЅС‹ СѓРєР°Р·Р°РЅРЅС‹Рµ СЃС‚РѕР»Р±С†С‹ 'time_col' РёР»Рё 'feature_col'.")

        # ---- 1) РџРѕРґРіРѕС‚РѕРІРєР° РІСЂРµРјРµРЅРё
        work = df[[time_col, feature_col]].copy()
        work[time_col] = pd.to_datetime(work[time_col], errors="coerce")
        work = work.dropna(subset=[time_col])
        work["__period__"] = work[time_col].dt.to_period(time_freq).dt.to_timestamp()

        # ---- 2) РћРїСЂРµРґРµР»СЏРµРј С‚РёРї РїСЂРёР·РЅР°РєР°
        if feature_type == "auto":
            if is_categorical_dtype(work[feature_col]) or work[feature_col].dtype == object:
                feature_type = "categorical"
            elif is_numeric_dtype(work[feature_col]):
                feature_type = "categorical" if work[feature_col].nunique(dropna=True) <= 20 else "continuous"
            else:
                feature_type = "categorical"

        # ---- 3) РџСЂРµРѕР±СЂР°Р·СѓРµРј РїСЂРёР·РЅР°Рє Рє РєР°С‚РµРіРѕСЂРёСЏРј
        feat = work[feature_col]
        if feature_type == "continuous":
            numeric = pd.to_numeric(feat, errors="coerce")
            if binning == "quantile":
                try:
                    cats = pd.qcut(numeric, q=bins, duplicates="drop")
                except ValueError:
                    cats = pd.cut(numeric, bins=min(bins, max(1, numeric.nunique())), include_lowest=True)
            else:
                cats = pd.cut(numeric, bins=bins, include_lowest=True)
            work["__cat__"] = cats.astype("string")
        else:
            work["__cat__"] = feat.astype("string")

        if include_missing:
            work["__cat__"] = work["__cat__"].fillna("Missing")
        else:
            work = work.dropna(subset=["__cat__"])

        # ---- 4) РЎС‡РёС‚Р°РµРј РґРѕР»Рё РїРѕ РїРµСЂРёРѕРґР°Рј
        counts = (
            work.groupby(["__period__", "__cat__"], dropna=False)
                .size()
                .rename("cnt")
                .reset_index()
        )
        totals = counts.groupby("__period__")["cnt"].transform("sum")
        counts["share"] = counts["cnt"] / totals

        periods = counts["__period__"].drop_duplicates().sort_values()
        categories = counts["__cat__"].drop_duplicates().sort_values()
        grid = (
            pd.MultiIndex.from_product([periods, categories], names=["__period__", "__cat__"])
            .to_frame(index=False)
            .merge(counts[["__period__", "__cat__", "share"]], on=["__period__", "__cat__"], how="left")
            .fillna({"share": 0.0})
        )
        pivot_df = grid.pivot(index="__cat__", columns="__period__", values="share").sort_index()

        # ---- 5) РџРѕСЃС‚СЂРѕРµРЅРёРµ С‚РµРїР»РѕРєР°СЂС‚С‹
        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(pivot_df.values, aspect="auto", interpolation="nearest", cmap="hot_r")

        ax.set_ylabel("РљР°С‚РµРіРѕСЂРёСЏ" + (" (Р±РёРЅС‹)" if feature_type == "continuous" else ""))
        ax.set_xlabel("РџРµСЂРёРѕРґ")
        if title is None:
            title = f"Р Р°СЃРїСЂРµРґРµР»РµРЅРёРµ '{feature_col}' РїРѕ РІСЂРµРјРµРЅРё (С†РІРµС‚ = РґРѕР»СЏ)"
        ax.set_title(title)

        ax.set_yticks(range(pivot_df.shape[0]))
        ax.set_yticklabels(list(pivot_df.index), rotation=0)
        ax.set_xticks(range(pivot_df.shape[1]))

        max_xticks = 30
        if pivot_df.shape[1] > max_xticks:
            step = int(np.ceil(pivot_df.shape[1] / max_xticks))
            shown = np.arange(0, pivot_df.shape[1], step)
            ax.set_xticks(shown)
            ax.set_xticklabels(pivot_df.columns.strftime("%Y-%m-%d")[shown], rotation=45, ha="right")
        else:
            ax.set_xticklabels(pivot_df.columns.strftime("%Y-%m-%d"), rotation=45, ha="right")

        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label("Р”РѕР»СЏ РЅР°Р±Р»СЋРґРµРЅРёР№")
        plt.tight_layout()
        
        return fig, pivot_df

    def plot_outliers_heatmap(
        self,
        df: pd.DataFrame,
        feature_col: str,
        time_col: str,
        time_freq: str = "M",
        outlier_threshold: float = 3.0,
        figsize=(11, 7),
        title: str | None = None):
        """
        РЎС‚СЂРѕРёС‚ С‚РµРїР»РѕРєР°СЂС‚Сѓ РІС‹Р±СЂРѕСЃРѕРІ РїСЂРёР·РЅР°РєР° РїРѕ РІСЂРµРјРµРЅРЅС‹Рј РїРµСЂРёРѕРґР°Рј.
        """
        if time_col not in df.columns or feature_col not in df.columns:
            raise KeyError("РќРµ РЅР°Р№РґРµРЅС‹ СѓРєР°Р·Р°РЅРЅС‹Рµ СЃС‚РѕР»Р±С†С‹ 'time_col' РёР»Рё 'feature_col'.")

        # ---- 1) РџРѕРґРіРѕС‚РѕРІРєР° РґР°РЅРЅС‹С…
        work = df[[time_col, feature_col]].copy()
        work[time_col] = pd.to_datetime(work[time_col], errors="coerce")
        work = work.dropna(subset=[time_col])
        work["__period__"] = work[time_col].dt.to_period(time_freq).dt.to_timestamp()
        
        # ---- 2) РћРїСЂРµРґРµР»РµРЅРёРµ РІС‹Р±СЂРѕСЃРѕРІ (Z-score > threshold)
        numeric = pd.to_numeric(work[feature_col], errors="coerce").dropna()
        mean_val = numeric.mean()
        std_val = numeric.std()
        
        if std_val == 0:
            work["__outlier__"] = "No Outliers"
        else:
            z_scores = np.abs((numeric - mean_val) / std_val)
            outlier_mask = z_scores > outlier_threshold
            work.loc[numeric.index, "__outlier__"] = np.where(outlier_mask, "Outlier", "Normal")

        # ---- 3) РЎС‡РёС‚Р°РµРј РґРѕР»Рё РїРѕ РїРµСЂРёРѕРґР°Рј
        counts = (
            work.groupby(["__period__", "__outlier__"], dropna=False)
                .size()
                .rename("cnt")
                .reset_index()
        )
        totals = counts.groupby("__period__")["cnt"].transform("sum")
        counts["share"] = counts["cnt"] / totals

        periods = counts["__period__"].drop_duplicates().sort_values()
        categories = counts["__outlier__"].drop_duplicates().sort_values()
        grid = (
            pd.MultiIndex.from_product([categories, periods], names=["__outlier__", "__period__"])
            .to_frame(index=False)
            .merge(counts[["__period__", "__outlier__", "share"]], on=["__period__", "__outlier__"], how="left")
            .fillna({"share": 0.0})
        )
        pivot_df = grid.pivot(index="__outlier__", columns="__period__", values="share").sort_index()

        # ---- 4) РџРѕСЃС‚СЂРѕРµРЅРёРµ С‚РµРїР»РѕРєР°СЂС‚С‹
        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(pivot_df.values, aspect="auto", interpolation="nearest", cmap="hot_r")

        ax.set_ylabel("РЎС‚Р°С‚СѓСЃ")
        ax.set_xlabel("РџРµСЂРёРѕРґ")
        if title is None:
            title = f"РђРЅР°Р»РёР· РІС‹Р±СЂРѕСЃРѕРІ '{feature_col}' РїРѕ РІСЂРµРјРµРЅРё"
        ax.set_title(title)

        ax.set_yticks(range(pivot_df.shape[0]))
        ax.set_yticklabels(list(pivot_df.index), rotation=0)
        ax.set_xticks(range(pivot_df.shape[1]))

        max_xticks = 30
        if pivot_df.shape[1] > max_xticks:
            step = int(np.ceil(pivot_df.shape[1] / max_xticks))
            shown = np.arange(0, pivot_df.shape[1], step)
            ax.set_xticks(shown)
            ax.set_xticklabels(pivot_df.columns.strftime("%Y-%m-%d")[shown], rotation=45, ha="right")
        else:
            ax.set_xticklabels(pivot_df.columns.strftime("%Y-%m-%d"), rotation=45, ha="right")

        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label("Р”РѕР»СЏ РЅР°Р±Р»СЋРґРµРЅРёР№")
        plt.tight_layout()
        
        return fig, pivot_df

    def plot_missing_values_heatmap(
        self,
        df: pd.DataFrame,
        feature_col: str,
        time_col: str,
        time_freq: str = "M",
        figsize=(11, 7),
        title: str | None = None):
        """
        РЎС‚СЂРѕРёС‚ С‚РµРїР»РѕРєР°СЂС‚Сѓ РїСЂРѕРїСѓС‰РµРЅРЅС‹С… Р·РЅР°С‡РµРЅРёР№ РїСЂРёР·РЅР°РєР° РїРѕ РІСЂРµРјРµРЅРЅС‹Рј РїРµСЂРёРѕРґР°Рј.
        """
        if time_col not in df.columns or feature_col not in df.columns:
            raise KeyError("РќРµ РЅР°Р№РґРµРЅС‹ СѓРєР°Р·Р°РЅРЅС‹Рµ СЃС‚РѕР»Р±С†С‹ 'time_col' РёР»Рё 'feature_col'.")

        # ---- 1) РџРѕРґРіРѕС‚РѕРІРєР° РґР°РЅРЅС‹С…
        work = df[[time_col, feature_col]].copy()
        work[time_col] = pd.to_datetime(work[time_col], errors="coerce")
        work = work.dropna(subset=[time_col])
        work["__period__"] = work[time_col].dt.to_period(time_freq).dt.to_timestamp()
        
        # ---- 2) РћРїСЂРµРґРµР»РµРЅРёРµ РїСЂРѕРїСѓС‰РµРЅРЅС‹С… Р·РЅР°С‡РµРЅРёР№
        work["__missing__"] = work[feature_col].isna().map({True: "Missing", False: "Present"})

        # ---- 3) РЎС‡РёС‚Р°РµРј РґРѕР»Рё РїРѕ РїРµСЂРёРѕРґР°Рј
        counts = (
            work.groupby(["__period__", "__missing__"], dropna=False)
                .size()
                .rename("cnt")
                .reset_index()
        )
        totals = counts.groupby("__period__")["cnt"].transform("sum")
        counts["share"] = counts["cnt"] / totals

        periods = counts["__period__"].drop_duplicates().sort_values()
        categories = counts["__missing__"].drop_duplicates().sort_values()
        grid = (
            pd.MultiIndex.from_product([categories, periods], names=["__missing__", "__period__"])
            .to_frame(index=False)
            .merge(counts[["__period__", "__missing__", "share"]], on=["__period__", "__missing__"], how="left")
            .fillna({"share": 0.0})
        )
        pivot_df = grid.pivot(index="__missing__", columns="__period__", values="share").sort_index()

        # ---- 4) РџРѕСЃС‚СЂРѕРµРЅРёРµ С‚РµРїР»РѕРєР°СЂС‚С‹
        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(pivot_df.values, aspect="auto", interpolation="nearest", cmap="hot_r")

        ax.set_ylabel("РЎС‚Р°С‚СѓСЃ")
        ax.set_xlabel("РџРµСЂРёРѕРґ")
        if title is None:
            title = f"РђРЅР°Р»РёР· РїСЂРѕРїСѓС‰РµРЅРЅС‹С… Р·РЅР°С‡РµРЅРёР№ '{feature_col}' РїРѕ РІСЂРµРјРµРЅРё"
        ax.set_title(title)

        ax.set_yticks(range(pivot_df.shape[0]))
        ax.set_yticklabels(list(pivot_df.index), rotation=0)
        ax.set_xticks(range(pivot_df.shape[1]))

        max_xticks = 30
        if pivot_df.shape[1] > max_xticks:
            step = int(np.ceil(pivot_df.shape[1] / max_xticks))
            shown = np.arange(0, pivot_df.shape[1], step)
            ax.set_xticks(shown)
            ax.set_xticklabels(pivot_df.columns.strftime("%Y-%m-%d")[shown], rotation=45, ha="right")
        else:
            ax.set_xticklabels(pivot_df.columns.strftime("%Y-%m-%d"), rotation=45, ha="right")

        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label("Р”РѕР»СЏ РЅР°Р±Р»СЋРґРµРЅРёР№")
        plt.tight_layout()
        
        return fig, pivot_df

    def __init__(self):
        super().__init__('M 1.4', 'Stability Heatmap')

    def run(self, df: pd.DataFrame = None, config: dict = None, **kwargs) -> Dict[str, str]:
        try:
            cfg = validate_config(config, df)
        except ConfigValidationError as e:
            return {"report": f"<h4>M1.4 skipped</h4><p>Config validation failed: {'; '.join(e.errors)}</p>"}

        # РџСЂРѕРІРµСЂСЏРµРј РґРѕРїРѕР»РЅРёС‚РµР»СЊРЅС‹Рµ РїР°СЂР°РјРµС‚СЂС‹ РёР· test_params
        columns = kwargs.get('columns')
        if columns is None:
            # fallback РЅР° РѕСЂРёРіРёРЅР°Р»СЊРЅСѓСЋ Р»РѕРіРёРєСѓ
            columns = getattr(cfg.columns, 'stability_features', [])

        if not columns:
            return {"report": "<h4>M1.4 skipped</h4><p>No 'stability_features' specified in config or test_params.</p>"}
        if isinstance(columns, str):
            columns = [columns]  # РїРѕРґРґРµСЂР¶РєР° РѕРґРЅРѕРіРѕ РїСЂРёР·РЅР°РєР° РєР°Рє СЃС‚СЂРѕРєРё
        
        date_col = cfg.columns.date_column
        if date_col not in df.columns:
            return {"report": f"<h4>M1.4 skipped</h4><p>Date column '{date_col}' missing.</p>"}

        html = "<h4>M1.4 Stability Heatmaps</h4>"
        self.test_meta = {"features": columns}

        logger.info(f"Starting M1.4 Stability Heatmaps for {len(columns)} features.")

        for feature_col in columns:
            if feature_col not in df.columns:
                html += f"<p>вљ пёЏ Feature '{feature_col}' not found in data.</p>"
                continue

            try:
                # РћСЃРЅРѕРІРЅР°СЏ С‚РµРїР»РѕРєР°СЂС‚Р° СЂР°СЃРїСЂРµРґРµР»РµРЅРёСЏ
                fig, _ = self.plot_feature_time_heatmap(
                    df=df,
                    feature_col=feature_col,
                    time_col=date_col,
                    time_freq="M",
                    figsize=(12, 6)
                )
                plot_b64 = _to_base64(fig)
                html += f"<h5>Feature: <b>{feature_col}</b> - Р Р°СЃРїСЂРµРґРµР»РµРЅРёРµ</h5>"
                html += f'<img src="data:image/png;base64,{plot_b64}" style="max-width:100%; height:auto;" />'
                
                # РўРµРїР»РѕРєР°СЂС‚Р° РІС‹Р±СЂРѕСЃРѕРІ
                fig, _ = self.plot_outliers_heatmap(
                    df=df,
                    feature_col=feature_col,
                    time_col=date_col,
                    time_freq="M",
                    figsize=(12, 4)
                )
                plot_b64 = _to_base64(fig)
                html += f"<h5>Feature: <b>{feature_col}</b> - РђРЅР°Р»РёР· РІС‹Р±СЂРѕСЃРѕРІ</h5>"
                html += f'<img src="data:image/png;base64,{plot_b64}" style="max-width:100%; height:auto;" />'
                
                # РўРµРїР»РѕРєР°СЂС‚Р° РїСЂРѕРїСѓС‰РµРЅРЅС‹С… Р·РЅР°С‡РµРЅРёР№
                if df[feature_col].isna().any():
                    fig, _ = self.plot_missing_values_heatmap(
                        df=df,
                        feature_col=feature_col,
                        time_col=date_col,
                        time_freq="M",
                        figsize=(12, 4)
                    )
                    plot_b64 = _to_base64(fig)
                    html += f"<h5>Feature: <b>{feature_col}</b> - РђРЅР°Р»РёР· РїСЂРѕРїСѓС‰РµРЅРЅС‹С… Р·РЅР°С‡РµРЅРёР№</h5>"
                    html += f'<img src="data:image/png;base64,{plot_b64}" style="max-width:100%; height:auto;" />'
                else:
                    html += f"<p>Р”Р»СЏ РїСЂРёР·РЅР°РєР° <b>{feature_col}</b> РѕС‚СЃСѓС‚СЃС‚РІСѓСЋС‚ РїСЂРѕРїСѓС‰РµРЅРЅС‹Рµ Р·РЅР°С‡РµРЅРёСЏ.</p>"
                    
            except Exception as e:
                logger.error(f"Error plotting heatmap for '{feature_col}'", exc_info=True)
                html += f"<p>вќЊ Failed to plot heatmap for '{feature_col}': {str(e)}</p>"

        self.test_signal = "info"
        return {"DASHBOARD": html}
