"""Compatibility wrapper for `tests_blackbox.m3_regression_tests`."""

from .tests_blackbox.m3_regression_tests import *  # noqa: F401,F403
