"""Compatibility wrapper for `tests_blackbox.m9_visual_tests`."""

from .tests_blackbox.m9_visual_tests import *  # noqa: F401,F403
