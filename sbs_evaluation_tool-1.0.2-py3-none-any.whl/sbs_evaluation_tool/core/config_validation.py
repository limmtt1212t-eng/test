from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional

import pandas as pd

TaskType = Literal["classification", "regression"]
ModelMode = Literal["severity", "frequency", "binary", "classification"]
ValidationMode = Literal["oos", "oot"]


class ConfigValidationError(ValueError):
    def __init__(self, errors: List[str]):
        super().__init__("\n".join(errors))
        self.errors = errors


@dataclass
class ColumnsConfig:
    numeric_features: List[str] = field(default_factory=list)
    categorical_features: List[str] = field(default_factory=list)
    score_column: Optional[str] = None
    prediction_column: Optional[str] = None
    date_column: Optional[str] = None
    target_column: Optional[str] = None
    sample_column: Optional[str] = None
    id_column: Optional[str] = None
    weight_column: Optional[str] = None


@dataclass
class SBSConfig:
    task: TaskType
    model_mode: ModelMode
    validation_mode: ValidationMode
    columns: ColumnsConfig


def _ensure_list(value: Any, field_name: str) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value.strip()]
    if isinstance(value, (list, tuple)):
        out: List[str] = []
        for v in value:
            if not isinstance(v, str):
                raise ConfigValidationError(
                    [f"`{field_name}` должен быть списком строк; найден элемент типа {type(v)}"]
                )
            out.append(v.strip())
        return out
    raise ConfigValidationError([f"`{field_name}` должен быть списком строк или строкой"])


def _non_empty_str(value: Any, field_name: str, required: bool = True) -> Optional[str]:
    if value is None or (isinstance(value, str) and value.strip() == ""):
        if required:
            raise ConfigValidationError([f"Отсутствует или пустое поле `{field_name}`"])
        return None
    if not isinstance(value, str):
        raise ConfigValidationError([f"`{field_name}` должен быть строкой"])
    return value.strip()


def _derive_model_mode(task: Optional[str], weight_column: Optional[str]) -> ModelMode:
    if task == "classification":
        return "binary"
    if task == "regression":
        return "frequency" if weight_column else "severity"
    raise ConfigValidationError(
        ["Не удалось определить `model_mode`: задайте `model_mode` или корректный `task`"]
    )


def _derive_task(model_mode: str) -> TaskType:
    if model_mode in ("severity", "frequency"):
        return "regression"
    if model_mode in ("binary", "classification"):
        return "classification"
    raise ConfigValidationError([f"Неизвестный `model_mode`: {model_mode}"])


def validate_config(raw_config: Dict[str, Any], df: pd.DataFrame) -> SBSConfig:
    """
    Полная валидация и нормализация конфига относительно переданного df.

    Поддерживает новый контракт:
      - model_mode: severity | frequency | binary | classification
      - validation_mode: oos | oot

    И сохраняет обратную совместимость:
      - task: classification | regression
    """
    errors: List[str] = []

    task = raw_config.get("task")
    model_mode = raw_config.get("model_mode") or raw_config.get("mode")
    validation_mode = (
        raw_config.get("validation_mode")
        or raw_config.get("validation_sample_mode")
        or raw_config.get("sample_mode")
        or "oos"
    )

    if task is not None and task not in ("classification", "regression"):
        errors.append("`task` должен быть 'classification' или 'regression'")
    if model_mode is not None and model_mode not in ("severity", "frequency", "binary", "classification"):
        errors.append(
            "`model_mode` должен быть одним из: 'severity', 'frequency', 'binary', 'classification'"
        )
    if validation_mode not in ("oos", "oot"):
        errors.append("`validation_mode` должен быть 'oos' или 'oot'")
    if task is None and model_mode is None:
        errors.append("Нужно задать хотя бы одно из полей: `task` или `model_mode`")

    columns = raw_config.get("columns")
    if not isinstance(columns, dict):
        errors.append("`columns` обязателен и должен быть объектом (mapping)")

    if errors:
        raise ConfigValidationError(errors)

    numeric_features: List[str] = []
    categorical_features: List[str] = []
    score_column: Optional[str] = None
    prediction_column: Optional[str] = None
    date_column: Optional[str] = None
    target_column: Optional[str] = None
    sample_column: Optional[str] = None
    id_column: Optional[str] = None
    weight_column: Optional[str] = None

    try:
        numeric_features = _ensure_list(columns.get("numeric_features"), "columns.numeric_features")
        categorical_features = _ensure_list(columns.get("categorical_features"), "columns.categorical_features")
    except ConfigValidationError as e:
        errors.extend(e.errors)

    try:
        score_column = _non_empty_str(columns.get("score_column"), "columns.score_column", required=False)
        prediction_column = _non_empty_str(
            columns.get("prediction_column"), "columns.prediction_column", required=False
        )
        date_column = _non_empty_str(columns.get("date_column"), "columns.date_column", required=True)
        target_column = _non_empty_str(columns.get("target_column"), "columns.target_column", required=True)
        sample_column = _non_empty_str(columns.get("sample_column"), "columns.sample_column", required=True)
        id_column = _non_empty_str(columns.get("id_column"), "columns.id_column", required=True)
        weight_column = _non_empty_str(
            columns.get("weight_column") or columns.get("weight"),
            "columns.weight_column",
            required=False,
        )
    except ConfigValidationError as e:
        errors.extend(e.errors)

    if model_mode is None:
        try:
            model_mode = _derive_model_mode(task, weight_column)
        except ConfigValidationError as e:
            errors.extend(e.errors)

    resolved_task: Optional[TaskType] = None
    if model_mode is not None:
        try:
            resolved_task = _derive_task(model_mode)
        except ConfigValidationError as e:
            errors.extend(e.errors)

    if task is not None and resolved_task is not None and task != resolved_task:
        errors.append(
            f"`task={task}` конфликтует с `model_mode={model_mode}`. "
            f"Для этого режима ожидается `task={resolved_task}`"
        )

    task = resolved_task or task

    if task == "classification":
        if not score_column and not prediction_column:
            errors.append(
                "Для классификационных режимов требуется хотя бы одна колонка: "
                "`columns.score_column` или `columns.prediction_column`"
            )
        elif not score_column and prediction_column:
            score_column = prediction_column
        elif not prediction_column and score_column:
            prediction_column = score_column
    elif task == "regression":
        if not score_column:
            errors.append("Для регрессионных режимов требуется `columns.score_column`")
        if model_mode == "frequency" and not weight_column:
            errors.append("Для `model_mode=frequency` требуется `columns.weight_column` (экспозиция)")

    required_columns = {
        c
        for c in [
            date_column,
            target_column,
            sample_column,
            id_column,
            score_column,
            prediction_column,
            weight_column,
        ]
        if c is not None
    }
    missing_in_df = [c for c in required_columns if c not in df.columns]
    if missing_in_df:
        errors.append(f"В DataFrame отсутствуют необходимые колонки: {missing_in_df}")

    all_features = list(dict.fromkeys([*numeric_features, *categorical_features]))
    missing_features = [c for c in all_features if c not in df.columns]
    if missing_features:
        errors.append(f"Некоторые фичи отсутствуют в данных: {missing_features}")

    overlap = sorted(set(numeric_features).intersection(categorical_features))
    if overlap:
        errors.append(f"Фичи не должны дублироваться между numeric и categorical: {overlap}")

    if not numeric_features and not categorical_features:
        errors.append("Не заданы `numeric_features` и `categorical_features` — список фичей пуст")

    reserved = {
        c
        for c in [
            score_column,
            prediction_column,
            date_column,
            target_column,
            sample_column,
            id_column,
            weight_column,
        ]
        if c
    }
    bad_reserved_overlap = sorted(reserved.intersection(all_features))
    if bad_reserved_overlap:
        errors.append(f"Служебные колонки не должны входить в список фичей: {bad_reserved_overlap}")

    if date_column in df.columns:
        try:
            pd.to_datetime(df[date_column], errors="raise")
        except Exception:
            errors.append(f"`{date_column}` не приводится к datetime; проверь формат дат")

    if model_mode == "binary" and target_column in df.columns:
        unique_vals = pd.Series(df[target_column].dropna().unique())
        if unique_vals.nunique() > 10:
            errors.append(
                f"`{target_column}` выглядит не бинарным для `model_mode=binary` "
                "(найдено >10 уникальных значений). Проверьте кодировку таргета."
            )
    elif model_mode == "frequency" and target_column in df.columns:
        target_numeric = pd.to_numeric(df[target_column], errors="coerce")
        if target_numeric.isna().all():
            errors.append(f"`{target_column}` должен быть числовым для `model_mode=frequency`")
        elif (target_numeric.dropna() < 0).any():
            errors.append(f"`{target_column}` должен быть неотрицательным для `model_mode=frequency`")
    elif model_mode == "severity" and target_column in df.columns:
        target_numeric = pd.to_numeric(df[target_column], errors="coerce")
        if target_numeric.isna().all():
            errors.append(f"`{target_column}` должен быть числовым для `model_mode=severity`")

    for name, col in [("prediction_column", prediction_column), ("score_column", score_column)]:
        if col and col in df.columns and not pd.api.types.is_numeric_dtype(df[col]):
            errors.append(f"`{name}` ('{col}') должен быть числовым")

    if errors:
        raise ConfigValidationError(errors)

    norm_cols = ColumnsConfig(
        numeric_features=numeric_features,
        categorical_features=categorical_features,
        score_column=score_column,
        prediction_column=prediction_column,
        date_column=date_column,
        target_column=target_column,
        sample_column=sample_column,
        id_column=id_column,
        weight_column=weight_column,
    )
    return SBSConfig(
        task=task,
        model_mode=model_mode,
        validation_mode=validation_mode,
        columns=norm_cols,
    )
