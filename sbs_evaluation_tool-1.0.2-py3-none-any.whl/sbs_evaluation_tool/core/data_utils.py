from __future__ import annotations

from typing import Dict, List, Optional, Tuple, Union

import pandas as pd

from .config_validation import SBSConfig, ConfigValidationError, validate_config


TRAIN_ALIASES = {"train", "development", "dev"}
VALIDATION_ALIASES = {
    "oos": {"test", "oos", "out_of_sample", "out-of-sample", "validation", "valid", "val"},
    "oot": {"oot", "out_of_time", "out-of-time", "outoftime"},
}


def ensure_config(config: Union[Dict, SBSConfig], df: pd.DataFrame) -> SBSConfig:
    if isinstance(config, SBSConfig):
        return config
    return validate_config(config, df)


def get_col_name(cfg: SBSConfig, name: str) -> Optional[str]:
    return getattr(cfg.columns, name, None)


def get_model_mode(cfg: SBSConfig) -> str:
    return getattr(cfg, "model_mode", None) or ("binary" if str(cfg.task).lower() == "classification" else "severity")


def get_validation_mode(cfg: SBSConfig) -> str:
    return getattr(cfg, "validation_mode", None) or "oos"


def is_binary_mode(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) == "binary"


def is_generic_classification_mode(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) == "classification"


def is_regression_mode(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) in {"severity", "frequency"}


def uses_exposure(cfg: SBSConfig) -> bool:
    return get_model_mode(cfg) == "frequency"


def _normalize_sample_value(value: object) -> str:
    return str(value).strip().lower().replace(" ", "_")


def get_validation_aliases(cfg: SBSConfig) -> set[str]:
    return VALIDATION_ALIASES[get_validation_mode(cfg)]


def get_validation_label(cfg: SBSConfig) -> str:
    return get_validation_mode(cfg).upper()


def split_frames(df: pd.DataFrame, cfg: SBSConfig) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Splits DataFrame into train, validation, and genpop (full) based on sample_column and validation_mode.
    Returns (df_train, df_validation, df_genpop).
    """
    sc = cfg.columns.sample_column
    if sc is None or sc not in df.columns:
        raise ConfigValidationError([f"Column '{sc}' (sample_column) is missing in DataFrame"])

    normalized = df[sc].map(_normalize_sample_value)
    train_mask = normalized.isin(TRAIN_ALIASES)
    validation_aliases = get_validation_aliases(cfg)
    validation_mask = normalized.isin(validation_aliases)

    if not train_mask.any():
        raise ConfigValidationError(
            [f"В `{sc}` не найдены строки TRAIN. Ожидаются метки из набора: {sorted(TRAIN_ALIASES)}"]
        )
    if not validation_mask.any():
        raise ConfigValidationError(
            [
                f"Для validation_mode='{get_validation_mode(cfg)}' в `{sc}` "
                f"не найдены строки validation-сэмпла. Ожидаются метки из набора: {sorted(validation_aliases)}"
            ]
        )

    df_train = df[train_mask].copy()
    df_validation = df[validation_mask].copy()
    return df_train, df_validation, df.copy()


def get_weight_col(df: pd.DataFrame, cfg: SBSConfig, config_dict: Optional[dict] = None) -> Optional[pd.Series]:
    weight_col = None
    if config_dict:
        cols = config_dict.get("columns") or config_dict
        weight_col = cols.get("weight_column") or cols.get("weight")

    if weight_col is None:
        weight_col = getattr(cfg.columns, "weight_column", None)

    if not weight_col or weight_col not in df.columns:
        return None

    w = pd.to_numeric(df[weight_col], errors="coerce").fillna(0.0)
    if (w > 0).sum() == 0:
        return None
    return w


def get_features(df: pd.DataFrame, cfg: SBSConfig, include_categorical: bool = True) -> List[str]:
    num = getattr(cfg.columns, "numeric_features", []) or []
    cat = getattr(cfg.columns, "categorical_features", []) or []

    feats = list(num)
    if include_categorical:
        feats.extend(list(cat))
    return list(dict.fromkeys(feats))


def get_score_col(cfg: SBSConfig) -> Optional[str]:
    mode = get_model_mode(cfg)
    if mode in {"binary", "classification"}:
        return getattr(cfg.columns, "score_column", None) or getattr(cfg.columns, "prediction_column", None)
    if getattr(cfg.columns, "score_column", None):
        return cfg.columns.score_column
    if getattr(cfg.columns, "prediction_column", None):
        return cfg.columns.prediction_column
    raise ConfigValidationError(["Для регрессионных режимов требуется columns.score_column (или prediction_column)"])


def get_vectors(
    df: pd.DataFrame,
    cfg: SBSConfig,
    for_classification: bool = True,
) -> Tuple[pd.Series, Optional[pd.Series], Optional[pd.Series]]:
    tcol = cfg.columns.target_column
    scol = cfg.columns.score_column
    pcol = cfg.columns.prediction_column

    if tcol not in df.columns:
        raise ConfigValidationError([f"target_column '{tcol}' not in df"])

    y = df[tcol]
    score = df[scol] if (scol and scol in df.columns) else None
    pred = df[pcol] if (pcol and pcol in df.columns) else None

    if for_classification:
        if score is None and pred is None:
            raise ConfigValidationError(["For classification need either score_column or prediction_column"])
        if score is None:
            score = pred
    else:
        if score is None:
            if pred is not None:
                score = pred
            else:
                raise ConfigValidationError(
                    ["For regression need score_column (or prediction_column) with numeric predictions"]
                )

    return y, pred, score
