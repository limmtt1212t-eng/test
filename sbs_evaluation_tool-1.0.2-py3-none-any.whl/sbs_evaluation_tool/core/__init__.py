"""Core API surface for the SBS Evaluation Tool.

This package contains the core implementation of the SBS Evaluation Tool.

Typical imports:

    from sbs_evaluation_tool.core.base_test import BaseModelTest, TestGroupBuilder, ModelReportBuilder
    from sbs_evaluation_tool.core.config_validation import SBSConfig, ColumnsConfig, validate_config
    from sbs_evaluation_tool.core.inline_display import show_test_inline
    from sbs_evaluation_tool.core.runner import run_sbs_evaluation
"""

from .base_test import BaseModelTest, TestGroupBuilder, ModelReportBuilder
from .config_validation import (
    SBSConfig,
    ColumnsConfig,
    ModelMode,
    ValidationMode,
    validate_config,
    ConfigValidationError,
)
from .inline_display import show_test_inline
# Note: runner is NOT imported here to avoid circular dependency
# Import it directly: from sbs_evaluation_tool.core.runner import run_sbs_evaluation
from . import styles

__all__ = [
    "BaseModelTest",
    "TestGroupBuilder",
    "ModelReportBuilder",
    "SBSConfig",
    "ColumnsConfig",
    "ModelMode",
    "ValidationMode",
    "validate_config",
    "ConfigValidationError",
    "show_test_inline",
    # "run_sbs_evaluation",  # available via direct import from .runner
    "styles",
]
